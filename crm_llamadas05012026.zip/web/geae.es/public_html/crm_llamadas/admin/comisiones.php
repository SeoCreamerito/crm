<?php
/**
 * PANEL DE GESTIÓN DE COMISIONES
 * 
 * Módulo para que el administrador controle las comisiones generadas
 * por las ventas de cursos de cada teleoperadora.
 * 
 * Base de datos: geae_crm_llamadas
 * 
 * Funcionalidades:
 * - Ver comisiones por teleoperadora
 * - Filtrar por mes/año
 * - Marcar comisiones como pagadas
 * - Exportar liquidaciones
 * - Histórico de pagos
 */

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

verificarRol(['admin']);

$mes_actual = date('m');
$anio_actual = date('Y');

// Obtener filtros
$mes_filtro = isset($_GET['mes']) ? (int)$_GET['mes'] : $mes_actual;
$anio_filtro = isset($_GET['anio']) ? (int)$_GET['anio'] : $anio_actual;
$teleoperadora_filtro = isset($_GET['teleoperadora']) ? (int)$_GET['teleoperadora'] : 0;

// Estadísticas generales del período
$sqlStats = "SELECT 
    COUNT(*) as total_ventas,
    SUM(credito_formacion) as creditos_totales,
    SUM(importe_comision) as comisiones_totales,
    SUM(CASE WHEN comision_pagada = 1 THEN importe_comision ELSE 0 END) as pagadas,
    SUM(CASE WHEN comision_pagada = 0 THEN importe_comision ELSE 0 END) as pendientes
FROM leads_activos
WHERE nombre_curso IS NOT NULL
  AND MONTH(fecha_cierre_venta) = ?
  AND YEAR(fecha_cierre_venta) = ?";

$stmtStats = $conn->prepare($sqlStats);
$stmtStats->bind_param("ii", $mes_filtro, $anio_filtro);
$stmtStats->execute();
$stats = $stmtStats->fetch_assoc();
$stmtStats->close();

// Obtener lista de teleoperadoras
$sqlTeleops = "SELECT id, nombre, apellidos FROM usuarios WHERE rol = 'agent' AND activo = 1 ORDER BY nombre";
$resultTeleops = $conn->query($sqlTeleops);
$teleoperadoras = [];
while ($row = $resultTeleops->fetch_assoc()) {
    $teleoperadoras[] = $row;
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Comisiones - CRM</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        .stat-box {
            border-left: 4px solid;
            padding: 1rem;
            background: white;
            border-radius: 0.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stat-box.total { border-color: #0d6efd; }
        .stat-box.pagadas { border-color: #198754; }
        .stat-box.pendientes { border-color: #ffc107; }
        
        .badge-pagada { background-color: #198754; }
        .badge-pendiente { background-color: #ffc107; color: #000; }
        
        .table-comisiones tbody tr:hover {
            background-color: rgba(0,123,255,0.05);
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="../admin/dashboard.php">
                <i class="bi bi-speedometer2"></i> CRM Admin
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="../admin/dashboard.php">
                    <i class="bi bi-arrow-left"></i> Volver
                </a>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-md-12">
                <h2>
                    <i class="bi bi-cash-coin"></i> Gestión de Comisiones
                </h2>
                <p class="text-muted">Control de comisiones por ventas de cursos</p>
            </div>
        </div>

        <!-- Filtros -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Mes</label>
                        <select name="mes" class="form-select">
                            <?php for($m = 1; $m <= 12; $m++): ?>
                            <option value="<?= $m ?>" <?= $m == $mes_filtro ? 'selected' : '' ?>>
                                <?= strftime('%B', mktime(0, 0, 0, $m, 1)) ?>
                            </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Año</label>
                        <select name="anio" class="form-select">
                            <?php for($y = 2024; $y <= date('Y') + 1; $y++): ?>
                            <option value="<?= $y ?>" <?= $y == $anio_filtro ? 'selected' : '' ?>>
                                <?= $y ?>
                            </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">Teleoperadora</label>
                        <select name="teleoperadora" class="form-select">
                            <option value="0">Todas las teleoperadoras</option>
                            <?php foreach($teleoperadoras as $t): ?>
                            <option value="<?= $t['id'] ?>" <?= $t['id'] == $teleoperadora_filtro ? 'selected' : '' ?>>
                                <?= htmlspecialchars($t['nombre'] . ' ' . $t['apellidos']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">
                            <i class="bi bi-search"></i> Filtrar
                        </button>
                        <a href="comisiones.php" class="btn btn-outline-secondary">
                            <i class="bi bi-x-circle"></i> Limpiar
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Estadísticas -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="stat-box total">
                    <h6 class="text-muted mb-2">Total Comisiones</h6>
                    <h3 class="mb-1"><?= number_format($stats['comisiones_totales'] ?? 0, 2) ?>€</h3>
                    <small><?= $stats['total_ventas'] ?? 0 ?> ventas</small>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="stat-box pagadas">
                    <h6 class="text-muted mb-2">Comisiones Pagadas</h6>
                    <h3 class="mb-1 text-success"><?= number_format($stats['pagadas'] ?? 0, 2) ?>€</h3>
                    <small>
                        <?= $stats['comisiones_totales'] > 0 
                            ? round(($stats['pagadas'] / $stats['comisiones_totales']) * 100, 1) 
                            : 0 ?>% del total
                    </small>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="stat-box pendientes">
                    <h6 class="text-muted mb-2">Comisiones Pendientes</h6>
                    <h3 class="mb-1 text-warning"><?= number_format($stats['pendientes'] ?? 0, 2) ?>€</h3>
                    <small>Por pagar</small>
                </div>
            </div>
        </div>

        <!-- Tabla de comisiones por teleoperadora -->
        <div class="card shadow">
            <div class="card-header bg-white">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h5 class="mb-0">
                            <i class="bi bi-table"></i> Comisiones del Período
                        </h5>
                    </div>
                    <div class="col-md-6 text-end">
                        <button id="btnExportarExcel" class="btn btn-success btn-sm">
                            <i class="bi bi-file-earmark-excel"></i> Exportar Excel
                        </button>
                        <button id="btnMarcarPagadas" class="btn btn-primary btn-sm" disabled>
                            <i class="bi bi-check-circle"></i> Marcar como Pagadas
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table id="tablaComisiones" class="table table-hover table-comisiones">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="selectAll"></th>
                            <th>Teleoperadora</th>
                            <th>Ventas</th>
                            <th>Créditos Vendidos</th>
                            <th>Comisión Total</th>
                            <th>Pagado</th>
                            <th>Pendiente</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Consulta de comisiones por teleoperadora
                        $sqlComisiones = "SELECT 
                            u.id,
                            u.nombre,
                            u.apellidos,
                            COUNT(*) as total_ventas,
                            SUM(l.credito_formacion) as creditos_totales,
                            SUM(l.importe_comision) as comision_total,
                            SUM(CASE WHEN l.comision_pagada = 1 THEN l.importe_comision ELSE 0 END) as pagado,
                            SUM(CASE WHEN l.comision_pagada = 0 THEN l.importe_comision ELSE 0 END) as pendiente,
                            CASE 
                                WHEN SUM(CASE WHEN l.comision_pagada = 0 THEN 1 ELSE 0 END) = 0 THEN 'Pagado'
                                WHEN SUM(CASE WHEN l.comision_pagada = 1 THEN 1 ELSE 0 END) = 0 THEN 'Pendiente'
                                ELSE 'Parcial'
                            END as estado_pago
                        FROM usuarios u
                        INNER JOIN leads_activos l ON u.id = l.id_teleoperadora_origen
                        WHERE u.rol = 'agent'
                          AND l.nombre_curso IS NOT NULL
                          AND MONTH(l.fecha_cierre_venta) = ?
                          AND YEAR(l.fecha_cierre_venta) = ?";
                        
                        if ($teleoperadora_filtro > 0) {
                            $sqlComisiones .= " AND u.id = ?";
                        }
                        
                        $sqlComisiones .= " GROUP BY u.id ORDER BY comision_total DESC";
                        
                        $stmtCom = $conn->prepare($sqlComisiones);
                        
                        if ($teleoperadora_filtro > 0) {
                            $stmtCom->bind_param("iii", $mes_filtro, $anio_filtro, $teleoperadora_filtro);
                        } else {
                            $stmtCom->bind_param("ii", $mes_filtro, $anio_filtro);
                        }
                        
                        $stmtCom->execute();
                        $resultCom = $stmtCom->get_result();
                        
                        while ($row = $resultCom->fetch_assoc()):
                            $badge_class = $row['estado_pago'] == 'Pagado' ? 'badge-pagada' : 'badge-pendiente';
                        ?>
                        <tr data-teleoperadora-id="<?= $row['id'] ?>">
                            <td>
                                <?php if ($row['pendiente'] > 0): ?>
                                <input type="checkbox" class="comision-checkbox" value="<?= $row['id'] ?>">
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['nombre'] . ' ' . $row['apellidos']) ?></strong>
                            </td>
                            <td><?= $row['total_ventas'] ?></td>
                            <td><?= number_format($row['creditos_totales'], 2) ?>€</td>
                            <td><strong><?= number_format($row['comision_total'], 2) ?>€</strong></td>
                            <td class="text-success"><?= number_format($row['pagado'], 2) ?>€</td>
                            <td class="text-warning"><strong><?= number_format($row['pendiente'], 2) ?>€</strong></td>
                            <td>
                                <span class="badge <?= $badge_class ?>">
                                    <?= $row['estado_pago'] ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary btn-ver-detalle" 
                                        data-id="<?= $row['id'] ?>"
                                        data-nombre="<?= htmlspecialchars($row['nombre'] . ' ' . $row['apellidos']) ?>">
                                    <i class="bi bi-eye"></i> Ver Detalle
                                </button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal: Detalle de Comisiones -->
    <div class="modal fade" id="modalDetalleComisiones" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="bi bi-list-ul"></i> Detalle de Ventas - 
                        <span id="nombreTeleoperadora"></span>
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="contenidoDetalle">
                    <!-- Cargado dinámicamente -->
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
    $(document).ready(function() {
        // DataTable
        $('#tablaComisiones').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json'
            },
            pageLength: 25,
            order: [[4, 'desc']] // Ordenar por comisión total
        });

        // Select all
        $('#selectAll').on('click', function() {
            $('.comision-checkbox').prop('checked', this.checked);
            actualizarBotonMarcar();
        });

        $('.comision-checkbox').on('change', function() {
            actualizarBotonMarcar();
        });

        function actualizarBotonMarcar() {
            const seleccionados = $('.comision-checkbox:checked').length;
            $('#btnMarcarPagadas').prop('disabled', seleccionados === 0);
        }

        // Marcar como pagadas
        $('#btnMarcarPagadas').on('click', function() {
            const seleccionados = $('.comision-checkbox:checked').map(function() {
                return $(this).val();
            }).get();

            if (seleccionados.length === 0) return;

            Swal.fire({
                title: '¿Marcar como pagadas?',
                text: `Se marcarán ${seleccionados.length} teleoperadora(s) con comisiones pagadas`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Sí, marcar como pagadas',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax/marcar_comisiones_pagadas.php',
                        type: 'POST',
                        data: {
                            teleoperadoras: seleccionados,
                            mes: <?= $mes_filtro ?>,
                            anio: <?= $anio_filtro ?>
                        },
                        success: function(response) {
                            if (response.success) {
                                Swal.fire('¡Éxito!', response.mensaje, 'success')
                                    .then(() => location.reload());
                            } else {
                                Swal.fire('Error', response.mensaje, 'error');
                            }
                        }
                    });
                }
            });
        });

        // Ver detalle
        $('.btn-ver-detalle').on('click', function() {
            const idTeleoperadora = $(this).data('id');
            const nombreTeleoperadora = $(this).data('nombre');
            
            $('#nombreTeleoperadora').text(nombreTeleoperadora);
            
            $.ajax({
                url: 'ajax/detalle_comisiones_teleoperadora.php',
                type: 'POST',
                data: {
                    id_teleoperadora: idTeleoperadora,
                    mes: <?= $mes_filtro ?>,
                    anio: <?= $anio_filtro ?>
                },
                success: function(response) {
                    $('#contenidoDetalle').html(response);
                    $('#modalDetalleComisiones').modal('show');
                }
            });
        });

        // Exportar Excel
        $('#btnExportarExcel').on('click', function() {
            window.location.href = 'exportar_comisiones_excel.php?mes=<?= $mes_filtro ?>&anio=<?= $anio_filtro ?>&teleoperadora=<?= $teleoperadora_filtro ?>';
        });
    });
    </script>
</body>
</html>
