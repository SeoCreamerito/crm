<?php
/**
 * 🔍 SCRIPT DE DIAGNÓSTICO - Enlaces a Gestión de Cursos
 * 
 * Sube este archivo a /admin/ como diagnostico_enlaces.php
 * Accede desde: https://tudominio.com/crm_llamadas/admin/diagnostico_enlaces.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Diagnóstico de Enlaces - CRM</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .success { color: #10b981; font-weight: bold; }
        .error { color: #ef4444; font-weight: bold; }
        .warning { color: #f59e0b; font-weight: bold; }
        .info { color: #3b82f6; font-weight: bold; }
        code {
            background: #f3f4f6;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        table th, table td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #e5e7eb;
        }
        table th {
            background: #f9fafb;
            font-weight: 600;
        }
        .check-item {
            padding: 10px;
            margin: 5px 0;
            border-left: 4px solid #cbd5e1;
            background: #f9fafb;
        }
        .check-item.pass {
            border-left-color: #10b981;
            background: #f0fdf4;
        }
        .check-item.fail {
            border-left-color: #ef4444;
            background: #fef2f2;
        }
        h1 { color: #1f2937; }
        h2 { color: #4b5563; margin-top: 30px; }
        h3 { color: #6b7280; }
    </style>
</head>
<body>
    <h1>🔍 Diagnóstico de Enlaces - CRM Llamadas</h1>
    <p><strong>Fecha:</strong> <?php echo date('d/m/Y H:i:s'); ?></p>

    <?php
    // 1. VERIFICAR ESTRUCTURA DE CARPETAS
    echo '<div class="card">';
    echo '<h2>📁 1. Estructura de Carpetas</h2>';
    
    $rutas_criticas = [
        'Dashboard' => __DIR__ . '/dashboard.php',
        'Carpeta Cursos' => __DIR__ . '/cursos',
        'Gestión Cursos' => __DIR__ . '/cursos/gestion_cursos.php',
        'Importar Excel' => __DIR__ . '/cursos/importar_excel_produccion.php',
        'Config' => __DIR__ . '/../includes/config.php',
        'Auth' => __DIR__ . '/../includes/auth.php',
    ];
    
    echo '<table>';
    echo '<tr><th>Archivo/Carpeta</th><th>Ruta</th><th>Estado</th></tr>';
    
    $estructura_ok = true;
    foreach ($rutas_criticas as $nombre => $ruta) {
        $existe = file_exists($ruta);
        $tipo = is_dir($ruta) ? '📁 Carpeta' : '📄 Archivo';
        $clase = $existe ? 'success' : 'error';
        $estado = $existe ? '✅ Existe' : '❌ No existe';
        
        if (!$existe) $estructura_ok = false;
        
        echo "<tr>";
        echo "<td>$tipo <strong>$nombre</strong></td>";
        echo "<td><code>" . basename(dirname($ruta)) . '/' . basename($ruta) . "</code></td>";
        echo "<td class='$clase'>$estado</td>";
        echo "</tr>";
    }
    echo '</table>';
    
    if ($estructura_ok) {
        echo '<div class="check-item pass">✅ <strong>Estructura de carpetas correcta</strong></div>';
    } else {
        echo '<div class="check-item fail">❌ <strong>Faltan archivos o carpetas críticas</strong></div>';
    }
    echo '</div>';

    // 2. ANALIZAR ENLACES EN DASHBOARD
    echo '<div class="card">';
    echo '<h2>🔗 2. Análisis de Enlaces en dashboard.php</h2>';
    
    $dashboard_file = __DIR__ . '/dashboard.php';
    
    if (file_exists($dashboard_file)) {
        $contenido = file_get_contents($dashboard_file);
        
        // Buscar enlaces a /cursos/ (INCORRECTOS)
        preg_match_all('/(href|action)=(["\'])([^"\']*\/cursos\/[^"\']*)\2/', $contenido, $enlaces_incorrectos);
        
        // Buscar enlaces a cursos/ (CORRECTOS - relativos)
        preg_match_all('/(href|action)=(["\'])(?!.*\/)(cursos\/[^"\']*)\2/', $contenido, $enlaces_correctos);
        
        echo '<h3>❌ Enlaces con ruta absoluta incorrecta (<code>/cursos/</code>):</h3>';
        if (!empty($enlaces_incorrectos[3])) {
            echo '<table>';
            echo '<tr><th>Enlace Encontrado</th><th>Tipo</th></tr>';
            foreach (array_unique($enlaces_incorrectos[3]) as $enlace) {
                echo "<tr>";
                echo "<td><code class='error'>" . htmlspecialchars($enlace) . "</code></td>";
                echo "<td class='error'>INCORRECTO</td>";
                echo "</tr>";
            }
            echo '</table>';
            echo '<div class="check-item fail">❌ <strong>Se encontraron ' . count(array_unique($enlaces_incorrectos[3])) . ' enlaces incorrectos</strong></div>';
        } else {
            echo '<div class="check-item pass">✅ No se encontraron enlaces con ruta absoluta incorrecta</div>';
        }
        
        echo '<h3>✅ Enlaces con ruta relativa correcta (<code>cursos/</code>):</h3>';
        if (!empty($enlaces_correctos[3])) {
            echo '<table>';
            echo '<tr><th>Enlace Encontrado</th><th>Tipo</th></tr>';
            foreach (array_unique($enlaces_correctos[3]) as $enlace) {
                echo "<tr>";
                echo "<td><code class='success'>" . htmlspecialchars($enlace) . "</code></td>";
                echo "<td class='success'>CORRECTO</td>";
                echo "</tr>";
            }
            echo '</table>';
            echo '<div class="check-item pass">✅ <strong>Se encontraron ' . count(array_unique($enlaces_correctos[3])) . ' enlaces correctos</strong></div>';
        } else {
            echo '<div class="check-item warning">⚠️ No se encontraron enlaces relativos correctos</div>';
        }
        
    } else {
        echo '<div class="check-item fail">❌ No se puede leer dashboard.php</div>';
    }
    echo '</div>';

    // 3. VERIFICAR PERMISOS
    echo '<div class="card">';
    echo '<h2>🔐 3. Permisos de Archivos</h2>';
    
    $archivos_permisos = [
        'dashboard.php' => __DIR__ . '/dashboard.php',
        'gestion_cursos.php' => __DIR__ . '/cursos/gestion_cursos.php',
    ];
    
    echo '<table>';
    echo '<tr><th>Archivo</th><th>Permisos</th><th>Estado</th></tr>';
    
    foreach ($archivos_permisos as $nombre => $ruta) {
        if (file_exists($ruta)) {
            $permisos = substr(sprintf('%o', fileperms($ruta)), -4);
            $legible = is_readable($ruta) ? '✅' : '❌';
            $ejecutable = is_executable($ruta) ? '✅' : '⚠️';
            
            echo "<tr>";
            echo "<td><code>$nombre</code></td>";
            echo "<td>$permisos</td>";
            echo "<td>Lectura: $legible | Ejecución: $ejecutable</td>";
            echo "</tr>";
        }
    }
    echo '</table>';
    echo '</div>';

    // 4. PRUEBA DE INCLUSIÓN
    echo '<div class="card">';
    echo '<h2>🧪 4. Prueba de Acceso</h2>';
    
    $gestion_cursos = __DIR__ . '/cursos/gestion_cursos.php';
    
    if (file_exists($gestion_cursos)) {
        echo '<div class="check-item pass">✅ <code>gestion_cursos.php</code> existe y es accesible</div>';
        
        // Verificar sintaxis básica
        $contenido_gc = file_get_contents($gestion_cursos);
        if (strpos($contenido_gc, '<?php') === 0) {
            echo '<div class="check-item pass">✅ El archivo tiene sintaxis PHP válida</div>';
        } else {
            echo '<div class="check-item warning">⚠️ El archivo podría no tener sintaxis PHP correcta</div>';
        }
        
        // Buscar requires
        if (preg_match('/require.*config\.php/', $contenido_gc)) {
            echo '<div class="check-item pass">✅ El archivo requiere config.php correctamente</div>';
        } else {
            echo '<div class="check-item warning">⚠️ No se encontró require de config.php</div>';
        }
        
    } else {
        echo '<div class="check-item fail">❌ <code>gestion_cursos.php</code> NO existe</div>';
    }
    echo '</div>';

    // 5. RECOMENDACIONES
    echo '<div class="card">';
    echo '<h2>💡 5. Recomendaciones</h2>';
    
    if (!empty($enlaces_incorrectos[3])) {
        echo '<div class="check-item fail">';
        echo '<h3>🔧 Acción Requerida: Corregir Enlaces</h3>';
        echo '<ol>';
        echo '<li>Abre <code>/admin/dashboard.php</code> en el editor</li>';
        echo '<li>Busca: <code>/cursos/gestion_cursos.php</code></li>';
        echo '<li>Reemplaza por: <code>cursos/gestion_cursos.php</code></li>';
        echo '<li>Guarda el archivo</li>';
        echo '</ol>';
        echo '<p><strong>O descarga el archivo corregido que te proporcioné.</strong></p>';
        echo '</div>';
    } else {
        echo '<div class="check-item pass">';
        echo '<h3>✅ Los enlaces parecen estar correctos</h3>';
        echo '<p>Si aún tienes problemas, verifica:</p>';
        echo '<ul>';
        echo '<li>Que no haya errores de PHP en <code>gestion_cursos.php</code></li>';
        echo '<li>Que la sesión de usuario esté activa</li>';
        echo '<li>Que el usuario tenga permisos para acceder a gestión de cursos</li>';
        echo '</ul>';
        echo '</div>';
    }
    echo '</div>';

    // 6. INFORMACIÓN DEL SERVIDOR
    echo '<div class="card">';
    echo '<h2>ℹ️ 6. Información del Servidor</h2>';
    echo '<table>';
    echo '<tr><th>Parámetro</th><th>Valor</th></tr>';
    echo '<tr><td>PHP Version</td><td>' . phpversion() . '</td></tr>';
    echo '<tr><td>Document Root</td><td>' . $_SERVER['DOCUMENT_ROOT'] . '</td></tr>';
    echo '<tr><td>Script Path</td><td>' . __FILE__ . '</td></tr>';
    echo '<tr><td>Working Directory</td><td>' . getcwd() . '</td></tr>';
    echo '</table>';
    echo '</div>';
    ?>

    <div class="card" style="background: #eff6ff; border: 2px solid #3b82f6;">
        <h2 style="color: #1e40af;">📊 Resumen del Diagnóstico</h2>
        <?php
        $total_problemas = 0;
        
        if (!$estructura_ok) {
            echo '<p class="error">❌ Problemas con la estructura de carpetas</p>';
            $total_problemas++;
        }
        
        if (!empty($enlaces_incorrectos[3])) {
            echo '<p class="error">❌ Enlaces incorrectos encontrados en dashboard.php</p>';
            $total_problemas++;
        }
        
        if (!file_exists($gestion_cursos)) {
            echo '<p class="error">❌ No se encuentra gestion_cursos.php</p>';
            $total_problemas++;
        }
        
        if ($total_problemas === 0) {
            echo '<p class="success">✅ <strong>¡No se detectaron problemas críticos!</strong></p>';
            echo '<p>Si aún no puedes acceder a gestión de cursos, verifica los logs de PHP en cPanel.</p>';
        } else {
            echo '<p class="warning">⚠️ Se detectaron <strong>' . $total_problemas . ' problema(s)</strong> que deben corregirse.</p>';
            echo '<p>Sigue las recomendaciones de la sección 5 para solucionarlos.</p>';
        }
        ?>
    </div>

    <p style="text-align: center; color: #6b7280; margin-top: 40px;">
        <small>Diagnóstico generado por CRM Llamadas v1.0 | <?php echo date('d/m/Y H:i:s'); ?></small>
    </p>
</body>
</html>
