<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
requireLogin();
requireRole('admin');

// Solo mostramos un mensaje mínimo para confirmar que es una página con HTML
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reasignación Masiva - CRM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- ✅ CSS personalizado -->
    <link rel="stylesheet" href="/crm_llamadas/assets/css/main.css">
</head>
<body>
<div class="container mt-4">
    <h2>🔄 Reasignación Masiva (en desarrollo)</h2>
    <p>Esta página permitirá reasignar leads desde tablas finales.</p>
    <a href="dashboard.php" class="btn btn-secondary">← Volver</a>
</div>

<!-- ✅ JS personalizado -->
<script src="/crm_llamadas/assets/js/main.js"></script>
</body>
</html>