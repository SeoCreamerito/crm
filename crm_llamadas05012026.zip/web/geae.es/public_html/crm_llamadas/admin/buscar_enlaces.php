<?php
/**
 * BUSCAR ENLACES INCORRECTOS EN DASHBOARD
 * Sube este archivo a /admin/ como buscar_enlaces.php
 * Te mostrará qué enlaces hay que cambiar
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>🔍 Analizando Enlaces en dashboard.php</h2>";

$dashboard_path = __DIR__ . '/dashboard.php';

if (!file_exists($dashboard_path)) {
    die("❌ No se encuentra dashboard.php en " . __DIR__);
}

echo "✅ Archivo encontrado: " . realpath($dashboard_path) . "<br><br>";

// Leer contenido
$contenido = file_get_contents($dashboard_path);

echo "<h3>📋 Enlaces a /cursos/ encontrados:</h3>";

// Buscar enlaces a /cursos/
preg_match_all('/(href=|action=|window\.location=)["\']([^"\']*\/cursos\/[^"\']*)["\']/', $contenido, $matches);

if (!empty($matches[2])) {
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
    echo "<tr><th>Enlace Incorrecto</th><th>Debe Ser</th></tr>";
    
    foreach ($matches[2] as $enlace) {
        $enlace_corregido = str_replace('/cursos/', '/admin/cursos/', $enlace);
        
        echo "<tr>";
        echo "<td><code style='color: red;'>" . htmlspecialchars($enlace) . "</code></td>";
        echo "<td><code style='color: green;'>" . htmlspecialchars($enlace_corregido) . "</code></td>";
        echo "</tr>";
    }
    
    echo "</table><br>";
    
    echo "<div style='background: #ffe; padding: 15px; border: 2px solid #cc0; margin: 20px 0;'>";
    echo "<h4>🔧 SOLUCIÓN:</h4>";
    echo "<p>Abre <code>/admin/dashboard.php</code> en el editor y busca/reemplaza:</p>";
    echo "<ul>";
    echo "<li><strong>Buscar:</strong> <code>/cursos/</code></li>";
    echo "<li><strong>Reemplazar por:</strong> <code>/admin/cursos/</code></li>";
    echo "</ul>";
    echo "<p><strong>O</strong> usa el botón de abajo para corregirlo automáticamente:</p>";
    echo "<form method='POST' action=''>";
    echo "<button type='submit' name='corregir' style='background: green; color: white; padding: 10px 20px; border: none; cursor: pointer; font-size: 16px;'>";
    echo "✅ CORREGIR AUTOMÁTICAMENTE</button>";
    echo "</form>";
    echo "</div>";
    
} else {
    echo "<div style='background: #efe; padding: 15px; border: 2px solid #0c0;'>";
    echo "✅ <strong>No se encontraron enlaces a /cursos/</strong><br>";
    echo "Los enlaces ya están correctos o se usan rutas diferentes.";
    echo "</div>";
}

// Buscar también enlaces relativos
echo "<br><h3>🔗 Todos los enlaces relacionados con cursos:</h3>";

preg_match_all('/(href=|action=|window\.location=)["\']([^"\']*cursos[^"\']*)["\']/', $contenido, $matches_all);

if (!empty($matches_all[2])) {
    echo "<ul>";
    foreach (array_unique($matches_all[2]) as $enlace) {
        $color = (strpos($enlace, '/admin/cursos/') !== false) ? 'green' : 'orange';
        echo "<li><code style='color: $color;'>" . htmlspecialchars($enlace) . "</code></li>";
    }
    echo "</ul>";
}

// Botón de corrección automática
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['corregir'])) {
    echo "<br><hr><br>";
    echo "<h3>🔧 Aplicando Correcciones...</h3>";
    
    // Hacer backup
    $backup_path = $dashboard_path . '.backup.' . date('YmdHis');
    copy($dashboard_path, $backup_path);
    echo "✅ Backup creado: " . basename($backup_path) . "<br>";
    
    // Corregir enlaces
    $contenido_nuevo = str_replace('/cursos/', '/admin/cursos/', $contenido);
    
    // Guardar
    if (file_put_contents($dashboard_path, $contenido_nuevo)) {
        echo "✅ <strong>Archivo corregido exitosamente</strong><br><br>";
        echo "<div style='background: #efe; padding: 15px; border: 2px solid #0c0;'>";
        echo "✅ <strong>¡Corrección completada!</strong><br>";
        echo "Ahora prueba acceder a: <a href='dashboard.php' target='_blank'>dashboard.php</a>";
        echo "</div>";
    } else {
        echo "❌ <strong>Error al guardar el archivo</strong><br>";
        echo "Tendrás que editarlo manualmente.";
    }
}

echo "<br><hr><br>";

echo "<h3>📝 Instrucciones Manuales:</h3>";
echo "<ol>";
echo "<li>Ve a cPanel File Manager</li>";
echo "<li>Navega a <code>/crm_llamadas/admin/</code></li>";
echo "<li>Haz clic derecho en <code>dashboard.php</code> → Edit</li>";
echo "<li>Busca (Ctrl+F): <code>/cursos/</code></li>";
echo "<li>Reemplaza por: <code>/admin/cursos/</code></li>";
echo "<li>Guarda el archivo</li>";
echo "</ol>";

?>
