<?php
/**
 * PANEL DE GESTIÓN MOODLE
 * Ubicación: /admin/cursos/moodle_gestion.php
 * 
 * Integración completa Moodle con CRM
 */

error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', 0);

require_once '../../includes/config.php';
require_once '../../includes/MoodleAPI.php';

// Verificar sesión
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../../auth/login.php');
    exit;
}

if (!in_array($_SESSION['rol'], ['admin', 'gestion_cursos'])) {
    die('Acceso denegado');
}

$moodle = new MoodleAPI($conn);

// Obtener cursos de Moodle
$cursosMoodle = $moodle->getCursos();

// Obtener cursos del CRM pendientes de matricular
$sqlCursosCRM = "SELECT 
    l.id,
    l.empresa,
    l.nombre_curso,
    l.nombre_alumno,
    l.dni_alumno,
    l.email_alumno,
    l.telefono_alumno,
    l.envio_claves
FROM leads_activos l
WHERE l.nombre_curso IS NOT NULL
  AND l.estado_curso IN ('pendiente', 'en_proceso')
  AND (l.envio_claves IS NULL OR l.envio_claves = 0)
ORDER BY l.fecha_alta_curso DESC
LIMIT 100";

$resultCRM = $conn->query($sqlCursosCRM);
$cursosCRM = [];
while ($row = $resultCRM->fetch_assoc()) {
    $cursosCRM[] = $row;
}

// Procesar formulario
$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    
    if ($_POST['accion'] === 'crear_individual') {
        
        // Generar username automático
        $username = strtolower(substr($_POST['firstname'], 0, 1) . $_POST['lastname']);
        $username = preg_replace('/[^a-z0-9]/', '', $username);
        $username = substr($username, 0, 20);
        
        // Generar contraseña segura
        $password = generarPasswordSeguro();
        
        $datos = [
            'username' => $username,
            'password' => $password,
            'firstname' => $_POST['firstname'],
            'lastname' => $_POST['lastname'],
            'email' => $_POST['email'],
            'courseid' => (int)$_POST['courseid'],
            'id_curso_crm' => (int)$_POST['id_curso_crm']
        ];
        
        // Crear y matricular
        $resultado = $moodle->crearYMatricular($datos);
        
        if ($resultado['success']) {
            // Obtener nombre del curso
            $curso_nombre = '';
            foreach ($cursosMoodle['data'] as $c) {
                if ($c['id'] == $datos['courseid']) {
                    $curso_nombre = $c['nombre'];
                    break;
                }
            }
            
            // Enviar credenciales
            $datos['curso_nombre'] = $curso_nombre;
            $datos['user_id'] = $resultado['user_id'];
            $envio = $moodle->enviarCredenciales($datos);
            
            if ($envio['success']) {
                $mensaje = "✅ Usuario creado, matriculado y credenciales enviadas correctamente";
                $tipo_mensaje = 'success';
            } else {
                $mensaje = "✅ Usuario creado y matriculado, pero error al enviar email";
                $tipo_mensaje = 'warning';
            }
        } else {
            $mensaje = "❌ Error: " . $resultado['error'];
            $tipo_mensaje = 'danger';
        }
    }
}

function generarPasswordSeguro($longitud = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%';
    $password = '';
    for ($i = 0; $i < $longitud; $i++) {
        $password .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $password;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión Moodle - CRM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <style>
        .header-moodle {
            background: linear-gradient(135deg, #f98012 0%, #d96b08 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .stat-card {
            border-left: 4px solid #f98012;
        }
        .badge-moodle {
            background: #f98012;
        }
    </style>
</head>
<body class="bg-light">
    
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="bg-white border-bottom">
        <div class="container-fluid py-2">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="../dashboard.php"><i class="bi bi-house-door"></i> Dashboard</a></li>
                <li class="breadcrumb-item"><a href="gestion_cursos.php">Gestión de Cursos</a></li>
                <li class="breadcrumb-item active">Moodle</li>
            </ol>
        </div>
    </nav>
    
    <div class="container-fluid mt-4">
        
        <!-- Header -->
        <div class="header-moodle">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2><i class="bi bi-mortarboard-fill"></i> Gestión Moodle</h2>
                    <p class="mb-0">Integración completa con plataforma Moodle</p>
                </div>
                <div>
                    <a href="gestion_cursos.php" class="btn btn-light">
                        <i class="bi bi-arrow-left"></i> Volver
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Mensajes -->
        <?php if ($mensaje): ?>
        <div class="alert alert-<?= $tipo_mensaje ?> alert-dismissible">
            <?= $mensaje ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Estadísticas -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <h6 class="text-muted">Cursos Moodle</h6>
                        <h3 class="text-primary"><?= $cursosMoodle['success'] ? count($cursosMoodle['data']) : 0 ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card" style="border-left-color: #dc3545;">
                    <div class="card-body">
                        <h6 class="text-muted">Pendientes Matricular</h6>
                        <h3 class="text-danger"><?= count($cursosCRM) ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card" style="border-left-color: #198754;">
                    <div class="card-body">
                        <h6 class="text-muted">Con Claves Enviadas</h6>
                        <h3 class="text-success">
                            <?php
                            $conClaves = 0;
                            $sql = "SELECT COUNT(*) as total FROM leads_activos WHERE envio_claves = 1";
                            $r = $conn->query($sql);
                            if ($r) $conClaves = $r->fetch_assoc()['total'];
                            echo $conClaves;
                            ?>
                        </h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card" style="border-left-color: #ffc107;">
                    <div class="card-body">
                        <h6 class="text-muted">Estado API</h6>
                        <h3 class="<?= $cursosMoodle['success'] ? 'text-success' : 'text-danger' ?>">
                            <?= $cursosMoodle['success'] ? '✓ OK' : '✗ Error' ?>
                        </h3>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tabs -->
        <ul class="nav nav-tabs mb-4">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#tab-individual">
                    <i class="bi bi-person-plus"></i> Matriculación Individual
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-masiva">
                    <i class="bi bi-people"></i> Matriculación Masiva
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-cursos">
                    <i class="bi bi-list"></i> Cursos Moodle
                </a>
            </li>
        </ul>
        
        <div class="tab-content">
            
            <!-- Tab Individual -->
            <div class="tab-pane fade show active" id="tab-individual">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0">Crear Usuario y Matricular</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="accion" value="crear_individual">
                                    
                                    <div class="mb-3">
                                        <label>Alumno del CRM</label>
                                        <select class="form-select" id="selectAlumno">
                                            <option value="">-- Seleccionar alumno --</option>
                                            <?php foreach ($cursosCRM as $c): ?>
                                            <option value='<?= htmlspecialchars(json_encode($c)) ?>'>
                                                <?= htmlspecialchars($c['nombre_alumno']) ?> - <?= htmlspecialchars($c['nombre_curso']) ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <hr>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label>Nombre <span class="text-danger">*</span></label>
                                            <input type="text" name="firstname" id="firstname" class="form-control" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label>Apellidos <span class="text-danger">*</span></label>
                                            <input type="text" name="lastname" id="lastname" class="form-control" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label>Email <span class="text-danger">*</span></label>
                                        <input type="email" name="email" id="email" class="form-control" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label>Curso Moodle <span class="text-danger">*</span></label>
                                        <select name="courseid" class="form-select" required>
                                            <option value="">-- Seleccionar curso --</option>
                                            <?php if ($cursosMoodle['success']): ?>
                                                <?php foreach ($cursosMoodle['data'] as $curso): ?>
                                                <option value="<?= $curso['id'] ?>">
                                                    <?= htmlspecialchars($curso['nombre']) ?>
                                                </option>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    
                                    <input type="hidden" name="id_curso_crm" id="id_curso_crm">
                                    
                                    <div class="alert alert-info">
                                        <small>
                                            <i class="bi bi-info-circle"></i>
                                            El usuario y contraseña se generarán automáticamente y se enviarán por email.
                                        </small>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary btn-lg w-100">
                                        <i class="bi bi-send"></i> Crear, Matricular y Enviar Credenciales
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">Alumnos Pendientes de Matricular</h6>
                            </div>
                            <div class="card-body" style="max-height: 500px; overflow-y: auto;">
                                <?php if (empty($cursosCRM)): ?>
                                <p class="text-muted">No hay alumnos pendientes</p>
                                <?php else: ?>
                                <div class="list-group">
                                    <?php foreach ($cursosCRM as $c): ?>
                                    <div class="list-group-item">
                                        <strong><?= htmlspecialchars($c['nombre_alumno']) ?></strong><br>
                                        <small class="text-muted">
                                            <?= htmlspecialchars($c['nombre_curso']) ?><br>
                                            📧 <?= htmlspecialchars($c['email_alumno']) ?>
                                        </small>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Tab Masiva -->
            <div class="tab-pane fade" id="tab-masiva">
                <div class="card">
                    <div class="card-body">
                        <h5>Matriculación Masiva</h5>
                        <p class="text-muted">Próximamente: Seleccionar múltiples alumnos y matricularlos automáticamente</p>
                    </div>
                </div>
            </div>
            
            <!-- Tab Cursos -->
            <div class="tab-pane fade" id="tab-cursos">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Cursos Disponibles en Moodle</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!$cursosMoodle['success']): ?>
                        <div class="alert alert-danger">
                            Error al obtener cursos: <?= htmlspecialchars($cursosMoodle['error']) ?>
                        </div>
                        <?php else: ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Shortname</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cursosMoodle['data'] as $curso): ?>
                                <tr>
                                    <td><?= $curso['id'] ?></td>
                                    <td><?= htmlspecialchars($curso['nombre']) ?></td>
                                    <td><code><?= htmlspecialchars($curso['shortname']) ?></code></td>
                                    <td>
                                        <?php if ($curso['visible']): ?>
                                        <span class="badge bg-success">Visible</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Oculto</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
        </div>
        
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Autocompletar con datos del alumno seleccionado
        $('#selectAlumno').on('change', function() {
            if ($(this).val()) {
                const alumno = JSON.parse($(this).val());
                const nombres = alumno.nombre_alumno.split(' ');
                const firstname = nombres[0];
                const lastname = nombres.slice(1).join(' ');
                
                $('#firstname').val(firstname);
                $('#lastname').val(lastname);
                $('#email').val(alumno.email_alumno);
                $('#id_curso_crm').val(alumno.id);
            }
        });
    });
    </script>
</body>
</html>
