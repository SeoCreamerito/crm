<?php
/**
 * AJAX ENDPOINT: DataTable de Cursos
 * Ubicación: /admin/cursos/ajax/cursos_datatable.php
 * 
 * Alimenta la tabla de cursos con datos, filtros y búsqueda
 */

// CRÍTICO: Desactivar error_handler para AJAX
define('AJAX_MODE', true);

// Limpiar cualquier output previo
if (ob_get_level()) {
    ob_end_clean();
}

// Iniciar buffer limpio
ob_start();

// Silenciar TODOS los errores para que no contaminen el JSON
error_reporting(0);
ini_set('display_errors', 0);

require_once '../../../includes/config.php';

// Verificar autenticación
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Verificar rol
if (!in_array($_SESSION['rol'], ['admin', 'gestion_cursos'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Acceso denegado']);
    exit;
}

header('Content-Type: application/json');

// Parámetros de DataTables
$draw = isset($_GET['draw']) ? intval($_GET['draw']) : 1;
$start = isset($_GET['start']) ? intval($_GET['start']) : 0;
$length = isset($_GET['length']) ? intval($_GET['length']) : 10;
$searchValue = isset($_GET['search']['value']) ? $_GET['search']['value'] : '';

// Filtros adicionales
$filtroEstado = isset($_GET['estado']) ? $_GET['estado'] : '';
$filtroGestor = isset($_GET['gestor']) ? intval($_GET['gestor']) : 0;
$filtroFechaDesde = isset($_GET['fecha_desde']) ? $_GET['fecha_desde'] : '';
$filtroFechaHasta = isset($_GET['fecha_hasta']) ? $_GET['fecha_hasta'] : '';

// Orden
$orderColumnIndex = isset($_GET['order'][0]['column']) ? intval($_GET['order'][0]['column']) : 0;
$orderDir = isset($_GET['order'][0]['dir']) ? $_GET['order'][0]['dir'] : 'DESC';

// Mapeo de columnas para ordenamiento
$columns = [
    0 => 'l.id',
    1 => 'l.empresa',
    2 => 'l.nombre_curso',
    3 => 'l.nombre_alumno',
    4 => 'l.fecha_inicio',
    5 => 'l.estado_curso',
    6 => 'l.fecha_alta_curso'
];

$orderColumn = isset($columns[$orderColumnIndex]) ? $columns[$orderColumnIndex] : 'l.id';

// Construir query base
$sqlBase = "FROM leads_activos l
            LEFT JOIN usuarios u ON l.id_gestor = u.id
            WHERE l.nombre_curso IS NOT NULL";

$params = [];
$types = '';

// Aplicar filtros
if (!empty($searchValue)) {
    $sqlBase .= " AND (
        l.empresa LIKE ? OR
        l.nombre_curso LIKE ? OR
        l.nombre_alumno LIKE ? OR
        l.dni_alumno LIKE ? OR
        l.email LIKE ?
    )";
    $searchParam = "%$searchValue%";
    $params = array_merge($params, [$searchParam, $searchParam, $searchParam, $searchParam, $searchParam]);
    $types .= 'sssss';
}

if (!empty($filtroEstado)) {
    $sqlBase .= " AND l.estado_curso = ?";
    $params[] = $filtroEstado;
    $types .= 's';
}

if ($filtroGestor > 0) {
    $sqlBase .= " AND l.id_gestor = ?";
    $params[] = $filtroGestor;
    $types .= 'i';
}

if (!empty($filtroFechaDesde)) {
    $sqlBase .= " AND l.fecha_inicio >= ?";
    $params[] = $filtroFechaDesde;
    $types .= 's';
}

if (!empty($filtroFechaHasta)) {
    $sqlBase .= " AND l.fecha_inicio <= ?";
    $params[] = $filtroFechaHasta;
    $types .= 's';
}

// Contar registros totales
$sqlCount = "SELECT COUNT(*) as total " . $sqlBase;
$stmtCount = $conn->prepare($sqlCount);

if (!empty($params)) {
    $stmtCount->bind_param($types, ...$params);
}

$stmtCount->execute();
$resultCount = $stmtCount->get_result();
$totalFiltered = $resultCount->fetch_assoc()['total'];
$stmtCount->close();

// Contar registros sin filtro
$sqlTotalRecords = "SELECT COUNT(*) as total FROM leads_activos WHERE nombre_curso IS NOT NULL";
$resultTotal = $conn->query($sqlTotalRecords);
$totalRecords = $resultTotal->fetch_assoc()['total'];

// Obtener datos
$sqlData = "SELECT 
    l.id,
    l.empresa,
    l.CIF,
    l.email,
    l.nombre_curso,
    l.codigo_curso,
    l.horas_curso,
    l.credito_formacion,
    l.nombre_alumno,
    l.dni_alumno,
    l.telefono_alumno,
    l.email_alumno,
    l.fecha_inicio,
    l.fecha_fin,
    l.estado_curso,
    l.id_gestor,
    l.fecha_alta_curso,
    l.nombre_asesoria,
    l.envio_claves,
    l.fecha_envio_claves,
    u.nombre as gestor_nombre,
    u.apellidos as gestor_apellidos
    " . $sqlBase . "
    ORDER BY $orderColumn $orderDir
    LIMIT ? OFFSET ?";

$params[] = $length;
$params[] = $start;
$types .= 'ii';

$stmtData = $conn->prepare($sqlData);

if (!empty($params)) {
    $stmtData->bind_param($types, ...$params);
}

$stmtData->execute();
$result = $stmtData->get_result();

$data = [];

while ($row = $result->fetch_assoc()) {
    // Badge de estado
    $estadoBadges = [
        'pendiente' => '<span class="badge bg-warning">Pendiente</span>',
        'en_proceso' => '<span class="badge bg-info">En Proceso</span>',
        'completado' => '<span class="badge bg-success">Completado</span>',
        'cancelado' => '<span class="badge bg-danger">Cancelado</span>'
    ];
    
    $estadoBadge = $estadoBadges[$row['estado_curso']] ?? '<span class="badge bg-secondary">Sin estado</span>';
    
    // Gestor asignado
    $gestor = ($row['gestor_nombre']) 
        ? $row['gestor_nombre'] . ' ' . $row['gestor_apellidos']
        : '<span class="text-muted">Sin asignar</span>';
    
    // Fecha de inicio formateada
    $fechaInicio = $row['fecha_inicio'] 
        ? date('d/m/Y', strtotime($row['fecha_inicio']))
        : '<span class="text-muted">-</span>';
    
    // Envío de claves
    $claves = $row['envio_claves'] 
        ? '<i class="bi bi-check-circle-fill text-success" title="Claves enviadas"></i>'
        : '<i class="bi bi-x-circle text-muted" title="Sin enviar"></i>';
    
    // Botones de acción
    $acciones = '
        <div class="btn-group btn-group-sm" role="group">
            <button type="button" 
                    class="btn btn-outline-primary btn-ver-detalle" 
                    data-id="' . $row['id'] . '"
                    title="Ver detalle">
                <i class="bi bi-eye"></i>
            </button>
            <button type="button" 
                    class="btn btn-outline-secondary btn-editar" 
                    data-id="' . $row['id'] . '"
                    title="Editar">
                <i class="bi bi-pencil"></i>
            </button>
        </div>
    ';
    
    $data[] = [
        'id' => $row['id'],
        'empresa' => htmlspecialchars($row['empresa'] ?? ''),
        'nombre_curso' => htmlspecialchars($row['nombre_curso'] ?? ''),
        'alumno' => htmlspecialchars($row['nombre_alumno'] ?? ''),
        'dni_alumno' => htmlspecialchars($row['dni_alumno'] ?? ''),
        'fecha_inicio' => $fechaInicio,
        'estado' => $estadoBadge,
        'gestor' => $gestor,
        'claves' => $claves,
        'acciones' => $acciones
    ];
}

$stmtData->close();

// Respuesta JSON para DataTables
$response = [
    'draw' => $draw,
    'recordsTotal' => $totalRecords,
    'recordsFiltered' => $totalFiltered,
    'data' => $data
];

// Limpiar el buffer y asegurar que solo se envía JSON
ob_clean();

// Establecer header JSON
header('Content-Type: application/json; charset=utf-8');

// Enviar JSON
echo json_encode($response);

// Limpiar y terminar
ob_end_flush();
exit;
?>
