<?php
/**
 * IMPORTADOR SIMPLE DE CURSOS DESDE CSV
 * Ubicación: /admin/cursos/importar_cursos_excel.php
 */

error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', 0);

require_once '../../includes/config.php';

// Verificar sesión y rol
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../../auth/login.php');
    exit;
}

if (!in_array($_SESSION['rol'], ['admin', 'gestion_cursos'])) {
    die('Acceso denegado.');
}

$mensaje = '';
$tipo_mensaje = '';
$registros_importados = 0;
$registros_errores = 0;
$errores_detalle = [];

// Procesar archivo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['archivo'])) {
    $archivo = $_FILES['archivo'];
    
    if ($archivo['error'] !== UPLOAD_ERR_OK) {
        $mensaje = 'Error al subir el archivo';
        $tipo_mensaje = 'danger';
    } else {
        $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        
        if (!in_array($extension, ['csv', 'txt'])) {
            $mensaje = 'Solo archivos CSV. Convierte tu Excel primero.';
            $tipo_mensaje = 'warning';
        } else {
            $resultado = procesarCSV($archivo['tmp_name'], $conn);
            $registros_importados = $resultado['importados'];
            $registros_errores = $resultado['errores'];
            $errores_detalle = $resultado['errores_detalle'];
            
            if ($registros_importados > 0) {
                $mensaje = "✅ $registros_importados importados" . ($registros_errores > 0 ? ", $registros_errores errores" : "");
                $tipo_mensaje = 'success';
            } else {
                $mensaje = "⚠️ 0 importados, $registros_errores errores";
                $tipo_mensaje = 'warning';
            }
        }
    }
}

function procesarCSV($archivo, $conn) {
    $datos = [];
    if (($handle = fopen($archivo, 'r')) !== FALSE) {
        fgetcsv($handle, 10000, ','); // Skip header
        while (($data = fgetcsv($handle, 10000, ',')) !== FALSE) {
            $datos[] = $data;
        }
        fclose($handle);
    }
    return importarDatos($datos, $conn);
}

function limpiarTelefono($tel) {
    if (empty($tel)) return null;
    $tel = (string)$tel;
    if (strpos($tel, '/') !== false) {
        $tel = explode('/', $tel)[0];
    }
    return preg_replace('/[^0-9+]/', '', trim($tel));
}

function limpiarFecha($fecha) {
    if (empty($fecha)) return null;
    $ts = strtotime(str_replace('/', '-', $fecha));
    return $ts ? date('Y-m-d', $ts) : null;
}

function importarDatos($datos, $conn) {
    $importados = 0;
    $errores = 0;
    $errores_detalle = [];
    
    foreach ($datos as $i => $f) {
        $fila = $i + 2;
        
        $empresa = trim($f[0] ?? '');
        $nombre_curso = trim($f[3] ?? '');
        $nombre_alumno = trim($f[7] ?? '');
        $dni_alumno = trim($f[8] ?? '');
        
        if (empty($empresa) || empty($nombre_curso) || empty($nombre_alumno) || empty($dni_alumno)) {
            $errores++;
            $errores_detalle[] = "Fila $fila: Faltan campos obligatorios";
            continue;
        }
        
        $sql = "INSERT INTO leads_activos (
            empresa, CIF, email, nombre_curso, codigo_curso, horas_curso, credito_formacion,
            nombre_alumno, dni_alumno, telefono_alumno, email_alumno,
            fecha_inicio, fecha_fin, nombre_asesoria, telefono_asesoria, email_asesoria,
            estado_curso, fecha_alta_curso, id_teleoperadora, verificado
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pendiente', NOW(), NULL, 1)";
        
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $errores++;
            continue;
        }
        
        $cif = trim($f[1] ?? '');
        $email = trim($f[2] ?? '');
        $codigo = trim($f[4] ?? '');
        $horas = !empty($f[5]) ? (int)$f[5] : null;
        $credito = !empty($f[6]) ? (float)str_replace(',', '.', $f[6]) : null;
        $tel_alumno = limpiarTelefono($f[9] ?? '');
        $email_alumno = trim($f[10] ?? '');
        $f_inicio = limpiarFecha($f[11] ?? '');
        $f_fin = limpiarFecha($f[12] ?? '');
        $asesoria = trim($f[13] ?? '');
        $tel_ases = limpiarTelefono($f[14] ?? '');
        $email_ases = trim($f[15] ?? '');
        
        $stmt->bind_param("sssssidsssssssss",
            $empresa, $cif, $email, $nombre_curso, $codigo, $horas, $credito,
            $nombre_alumno, $dni_alumno, $tel_alumno, $email_alumno,
            $f_inicio, $f_fin, $asesoria, $tel_ases, $email_ases
        );
        
        if ($stmt->execute()) {
            $importados++;
        } else {
            $errores++;
            $errores_detalle[] = "Fila $fila: " . $stmt->error;
        }
        $stmt->close();
    }
    
    return [
        'importados' => $importados,
        'errores' => $errores,
        'errores_detalle' => array_slice($errores_detalle, 0, 20)
    ];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Importar Cursos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-light">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="bg-white border-bottom">
        <div class="container py-3">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="../dashboard.php"><i class="bi bi-house-door"></i> Dashboard</a></li>
                <li class="breadcrumb-item"><a href="gestion_cursos.php">Gestión de Cursos</a></li>
                <li class="breadcrumb-item active">Importar CSV</li>
            </ol>
        </div>
    </nav>
    
    <div class="container py-4">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4><i class="bi bi-file-earmark-excel"></i> Importar Cursos (CSV)</h4>
            </div>
            <div class="card-body">
                <?php if ($mensaje): ?>
                <div class="alert alert-<?= $tipo_mensaje ?>">
                    <?= $mensaje ?>
                </div>
                <?php endif; ?>
                
                <?php if ($errores_detalle): ?>
                <div class="alert alert-warning">
                    <h6>Errores:</h6>
                    <ul class="mb-0"><?php foreach ($errores_detalle as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?></ul>
                </div>
                <?php endif; ?>
                
                <div class="alert alert-info">
                    <strong>1. Convierte tu Excel a CSV:</strong><br>
                    Excel → Guardar como → CSV (delimitado por comas)<br><br>
                    <strong>2. Columnas (en orden):</strong><br>
                    Empresa, CIF, Email, Nombre Curso, Código, Horas, Crédito,
                    Alumno, DNI Alumno, Tel Alumno, Email Alumno,
                    Fecha Inicio, Fecha Fin, Asesoría, Tel Asesoría, Email Asesoría
                </div>
                
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label>Archivo CSV:</label>
                        <input type="file" name="archivo" class="form-control" accept=".csv" required>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-upload"></i> Importar
                    </button>
                    <a href="gestion_cursos.php" class="btn btn-secondary">Volver</a>
                </form>
            </div>
        </div>
        
        <?php if ($registros_importados || $registros_errores): ?>
        <div class="card shadow mt-3">
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-6">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <h2><?= $registros_importados ?></h2>
                                <p>Importados</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card bg-warning">
                            <div class="card-body">
                                <h2><?= $registros_errores ?></h2>
                                <p>Errores</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
