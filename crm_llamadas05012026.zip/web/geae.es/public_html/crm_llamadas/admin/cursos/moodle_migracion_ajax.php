<?php
/**
 * MIGRACIÓN DE CURSOS VÍA WEB CON AJAX
 * Ubicación: /admin/cursos/moodle_migracion.php
 * 
 * Optimizado para funcionar sin SSH con procesamiento AJAX
 */

error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', 0);

require_once '../../includes/config.php';
require_once '../../includes/MoodleAPI.php';

// Verificar sesión
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../../auth/login.php');
    exit;
}

if (!in_array($_SESSION['rol'], ['admin'])) {
    die('Acceso denegado - Solo administradores');
}

// ============================================================================
// API AJAX ENDPOINT
// ============================================================================

if (isset($_GET['ajax']) && $_GET['ajax'] === 'migrar_curso') {
    header('Content-Type: application/json');
    
    $cursoId = intval($_POST['curso_id'] ?? 0);
    $origenUrl = $_POST['origen_url'] ?? '';
    $origenToken = $_POST['origen_token'] ?? '';
    $categoriaDestino = intval($_POST['categoria_destino'] ?? 1);
    
    if (!$cursoId || !$origenUrl || !$origenToken) {
        echo json_encode([
            'success' => false,
            'error' => 'Parámetros incompletos'
        ]);
        exit;
    }
    
    try {
        $migrator = new MoodleMigratorWeb(
            $origenUrl,
            $origenToken,
            'https://www.geae.es/plataforma',
            '580bed506280fbd3e81fa180dfaafc00'
        );
        
        $migrator->setConfig('categoria_destino', $categoriaDestino);
        $resultado = $migrator->migrarCurso($cursoId);
        
        echo json_encode($resultado);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    
    exit;
}

if (isset($_GET['ajax']) && $_GET['ajax'] === 'obtener_cursos') {
    header('Content-Type: application/json');
    
    $origenUrl = $_POST['origen_url'] ?? '';
    $origenToken = $_POST['origen_token'] ?? '';
    
    try {
        $api = $origenUrl . '/webservice/rest/server.php';
        $params = [
            'wstoken' => $origenToken,
            'wsfunction' => 'core_course_get_courses',
            'moodlewsrestformat' => 'json'
        ];
        
        $ch = curl_init($api);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $cursos = json_decode($response, true);
        
        if (isset($cursos['exception'])) {
            throw new Exception($cursos['message'] ?? 'Error al obtener cursos');
        }
        
        // Filtrar sitio principal
        $cursosFiltrados = [];
        foreach ($cursos as $curso) {
            if ($curso['id'] != 1) {
                $cursosFiltrados[] = [
                    'id' => $curso['id'],
                    'fullname' => $curso['fullname'],
                    'shortname' => $curso['shortname']
                ];
            }
        }
        
        echo json_encode([
            'success' => true,
            'cursos' => $cursosFiltrados
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    
    exit;
}

// ============================================================================
// CLASE MIGRADOR OPTIMIZADA PARA WEB
// ============================================================================

class MoodleMigratorWeb {
    private $origenUrl;
    private $origenToken;
    private $destinoUrl;
    private $destinoToken;
    private $config;
    
    public function __construct($origenUrl, $origenToken, $destinoUrl, $destinoToken) {
        $this->origenUrl = rtrim($origenUrl, '/');
        $this->origenToken = $origenToken;
        $this->destinoUrl = rtrim($destinoUrl, '/');
        $this->destinoToken = $destinoToken;
        
        $this->config = [
            'categoria_destino' => 1,
            'timeout' => 120
        ];
        
        // Aumentar límites PHP
        set_time_limit(300);
        ini_set('max_execution_time', 300);
    }
    
    public function setConfig($key, $value) {
        $this->config[$key] = $value;
    }
    
    public function migrarCurso($cursoId) {
        $log = [];
        
        try {
            // PASO 1: Obtener info del curso
            $this->addLog($log, 'Obteniendo información del curso...');
            $cursoInfo = $this->getCursoInfo($cursoId);
            
            if (!$cursoInfo) {
                throw new Exception('Curso no encontrado');
            }
            
            $this->addLog($log, "Curso: {$cursoInfo['fullname']}");
            
            // PASO 2: Duplicar en origen (más rápido que backup)
            $this->addLog($log, 'Duplicando curso en origen...');
            $duplicado = $this->duplicarCurso($cursoId, $cursoInfo);
            
            if (!$duplicado) {
                throw new Exception('Error al duplicar curso');
            }
            
            $this->addLog($log, 'Curso duplicado correctamente');
            
            // PASO 3: Crear curso vacío en destino
            $this->addLog($log, 'Creando curso en destino...');
            $cursoDestino = $this->crearCursoDestino($cursoInfo);
            
            if (!$cursoDestino) {
                throw new Exception('Error al crear curso en destino');
            }
            
            $cursoDestinoId = $cursoDestino['id'];
            $this->addLog($log, "Curso creado en destino (ID: $cursoDestinoId)");
            
            // PASO 4: Importar contenido
            $this->addLog($log, 'Importando contenido...');
            $importado = $this->importarContenido($duplicado['id'], $cursoDestinoId);
            
            if (!$importado) {
                throw new Exception('Error al importar contenido');
            }
            
            $this->addLog($log, 'Contenido importado correctamente');
            
            // PASO 5: Hacer visible
            $this->hacerVisible($cursoDestinoId);
            $this->addLog($log, 'Curso activado y visible');
            
            return [
                'success' => true,
                'curso_origen_id' => $cursoId,
                'curso_destino_id' => $cursoDestinoId,
                'url' => $this->destinoUrl . '/course/view.php?id=' . $cursoDestinoId,
                'log' => $log
            ];
            
        } catch (Exception $e) {
            $this->addLog($log, 'ERROR: ' . $e->getMessage());
            
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'log' => $log
            ];
        }
    }
    
    private function getCursoInfo($cursoId) {
        $response = $this->callAPI($this->origenUrl, $this->origenToken, 
            'core_course_get_courses', [
                'options' => ['ids' => [$cursoId]]
            ]
        );
        
        return $response[0] ?? null;
    }
    
    private function duplicarCurso($cursoId, $cursoInfo) {
        $response = $this->callAPI($this->origenUrl, $this->origenToken,
            'core_course_duplicate_course', [
                'courseid' => $cursoId,
                'fullname' => $cursoInfo['fullname'] . ' (TEMP)',
                'shortname' => $cursoInfo['shortname'] . '_temp_' . time(),
                'categoryid' => $cursoInfo['categoryid'],
                'visible' => 0,
                'options' => [
                    ['name' => 'activities', 'value' => 1],
                    ['name' => 'blocks', 'value' => 1],
                    ['name' => 'filters', 'value' => 1],
                    ['name' => 'users', 'value' => 0],
                    ['name' => 'role_assignments', 'value' => 0]
                ]
            ]
        );
        
        return $response;
    }
    
    private function crearCursoDestino($cursoInfo) {
        $response = $this->callAPI($this->destinoUrl, $this->destinoToken,
            'core_course_create_courses', [
                'courses' => [[
                    'fullname' => $cursoInfo['fullname'],
                    'shortname' => $cursoInfo['shortname'] . '_' . time(),
                    'categoryid' => $this->config['categoria_destino'],
                    'summary' => $cursoInfo['summary'] ?? '',
                    'summaryformat' => 1,
                    'visible' => 0
                ]]
            ]
        );
        
        return $response[0] ?? null;
    }
    
    private function importarContenido($origenId, $destinoId) {
        // Usar la función de importación de Moodle
        $response = $this->callAPI($this->destinoUrl, $this->destinoToken,
            'core_course_import_course', [
                'importfrom' => $origenId,
                'importto' => $destinoId,
                'deletecontent' => 1
            ]
        );
        
        return isset($response['success']) ? $response['success'] : false;
    }
    
    private function hacerVisible($cursoId) {
        $this->callAPI($this->destinoUrl, $this->destinoToken,
            'core_course_update_courses', [
                'courses' => [[
                    'id' => $cursoId,
                    'visible' => 1
                ]]
            ]
        );
    }
    
    private function callAPI($baseUrl, $token, $function, $params = []) {
        $apiUrl = $baseUrl . '/webservice/rest/server.php';
        
        $params['wstoken'] = $token;
        $params['wsfunction'] = $function;
        $params['moodlewsrestformat'] = 'json';
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->config['timeout']);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new Exception("Error CURL: $error");
        }
        
        $result = json_decode($response, true);
        
        if (isset($result['exception'])) {
            throw new Exception($result['message'] ?? 'Error desconocido');
        }
        
        return $result;
    }
    
    private function addLog(&$log, $mensaje) {
        $log[] = [
            'time' => date('H:i:s'),
            'message' => $mensaje
        ];
    }
}

// ============================================================================
// HTML INTERFACE
// ============================================================================

// Obtener categorías destino
$moodleDestino = new MoodleAPI($conn);
$categoriasDestino = [];

$mensaje = '';
$tipo_mensaje = '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Migración de Cursos - CRM GEAE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        .migration-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .curso-card {
            transition: all 0.3s;
            cursor: pointer;
            border: 2px solid transparent;
        }
        .curso-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .curso-card.selected {
            border-color: #667eea;
            background-color: #f8f9ff;
        }
        .log-console {
            background: #1e1e1e;
            color: #00ff00;
            padding: 15px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            max-height: 300px;
            overflow-y: auto;
            margin-top: 10px;
        }
        .progress-item {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            background: #f8f9fa;
        }
        .progress-item.success {
            border-color: #28a745;
            background: #d4edda;
        }
        .progress-item.error {
            border-color: #dc3545;
            background: #f8d7da;
        }
        .progress-item.processing {
            border-color: #ffc107;
            background: #fff3cd;
        }
        .spinner-border-sm {
            width: 1rem;
            height: 1rem;
        }
    </style>
</head>
<body class="bg-light">
    
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="bg-white border-bottom">
        <div class="container-fluid py-2">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="../dashboard.php"><i class="bi bi-house-door"></i> Dashboard</a></li>
                <li class="breadcrumb-item"><a href="moodle_gestion.php">Moodle</a></li>
                <li class="breadcrumb-item active">Migración de Cursos</li>
            </ol>
        </div>
    </nav>
    
    <div class="container-fluid mt-4 mb-5">
        
        <!-- Header -->
        <div class="migration-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2><i class="bi bi-arrow-left-right"></i> Migración de Cursos</h2>
                    <p class="mb-0">Importar cursos desde otra plataforma Moodle vía Web</p>
                </div>
                <div>
                    <a href="moodle_gestion.php" class="btn btn-light">
                        <i class="bi bi-arrow-left"></i> Volver
                    </a>
                </div>
            </div>
        </div>
        
        <!-- PASO 1: Configuración -->
        <div class="card mb-4" id="paso1">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <span class="badge bg-white text-primary me-2">1</span>
                    Configuración del Moodle Origen
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-5">
                        <label class="form-label">URL Moodle Origen</label>
                        <input type="url" id="origenUrl" class="form-control" 
                               placeholder="https://moodle-anterior.com" required>
                        <small class="text-muted">Sin / al final</small>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Token API Origen</label>
                        <input type="text" id="origenToken" class="form-control" 
                               placeholder="abc123xyz..." required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">&nbsp;</label>
                        <button type="button" class="btn btn-success w-100" onclick="conectarOrigen()">
                            <i class="bi bi-plug"></i> Conectar
                        </button>
                    </div>
                </div>
                
                <div class="alert alert-info mt-3 mb-0">
                    <strong><i class="bi bi-info-circle"></i> Permisos requeridos:</strong>
                    core_course_get_courses, core_course_duplicate_course
                </div>
            </div>
        </div>
        
        <!-- PASO 2: Selección de Cursos -->
        <div class="card mb-4" id="paso2" style="display:none;">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">
                    <span class="badge bg-white text-success me-2">2</span>
                    Selección de Cursos
                </h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-8">
                        <input type="text" class="form-control" id="buscarCurso" 
                               placeholder="🔍 Buscar curso...">
                    </div>
                    <div class="col-md-4">
                        <select class="form-select" id="categoriaDestino">
                            <option value="1">Categoría: Miscellaneous</option>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="seleccionarTodos()">
                        <i class="bi bi-check-all"></i> Todos
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="deseleccionarTodos()">
                        <i class="bi bi-x"></i> Ninguno
                    </button>
                    <span class="ms-3 text-muted" id="contadorSeleccion">0 cursos seleccionados</span>
                </div>
                
                <div class="row" id="listaCursos">
                    <!-- Se llena dinámicamente -->
                </div>
                
                <hr>
                
                <button type="button" class="btn btn-primary btn-lg w-100" onclick="iniciarMigracion()">
                    <i class="bi bi-cloud-download"></i> Iniciar Migración
                </button>
            </div>
        </div>
        
        <!-- PASO 3: Progreso -->
        <div class="card" id="paso3" style="display:none;">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0">
                    <span class="badge bg-dark me-2">3</span>
                    Migración en Proceso
                </h5>
            </div>
            <div class="card-body">
                <div class="progress mb-3" style="height: 30px;">
                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-success" 
                         id="barraProgreso" 
                         role="progressbar" 
                         style="width: 0%">
                        <span id="textoProgreso">0%</span>
                    </div>
                </div>
                
                <div id="listaProgreso">
                    <!-- Se llena dinámicamente -->
                </div>
                
                <div class="text-center mt-3" id="btnFinalizar" style="display:none;">
                    <button type="button" class="btn btn-success btn-lg" onclick="location.reload()">
                        <i class="bi bi-check-circle"></i> Finalizar
                    </button>
                </div>
            </div>
        </div>
        
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    let cursosOrigen = [];
    let cursosSeleccionados = [];
    let migracionEnProceso = false;
    
    // Conectar al Moodle origen
    function conectarOrigen() {
        const url = $('#origenUrl').val().trim();
        const token = $('#origenToken').val().trim();
        
        if (!url || !token) {
            alert('Complete todos los campos');
            return;
        }
        
        // Mostrar loading
        const btn = event.target;
        const originalHTML = btn.innerHTML;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Conectando...';
        btn.disabled = true;
        
        $.ajax({
            url: '?ajax=obtener_cursos',
            method: 'POST',
            data: {
                origen_url: url,
                origen_token: token
            },
            success: function(response) {
                btn.innerHTML = originalHTML;
                btn.disabled = false;
                
                if (response.success) {
                    cursosOrigen = response.cursos;
                    mostrarCursos();
                    $('#paso1').fadeOut(300, function() {
                        $('#paso2').fadeIn(300);
                    });
                } else {
                    alert('Error: ' + response.error);
                }
            },
            error: function() {
                btn.innerHTML = originalHTML;
                btn.disabled = false;
                alert('Error de conexión');
            }
        });
    }
    
    // Mostrar cursos
    function mostrarCursos() {
        const html = cursosOrigen.map(curso => `
            <div class="col-md-6 mb-3 curso-item" data-id="${curso.id}">
                <div class="card curso-card" onclick="toggleCurso(${curso.id})">
                    <div class="card-body">
                        <div class="form-check">
                            <input class="form-check-input curso-checkbox" 
                                   type="checkbox" 
                                   value="${curso.id}" 
                                   id="curso_${curso.id}"
                                   onchange="actualizarContador()">
                            <label class="form-check-label w-100" for="curso_${curso.id}">
                                <strong>${curso.fullname}</strong><br>
                                <small class="text-muted">
                                    <code>${curso.shortname}</code>
                                </small>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
        
        $('#listaCursos').html(html);
    }
    
    // Toggle selección
    function toggleCurso(id) {
        const checkbox = $('#curso_' + id);
        checkbox.prop('checked', !checkbox.prop('checked'));
        checkbox.closest('.curso-card').toggleClass('selected', checkbox.prop('checked'));
        actualizarContador();
    }
    
    // Actualizar contador
    function actualizarContador() {
        const count = $('.curso-checkbox:checked').length;
        $('#contadorSeleccion').text(count + ' curso(s) seleccionado(s)');
    }
    
    // Seleccionar todos
    function seleccionarTodos() {
        $('.curso-checkbox').prop('checked', true);
        $('.curso-card').addClass('selected');
        actualizarContador();
    }
    
    // Deseleccionar todos
    function deseleccionarTodos() {
        $('.curso-checkbox').prop('checked', false);
        $('.curso-card').removeClass('selected');
        actualizarContador();
    }
    
    // Buscar cursos
    $('#buscarCurso').on('keyup', function() {
        const valor = $(this).val().toLowerCase();
        $('.curso-item').each(function() {
            const texto = $(this).text().toLowerCase();
            $(this).toggle(texto.indexOf(valor) > -1);
        });
    });
    
    // Iniciar migración
    function iniciarMigracion() {
        cursosSeleccionados = [];
        $('.curso-checkbox:checked').each(function() {
            cursosSeleccionados.push(parseInt($(this).val()));
        });
        
        if (cursosSeleccionados.length === 0) {
            alert('Debe seleccionar al menos un curso');
            return;
        }
        
        if (!confirm(`¿Iniciar migración de ${cursosSeleccionados.length} curso(s)?`)) {
            return;
        }
        
        migracionEnProceso = true;
        $('#paso2').fadeOut(300, function() {
            $('#paso3').fadeIn(300);
            procesarMigracion();
        });
    }
    
    // Procesar migración curso por curso
    async function procesarMigracion() {
        const total = cursosSeleccionados.length;
        let completados = 0;
        let exitosos = 0;
        let errores = 0;
        
        for (let i = 0; i < cursosSeleccionados.length; i++) {
            const cursoId = cursosSeleccionados[i];
            const curso = cursosOrigen.find(c => c.id === cursoId);
            
            // Agregar item de progreso
            const itemId = 'progreso_' + cursoId;
            $('#listaProgreso').append(`
                <div class="progress-item processing" id="${itemId}">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <strong>${curso.fullname}</strong>
                        <span class="spinner-border spinner-border-sm"></span>
                    </div>
                    <div class="log-console" id="log_${cursoId}">
                        Iniciando migración...
                    </div>
                </div>
            `);
            
            // Scroll al item
            $('#' + itemId)[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // Ejecutar migración
            try {
                const resultado = await migrarCurso(cursoId);
                
                if (resultado.success) {
                    exitosos++;
                    $('#' + itemId).removeClass('processing').addClass('success');
                    $('#' + itemId + ' .spinner-border').replaceWith(`
                        <span class="badge bg-success">✓ ÉXITO</span>
                    `);
                    
                    // Agregar enlace
                    $('#log_' + cursoId).append(`
                        <div style="color: #00ff00; margin-top: 10px;">
                            ✅ Curso migrado correctamente<br>
                            <a href="${resultado.url}" target="_blank" style="color: #00d4ff;">
                                Ver curso en GEAE →
                            </a>
                        </div>
                    `);
                } else {
                    errores++;
                    $('#' + itemId).removeClass('processing').addClass('error');
                    $('#' + itemId + ' .spinner-border').replaceWith(`
                        <span class="badge bg-danger">✗ ERROR</span>
                    `);
                }
                
            } catch (error) {
                errores++;
                $('#' + itemId).removeClass('processing').addClass('error');
                $('#' + itemId + ' .spinner-border').replaceWith(`
                    <span class="badge bg-danger">✗ ERROR</span>
                `);
                $('#log_' + cursoId).append(`
                    <div style="color: #ff6b6b;">ERROR: ${error.message}</div>
                `);
            }
            
            // Actualizar progreso
            completados++;
            const porcentaje = Math.round((completados / total) * 100);
            $('#barraProgreso').css('width', porcentaje + '%');
            $('#textoProgreso').text(`${porcentaje}% (${completados}/${total})`);
            
            // Pausa entre cursos
            if (i < cursosSeleccionados.length - 1) {
                await sleep(2000);
            }
        }
        
        // Finalizar
        $('#barraProgreso').removeClass('progress-bar-animated');
        $('#textoProgreso').text(`Completado: ${exitosos} exitosos, ${errores} errores`);
        
        if (errores === 0) {
            $('#barraProgreso').removeClass('bg-success').addClass('bg-success');
        } else if (exitosos === 0) {
            $('#barraProgreso').removeClass('bg-success').addClass('bg-danger');
        } else {
            $('#barraProgreso').removeClass('bg-success').addClass('bg-warning');
        }
        
        $('#btnFinalizar').fadeIn();
        migracionEnProceso = false;
    }
    
    // Migrar un curso individual
    function migrarCurso(cursoId) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: '?ajax=migrar_curso',
                method: 'POST',
                data: {
                    curso_id: cursoId,
                    origen_url: $('#origenUrl').val(),
                    origen_token: $('#origenToken').val(),
                    categoria_destino: $('#categoriaDestino').val()
                },
                success: function(response) {
                    // Mostrar log
                    if (response.log) {
                        const logHtml = response.log.map(entry => 
                            `[${entry.time}] ${entry.message}`
                        ).join('<br>');
                        $('#log_' + cursoId).html(logHtml);
                    }
                    
                    resolve(response);
                },
                error: function(xhr) {
                    reject(new Error('Error de conexión'));
                }
            });
        });
    }
    
    // Función auxiliar sleep
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    // Prevenir salir durante migración
    window.addEventListener('beforeunload', function(e) {
        if (migracionEnProceso) {
            e.preventDefault();
            e.returnValue = '¿Está seguro de salir? La migración está en proceso.';
        }
    });
    </script>
</body>
</html>
