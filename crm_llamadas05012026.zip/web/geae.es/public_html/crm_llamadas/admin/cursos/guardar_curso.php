<?php
/**
 * GUARDAR CURSO MANUAL
 * Ubicación: /admin/cursos/guardar_curso.php
 */

require_once '../../includes/config.php';

// Verificar sesión
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../../auth/login.php');
    exit;
}

// Verificar rol
if (!in_array($_SESSION['rol'], ['admin', 'gestion_cursos'])) {
    die('Acceso denegado');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Obtener datos del formulario
    $empresa = trim($_POST['empresa'] ?? '');
    $cif = trim($_POST['cif'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $nombre_curso = trim($_POST['nombre_curso'] ?? '');
    $codigo_curso = trim($_POST['codigo_curso'] ?? '');
    $horas_curso = !empty($_POST['horas_curso']) ? (int)$_POST['horas_curso'] : null;
    $credito_formacion = !empty($_POST['credito_formacion']) ? (float)$_POST['credito_formacion'] : null;
    $nombre_alumno = trim($_POST['nombre_alumno'] ?? '');
    $dni_alumno = trim($_POST['dni_alumno'] ?? '');
    $telefono_alumno = trim($_POST['telefono_alumno'] ?? '');
    $email_alumno = trim($_POST['email_alumno'] ?? '');
    $fecha_inicio = !empty($_POST['fecha_inicio']) ? $_POST['fecha_inicio'] : null;
    $fecha_fin = !empty($_POST['fecha_fin']) ? $_POST['fecha_fin'] : null;
    $nombre_asesoria = trim($_POST['nombre_asesoria'] ?? '');
    $telefono_asesoria = trim($_POST['telefono_asesoria'] ?? '');
    $email_asesoria = trim($_POST['email_asesoria'] ?? '');
    
    // Validar campos obligatorios
    $errores = [];
    
    if (empty($empresa)) {
        $errores[] = 'El nombre de la empresa es obligatorio';
    }
    
    if (empty($nombre_curso)) {
        $errores[] = 'El nombre del curso es obligatorio';
    }
    
    if (empty($nombre_alumno)) {
        $errores[] = 'El nombre del alumno es obligatorio';
    }
    
    if (empty($dni_alumno)) {
        $errores[] = 'El DNI del alumno es obligatorio';
    }
    
    // Si hay errores, redirigir con mensaje
    if (!empty($errores)) {
        $_SESSION['mensaje_error'] = implode(', ', $errores);
        header('Location: gestion_cursos.php');
        exit;
    }
    
    // Insertar en la base de datos
    $sql = "INSERT INTO leads_activos (
        empresa, CIF, email,
        nombre_curso, codigo_curso, horas_curso, credito_formacion,
        nombre_alumno, dni_alumno, telefono_alumno, email_alumno,
        fecha_inicio, fecha_fin,
        nombre_asesoria, telefono_asesoria, email_asesoria,
        estado_curso, fecha_alta_curso, id_teleoperadora, verificado
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pendiente', NOW(), NULL, 1)";
    
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        $_SESSION['mensaje_error'] = 'Error al preparar la consulta: ' . $conn->error;
        header('Location: gestion_cursos.php');
        exit;
    }
    
    $stmt->bind_param(
        "sssssidsssssssss",
        $empresa, $cif, $email,
        $nombre_curso, $codigo_curso, $horas_curso, $credito_formacion,
        $nombre_alumno, $dni_alumno, $telefono_alumno, $email_alumno,
        $fecha_inicio, $fecha_fin,
        $nombre_asesoria, $telefono_asesoria, $email_asesoria
    );
    
    if ($stmt->execute()) {
        $id_curso = $stmt->insert_id;
        $_SESSION['mensaje_exito'] = "✅ Curso creado correctamente (ID: $id_curso)";
    } else {
        $_SESSION['mensaje_error'] = 'Error al guardar: ' . $stmt->error;
    }
    
    $stmt->close();
    
    header('Location: gestion_cursos.php');
    exit;
    
} else {
    // Si no es POST, redirigir
    header('Location: gestion_cursos.php');
    exit;
}
?>
