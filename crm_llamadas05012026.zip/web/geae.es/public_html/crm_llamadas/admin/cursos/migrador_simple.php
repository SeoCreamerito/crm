<?php
/**
 * MIGRADOR SIMPLE - VERSIÓN LOTE
 * Ubicación: /admin/cursos/migrador_simple.php
 * 
 * Migra 1 curso a la vez evitando timeouts
 */

error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', 0);

require_once '../../includes/config.php';
require_once '../../includes/MoodleAPI.php';

if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../../auth/login.php');
    exit;
}

if (!in_array($_SESSION['rol'], ['admin', 'gestion_cursos'])) {
    die('Acceso denegado - Solo administradores y gestión de cursos');
}

// Aumentar límites
set_time_limit(180);
ini_set('max_execution_time', 180);

$mensaje = '';
$tipo = '';

// ============================================================================
// PROCESAR MIGRACIÓN
// ============================================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    
    if ($_POST['accion'] === 'migrar_uno') {
        $origenUrl = $_POST['origen_url'];
        $origenToken = $_POST['origen_token'];
        $cursoId = intval($_POST['curso_id']);
        $categoriaDestino = intval($_POST['categoria_destino'] ?? 1);
        
        try {
            // API Origen
            $apiOrigen = $origenUrl . '/webservice/rest/server.php';
            $apiDestino = 'https://www.geae.es/plataforma/webservice/rest/server.php';
            $tokenDestino = '580bed506280fbd3e81fa180dfaafc00';
            
            // PASO 1: Obtener info curso
            $params = [
                'wstoken' => $origenToken,
                'wsfunction' => 'core_course_get_courses',
                'moodlewsrestformat' => 'json',
                'options[ids][0]' => $cursoId
            ];
            
            $ch = curl_init($apiOrigen);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            $response = curl_exec($ch);
            curl_close($ch);
            
            $cursos = json_decode($response, true);
            if (empty($cursos) || !isset($cursos[0])) {
                throw new Exception('Curso no encontrado');
            }
            
            $curso = $cursos[0];
            
            // PASO 2: Crear curso en destino
            $params = [
                'wstoken' => $tokenDestino,
                'wsfunction' => 'core_course_create_courses',
                'moodlewsrestformat' => 'json',
                'courses[0][fullname]' => $curso['fullname'],
                'courses[0][shortname]' => $curso['shortname'] . '_' . time(),
                'courses[0][categoryid]' => $categoriaDestino,
                'courses[0][summary]' => $curso['summary'] ?? '',
                'courses[0][visible]' => 1
            ];
            
            $ch = curl_init($apiDestino);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            $response = curl_exec($ch);
            curl_close($ch);
            
            $resultado = json_decode($response, true);
            
            if (isset($resultado[0]['id'])) {
                $nuevoCursoId = $resultado[0]['id'];
                $url = 'https://www.geae.es/plataforma/course/view.php?id=' . $nuevoCursoId;
                
                $mensaje = "✅ <strong>¡Curso migrado exitosamente!</strong><br>";
                $mensaje .= "Origen: {$curso['fullname']} (ID: $cursoId)<br>";
                $mensaje .= "Destino: ID $nuevoCursoId<br>";
                $mensaje .= "<a href='$url' target='_blank' class='btn btn-sm btn-success mt-2'>Ver curso →</a>";
                $tipo = 'success';
                
                // Registrar en BD
                $sql = "INSERT INTO migraciones_cursos (curso_origen_id, curso_destino_id, nombre_curso, fecha) 
                        VALUES (?, ?, ?, NOW())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("iis", $cursoId, $nuevoCursoId, $curso['fullname']);
                $stmt->execute();
                
            } else {
                throw new Exception('Error al crear curso en destino');
            }
            
        } catch (Exception $e) {
            $mensaje = "❌ <strong>Error:</strong> " . $e->getMessage();
            $tipo = 'danger';
        }
    }
}

// ============================================================================
// TABLA DE HISTORIAL (crear si no existe)
// ============================================================================
$conn->query("
    CREATE TABLE IF NOT EXISTS migraciones_cursos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        curso_origen_id INT,
        curso_destino_id INT,
        nombre_curso VARCHAR(255),
        fecha DATETIME,
        INDEX(fecha)
    )
");

// Obtener historial
$historial = [];
$result = $conn->query("SELECT * FROM migraciones_cursos ORDER BY fecha DESC LIMIT 20");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $historial[] = $row;
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Migrador Simple - GEAE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .step-card {
            border-left: 4px solid #667eea;
        }
    </style>
</head>
<body class="bg-light">
    
    <div class="container mt-4 mb-5">
        
        <!-- Hero -->
        <div class="hero">
            <h1><i class="bi bi-lightning-charge-fill"></i> Migrador Rápido de Cursos</h1>
            <p class="mb-0">Migra tus cursos de uno en uno - Sin complicaciones</p>
        </div>
        
        <!-- Mensaje -->
        <?php if ($mensaje): ?>
        <div class="alert alert-<?= $tipo ?> alert-dismissible">
            <?= $mensaje ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Formulario Simple -->
        <div class="row">
            <div class="col-md-8">
                <div class="card step-card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">🎯 Migrar un Curso</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="accion" value="migrar_uno">
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">URL Moodle Origen</label>
                                    <input type="url" name="origen_url" class="form-control" 
                                           placeholder="https://moodle-anterior.com" required
                                           value="<?= htmlspecialchars($_POST['origen_url'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Token API Origen</label>
                                    <input type="text" name="origen_token" class="form-control" 
                                           placeholder="abc123..." required
                                           value="<?= htmlspecialchars($_POST['origen_token'] ?? '') ?>">
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">ID del Curso a Migrar</label>
                                    <input type="number" name="curso_id" class="form-control" 
                                           placeholder="Ej: 123" required min="1">
                                    <small class="text-muted">
                                        Ver IDs en: URL_ORIGEN/course/index.php
                                    </small>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Categoría Destino (ID)</label>
                                    <input type="number" name="categoria_destino" class="form-control" 
                                           value="1" required>
                                    <small class="text-muted">1 = Miscellaneous</small>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg w-100">
                                <i class="bi bi-download"></i> Migrar Este Curso
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <!-- Ayuda -->
                <div class="card mb-3">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="bi bi-question-circle"></i> ¿Cómo funciona?</h6>
                    </div>
                    <div class="card-body">
                        <ol class="small mb-0">
                            <li>Introduce la URL y token de tu Moodle anterior</li>
                            <li>Indica el ID del curso a migrar</li>
                            <li>¡Listo! El curso se copiará a GEAE</li>
                        </ol>
                        <hr>
                        <p class="small mb-0">
                            <strong>Nota:</strong> Migra curso por curso para evitar timeouts.
                        </p>
                    </div>
                </div>
                
                <!-- Destino -->
                <div class="card">
                    <div class="card-body">
                        <h6>📍 Destino</h6>
                        <p class="small mb-0">
                            <strong>Plataforma:</strong><br>
                            www.geae.es/plataforma
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Historial -->
        <?php if (!empty($historial)): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">📊 Historial de Migraciones</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Curso</th>
                                <th>Origen ID</th>
                                <th>Destino ID</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($historial as $item): ?>
                            <tr>
                                <td><?= date('d/m/Y H:i', strtotime($item['fecha'])) ?></td>
                                <td><?= htmlspecialchars($item['nombre_curso']) ?></td>
                                <td><span class="badge bg-secondary"><?= $item['curso_origen_id'] ?></span></td>
                                <td><span class="badge bg-success"><?= $item['curso_destino_id'] ?></span></td>
                                <td>
                                    <a href="https://www.geae.es/plataforma/course/view.php?id=<?= $item['curso_destino_id'] ?>" 
                                       target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-box-arrow-up-right"></i> Ver
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
