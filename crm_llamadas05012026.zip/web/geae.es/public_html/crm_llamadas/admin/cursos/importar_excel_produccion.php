<?php
/**
 * IMPORTADOR DE CURSOS - EXCEL REAL DE PRODUCCIÓN
 * Ubicación: /admin/cursos/importar_excel_produccion.php
 * 
 * Estructura exacta del cursosonline.xlsx
 */

error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', 0);
ini_set('memory_limit', '512M');
set_time_limit(300);

require_once '../../includes/config.php';

// Verificar sesión y rol
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../../auth/login.php');
    exit;
}

if (!in_array($_SESSION['rol'], ['admin', 'gestion_cursos'])) {
    die('Acceso denegado.');
}

$mensaje = '';
$tipo_mensaje = '';
$registros_importados = 0;
$registros_errores = 0;
$errores_detalle = [];

// Verificar si existe PhpSpreadsheet
$tiene_phpspreadsheet = file_exists('../../vendor/autoload.php');

if ($tiene_phpspreadsheet) {
    require_once '../../vendor/autoload.php';
    use PhpOffice\PhpSpreadsheet\IOFactory;
    use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;
}

// Procesar archivo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['archivo'])) {
    $archivo = $_FILES['archivo'];
    
    if ($archivo['error'] !== UPLOAD_ERR_OK) {
        $mensaje = 'Error al subir el archivo';
        $tipo_mensaje = 'danger';
    } else {
        $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        
        if ($tiene_phpspreadsheet && in_array($extension, ['xlsx', 'xls'])) {
            // Procesar Excel con PhpSpreadsheet
            $resultado = procesarExcel($archivo['tmp_name'], $conn);
            $registros_importados = $resultado['importados'];
            $registros_errores = $resultado['errores'];
            $errores_detalle = $resultado['errores_detalle'];
            
            if ($registros_importados > 0) {
                $mensaje = "✅ $registros_importados cursos importados" . ($registros_errores > 0 ? ", $registros_errores errores" : "");
                $tipo_mensaje = 'success';
            } else {
                $mensaje = "⚠️ 0 cursos importados, $registros_errores errores";
                $tipo_mensaje = 'warning';
            }
        } elseif ($extension === 'csv') {
            $mensaje = 'Por favor, sube el archivo Excel original (.xlsx), no CSV';
            $tipo_mensaje = 'warning';
        } else {
            $mensaje = 'Solo se permiten archivos Excel (.xlsx, .xls)';
            $tipo_mensaje = 'danger';
        }
    }
}

function procesarExcel($archivo, $conn) {
    $importados = 0;
    $errores = 0;
    $errores_detalle = [];
    
    try {
        $spreadsheet = IOFactory::load($archivo);
        $worksheet = $spreadsheet->getActiveSheet();
        $highestRow = $worksheet->getHighestRow();
        
        // Empezar desde fila 2 (saltar encabezados)
        for ($row = 2; $row <= $highestRow; $row++) {
            
            // Leer TODAS las columnas del Excel real
            $teleoperadora = trim($worksheet->getCell("A{$row}")->getValue() ?? '');
            $tipo_regalo = trim($worksheet->getCell("B{$row}")->getValue() ?? '');
            $fecha_envio_tarjeta = $worksheet->getCell("C{$row}")->getValue();
            $fecha_envio_regalo = $worksheet->getCell("D{$row}")->getValue();
            $id_fundae = trim($worksheet->getCell("E{$row}")->getValue() ?? '');
            $codigo_curso = trim($worksheet->getCell("F{$row}")->getValue() ?? '');
            $numero_curso_anual = $worksheet->getCell("G{$row}")->getValue();
            $cif = trim($worksheet->getCell("H{$row}")->getValue() ?? '');
            $empresa = trim($worksheet->getCell("I{$row}")->getValue() ?? '');
            $fecha_inicio = $worksheet->getCell("J{$row}")->getValue();
            $fecha_fin = $worksheet->getCell("K{$row}")->getValue();
            $horas_curso = $worksheet->getCell("L{$row}")->getValue();
            $not_inicio = $worksheet->getCell("M{$row}")->getValue();
            $not_fin = $worksheet->getCell("N{$row}")->getValue();
            $credito = $worksheet->getCell("O{$row}")->getValue();
            $cofinanciado = $worksheet->getCell("P{$row}")->getValue();
            $nombre_curso = trim($worksheet->getCell("Q{$row}")->getValue() ?? '');
            $representante_legal = trim($worksheet->getCell("R{$row}")->getValue() ?? '');
            $dni_representante = trim($worksheet->getCell("S{$row}")->getValue() ?? '');
            $nombre_alumno = trim($worksheet->getCell("T{$row}")->getValue() ?? '');
            $dni_alumno = trim($worksheet->getCell("U{$row}")->getValue() ?? '');
            $telefono_alumno = trim($worksheet->getCell("V{$row}")->getValue() ?? '');
            $email_alumno = trim($worksheet->getCell("W{$row}")->getValue() ?? '');
            $puesto_alumno = trim($worksheet->getCell("X{$row}")->getValue() ?? '');
            $titulacion_alumno = trim($worksheet->getCell("Y{$row}")->getValue() ?? '');
            $nombre_asesoria = trim($worksheet->getCell("Z{$row}")->getValue() ?? '');
            $telefono_asesoria = trim($worksheet->getCell("AA{$row}")->getValue() ?? '');
            $email_asesoria = trim($worksheet->getCell("AB{$row}")->getValue() ?? '');
            $comentario_asesoria = trim($worksheet->getCell("AC{$row}")->getValue() ?? '');
            $envio_claves = $worksheet->getCell("AD{$row}")->getValue();
            $fecha_envio_claves = $worksheet->getCell("AE{$row}")->getValue();
            $claves_no_oficiales = trim($worksheet->getCell("AG{$row}")->getValue() ?? '');
            $contacto_administrativo = trim($worksheet->getCell("AH{$row}")->getValue() ?? '');
            $telefono_administrativo = trim($worksheet->getCell("AI{$row}")->getValue() ?? '');
            $email_administrativo = trim($worksheet->getCell("AJ{$row}")->getValue() ?? '');
            $comentario_general = trim($worksheet->getCell("AK{$row}")->getValue() ?? '');
            
            // Validar campos obligatorios
            if (empty($empresa)) {
                $errores++;
                $errores_detalle[] = "Fila $row: Falta empresa";
                continue;
            }
            
            if (empty($nombre_curso)) {
                $errores++;
                $errores_detalle[] = "Fila $row: Falta nombre del curso";
                continue;
            }
            
            if (empty($nombre_alumno)) {
                $errores++;
                $errores_detalle[] = "Fila $row: Falta nombre del alumno";
                continue;
            }
            
            if (empty($dni_alumno)) {
                $errores++;
                $errores_detalle[] = "Fila $row: Falta DNI del alumno";
                continue;
            }
            
            // Convertir fechas de Excel
            $fecha_inicio = convertirFechaExcel($fecha_inicio);
            $fecha_fin = convertirFechaExcel($fecha_fin);
            $fecha_envio_tarjeta = convertirFechaExcel($fecha_envio_tarjeta);
            $fecha_envio_regalo = convertirFechaExcel($fecha_envio_regalo);
            $fecha_envio_claves = convertirFechaExcel($fecha_envio_claves);
            
            // Convertir valores numéricos
            $horas_curso = !empty($horas_curso) && is_numeric($horas_curso) ? (int)$horas_curso : null;
            $credito = !empty($credito) && is_numeric($credito) ? (float)$credito : null;
            $numero_curso_anual = !empty($numero_curso_anual) && is_numeric($numero_curso_anual) ? (int)$numero_curso_anual : null;
            
            // Convertir booleanos
            $cofinanciado = (!empty($cofinanciado) && strtoupper($cofinanciado) === 'SI') ? 1 : 0;
            $envio_claves = (!empty($envio_claves) && strtoupper($envio_claves) === 'SI') ? 1 : 0;
            $not_inicio = (!empty($not_inicio) && strtoupper($not_inicio) === 'SI') ? 1 : 0;
            $not_fin = (!empty($not_fin) && strtoupper($not_fin) === 'SI') ? 1 : 0;
            
            // Buscar ID de teleoperadora por nombre
            $id_teleoperadora_origen = null;
            if (!empty($teleoperadora)) {
                $stmt_tel = $conn->prepare("SELECT id FROM usuarios WHERE (nombre LIKE ? OR CONCAT(nombre, ' ', apellidos) LIKE ?) AND rol = 'agent' LIMIT 1");
                $search_tel = "%$teleoperadora%";
                $stmt_tel->bind_param("ss", $search_tel, $search_tel);
                $stmt_tel->execute();
                $result_tel = $stmt_tel->get_result();
                if ($result_tel->num_rows > 0) {
                    $id_teleoperadora_origen = $result_tel->fetch_assoc()['id'];
                }
                $stmt_tel->close();
            }
            
            // Insertar en la base de datos
            $sql = "INSERT INTO leads_activos (
                empresa, CIF, email,
                nombre_curso, codigo_curso, horas_curso, credito_formacion, cofinanciado,
                nombre_alumno, dni_alumno, telefono_alumno, email_alumno, puesto_alumno, titulacion_alumno,
                representante_legal, dni_representante,
                fecha_inicio, fecha_fin,
                nombre_asesoria, telefono_asesoria, email_asesoria, comentario_asesoria,
                id_fundae, numero_curso_anual,
                tipo_regalo, fecha_envio_tarjeta, fecha_envio_regalo,
                envio_claves, fecha_envio_claves, claves_no_oficiales,
                notificacion_inicio_fundae, notificacion_fin_fundae,
                contacto_administrativo, telefono_administrativo, email_administrativo,
                comentario_general,
                id_teleoperadora_origen,
                estado_curso, fecha_alta_curso, id_teleoperadora, verificado
            ) VALUES (
                ?, ?, NULL,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?,
                ?, ?,
                ?, ?,
                ?, ?, ?, ?,
                ?, ?,
                ?, ?, ?,
                ?, ?, ?,
                ?, ?,
                ?, ?, ?,
                ?,
                ?,
                'pendiente', NOW(), NULL, 1
            )";
            
            $stmt = $conn->prepare($sql);
            
            if (!$stmt) {
                $errores++;
                $errores_detalle[] = "Fila $row: Error preparando consulta";
                continue;
            }
            
            $stmt->bind_param(
                "ssssiidsssssssssssssssisssisisssssi",
                $empresa, $cif,
                $nombre_curso, $codigo_curso, $horas_curso, $credito, $cofinanciado,
                $nombre_alumno, $dni_alumno, $telefono_alumno, $email_alumno, $puesto_alumno, $titulacion_alumno,
                $representante_legal, $dni_representante,
                $fecha_inicio, $fecha_fin,
                $nombre_asesoria, $telefono_asesoria, $email_asesoria, $comentario_asesoria,
                $id_fundae, $numero_curso_anual,
                $tipo_regalo, $fecha_envio_tarjeta, $fecha_envio_regalo,
                $envio_claves, $fecha_envio_claves, $claves_no_oficiales,
                $not_inicio, $not_fin,
                $contacto_administrativo, $telefono_administrativo, $email_administrativo,
                $comentario_general,
                $id_teleoperadora_origen
            );
            
            if ($stmt->execute()) {
                $importados++;
            } else {
                $errores++;
                $errores_detalle[] = "Fila $row: " . $stmt->error;
            }
            
            $stmt->close();
        }
        
    } catch (Exception $e) {
        $errores++;
        $errores_detalle[] = "Error general: " . $e->getMessage();
    }
    
    return [
        'importados' => $importados,
        'errores' => $errores,
        'errores_detalle' => array_slice($errores_detalle, 0, 20)
    ];
}

function convertirFechaExcel($valor) {
    if (empty($valor)) return null;
    
    // Si ya es DateTime
    if ($valor instanceof DateTime) {
        return $valor->format('Y-m-d');
    }
    
    // Si es número de serie de Excel
    if (is_numeric($valor)) {
        try {
            $fecha = ExcelDate::excelToDateTimeObject($valor);
            return $fecha->format('Y-m-d');
        } catch (Exception $e) {
            return null;
        }
    }
    
    // Si es string, intentar parsear
    if (is_string($valor)) {
        $timestamp = strtotime($valor);
        if ($timestamp !== false) {
            return date('Y-m-d', $timestamp);
        }
    }
    
    return null;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Importar Excel Producción</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-light">
    <div class="container py-4">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4><i class="bi bi-file-earmark-excel"></i> Importar Excel de Producción (cursosonline.xlsx)</h4>
            </div>
            <div class="card-body">
                <?php if ($mensaje): ?>
                <div class="alert alert-<?= $tipo_mensaje ?>">
                    <?= $mensaje ?>
                </div>
                <?php endif; ?>
                
                <?php if ($errores_detalle): ?>
                <div class="alert alert-warning">
                    <h6>Errores detectados:</h6>
                    <ul class="mb-0"><?php foreach ($errores_detalle as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?></ul>
                </div>
                <?php endif; ?>
                
                <div class="alert alert-info">
                    <h6><i class="bi bi-info-circle"></i> Información</h6>
                    <ul class="mb-0">
                        <li>Este importador está adaptado al <strong>Excel real de producción</strong></li>
                        <li>Sube directamente tu archivo <code>cursosonline.xlsx</code></li>
                        <li>Se importarán <strong>TODAS las columnas</strong> del Excel</li>
                        <li>Las teleoperadoras se asignarán automáticamente si coincide el nombre</li>
                        <?php if (!$tiene_phpspreadsheet): ?>
                        <li class="text-danger"><strong>⚠️ PhpSpreadsheet no instalado.</strong> Necesitas instalarlo para usar Excel.</li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label>Archivo Excel:</label>
                        <input type="file" name="archivo" class="form-control" accept=".xlsx,.xls" required 
                               <?= !$tiene_phpspreadsheet ? 'disabled' : '' ?>>
                    </div>
                    <button type="submit" class="btn btn-primary" <?= !$tiene_phpspreadsheet ? 'disabled' : '' ?>>
                        <i class="bi bi-upload"></i> Importar
                    </button>
                    <a href="gestion_cursos.php" class="btn btn-secondary">Volver</a>
                </form>
            </div>
        </div>
        
        <?php if ($registros_importados || $registros_errores): ?>
        <div class="card shadow mt-3">
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-6">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <h2><?= $registros_importados ?></h2>
                                <p>Importados</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card bg-warning">
                            <div class="card-body">
                                <h2><?= $registros_errores ?></h2>
                                <p>Errores</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
