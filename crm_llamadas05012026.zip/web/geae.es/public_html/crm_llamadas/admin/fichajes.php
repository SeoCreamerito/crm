<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();
requireRole('admin');

// Obtener usuarios con rol agent/inspeccion
$usuarios = $conexion->query("SELECT id, CONCAT(nombre, ' ', apellidos) AS nombre_completo, rol FROM usuarios WHERE rol IN ('agent', 'inspeccion') AND activo = 1 ORDER BY nombre_completo");

// Filtros
$id_usuario = $_GET['usuario'] ?? null;
$fecha_desde = $_GET['desde'] ?? date('Y-m-d', strtotime('-7 days'));
$fecha_hasta = $_GET['hasta'] ?? date('Y-m-d');

// Aprobar/rechazar horas extra (lógica existente)
if (isset($_POST['aprobar_he'])) {
    $stmt = $conexion->prepare("UPDATE horas_extra SET estado = 'aprobada', aprobado_por = ?, fecha_aprobacion = NOW() WHERE id = ?");
    $stmt->bind_param("ii", $_SESSION['user_id'], $_POST['aprobar_he']);
    $stmt->execute();
    header("Location: fichajes.php?" . $_SERVER['QUERY_STRING']);
    exit;
}
if (isset($_POST['rechazar_he'])) {
    $stmt = $conexion->prepare("UPDATE horas_extra SET estado = 'rechazada', aprobado_por = ?, fecha_aprobacion = NOW() WHERE id = ?");
    $stmt->bind_param("ii", $_SESSION['user_id'], $_POST['rechazar_he']);
    $stmt->execute();
    header("Location: fichajes.php?" . $_SERVER['QUERY_STRING']);
    exit;
}
if (isset($_POST['cerrar_sesion'])) {
    $stmt = $conexion->prepare("UPDATE sesiones_actividad SET fecha_salida = NOW(), cerrado_por_admin = 1 WHERE id = ? AND fecha_salida IS NULL");
    $stmt->bind_param("i", $_POST['cerrar_sesion']);
    $stmt->execute();
    header("Location: fichajes.php?" . $_SERVER['QUERY_STRING']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Fichajes y Jornadas - CRM Llamadas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/crm_llamadas/assets/css/main.css">
    <style>
        .jornada-incompleta { background-color: #fff3cd; }
        .jornada-completa { background-color: #d4edda; }
        .pausa-item { font-size: 0.9em; color: #6c757d; }
    </style>
</head>
<body>

<?php require_once '../includes/navbar.php'; ?>

<div class="container-fluid mt-3">
    <h2>⏱️ Gestión de Fichajes y Jornadas</h2>

    <!-- Filtros -->
    <div class="card p-3 mb-4">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label>Usuario</label>
                <select name="usuario" class="form-select">
                    <option value="">Todos los usuarios</option>
                    <?php while ($u = $usuarios->fetch_assoc()): ?>
                        <option value="<?= $u['id'] ?>" <?= ($id_usuario == $u['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($u['nombre_completo']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label>Desde</label>
                <input type="date" name="desde" class="form-control" value="<?= htmlspecialchars($fecha_desde) ?>">
            </div>
            <div class="col-md-2">
                <label>Hasta</label>
                <input type="date" name="hasta" class="form-control" value="<?= htmlspecialchars($fecha_hasta) ?>">
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">Filtrar</button>
            </div>
        </form>
    </div>

    <!-- Horas Extra Pendientes -->
    <div class="card mb-4">
        <div class="card-header bg-warning text-dark">
            ⚠️ Horas Extra Pendientes de Aprobación
        </div>
        <div class="card-body">
            <?php
            $he_pendientes = $conexion->query("
                SELECT he.*, CONCAT(u.nombre, ' ', u.apellidos) AS usuario, u.dni
                FROM horas_extra he
                JOIN usuarios u ON he.id_usuario = u.id
                WHERE he.estado = 'pendiente'
                ORDER BY he.fecha DESC
            ");
            if ($he_pendientes->num_rows > 0):
            ?>
                <table class="table table-sm">
                    <thead><tr><th>Usuario</th><th>DNI</th><th>Fecha</th><th>Horas</th><th>Motivo</th><th>Tipo</th><th>Acciones</th></tr></thead>
                    <tbody>
                        <?php while ($he = $he_pendientes->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($he['usuario']) ?></td>
                            <td><?= htmlspecialchars($he['dni']) ?></td>
                            <td><?= $he['fecha'] ?></td>
                            <td><?= $he['horas'] ?></td>
                            <td><?= htmlspecialchars($he['motivo']) ?></td>
                            <td><?= $he['tipo'] ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="aprobar_he" value="<?= $he['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-success">Aprobar</button>
                                </form>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="rechazar_he" value="<?= $he['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">Rechazar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-success">✅ No hay horas extra pendientes.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Jornadas -->
    <h4>Jornadas registradas</h4>
    <?php
    $condicion = "s.fecha_entrada BETWEEN ? AND ?";
    $params = [$fecha_desde, $fecha_hasta];
    $types = "ss";

    if ($id_usuario) {
        $condicion .= " AND s.id_usuario = ?";
        $params[] = $id_usuario;
        $types .= "i";
    }

    $stmt = $conexion->prepare("
        SELECT s.*, 
               CONCAT(u.nombre, ' ', u.apellidos) AS usuario_completo,
               u.dni,
               u.num_ss,
               u.puesto,
               u.rol,
               TIME_FORMAT(SEC_TO_TIME(TIMESTAMPDIFF(SECOND, s.fecha_entrada, COALESCE(s.fecha_salida, NOW()))), '%Hh %im') AS duracion,
               (SELECT COUNT(*) FROM pausas p WHERE p.id_sesion = s.id) AS total_pausas
        FROM sesiones_actividad s
        JOIN usuarios u ON s.id_usuario = u.id
        WHERE $condicion
        ORDER BY s.fecha_entrada DESC
    ");
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $jornadas = $stmt->get_result();
    ?>
    
    <?php if ($jornadas->num_rows > 0): ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Usuario</th>
                        <th>DNI</th>
                        <th>Nº SS</th>
                        <th>Puesto</th>
                        <th>Entrada</th>
                        <th>Salida</th>
                        <th>Duración</th>
                        <th>Pausas</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($j = $jornadas->fetch_assoc()):
                        $completa = $j['fecha_salida'] !== null;
                        $clase = $completa ? 'jornada-completa' : 'jornada-incompleta';
                    ?>
                    <tr class="<?= $clase ?>">
                        <td><?= htmlspecialchars($j['usuario_completo']) ?></td>
                        <td><?= htmlspecialchars($j['dni']) ?></td>
                        <td><?= htmlspecialchars($j['num_ss'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($j['puesto']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($j['fecha_entrada'])) ?></td>
                        <td>
                            <?php if ($completa): ?>
                                <?= date('d/m/Y H:i', strtotime($j['fecha_salida'])) ?>
                                <?php if ($j['cerrado_por_admin']): ?>
                                    <span class="badge bg-info">Cerrado por admin</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-danger">⚠️ Sin cerrar</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $j['duracion'] ?></td>
                        <td>
                            <?php if ($j['total_pausas'] > 0): ?>
                                <details>
                                    <summary><?= $j['total_pausas'] ?> pausa(s)</summary>
                                    <?php
                                    $pausas = $conexion->query("SELECT * FROM pausas WHERE id_sesion = {$j['id']} ORDER BY hora_inicio");
                                    while ($p = $pausas->fetch_assoc()):
                                        $duracion = $p['duracion_minutos'] ?? '0';
                                    ?>
                                        <div class="pausa-item">
                                            <?= date('H:i', strtotime($p['hora_inicio'])) ?> - 
                                            <?= $p['hora_fin'] ? date('H:i', strtotime($p['hora_fin'])) : 'en curso' ?> 
                                            (<?= $duracion ?> min) [<?= $p['tipo'] ?>]
                                        </div>
                                    <?php endwhile; ?>
                                </details>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!$completa): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="cerrar_sesion" value="<?= $j['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-warning" 
                                            onclick="return confirm('¿Cerrar esta jornada ahora?')">
                                        Cerrar Jornada
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info">No se encontraron jornadas con los filtros aplicados.</div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/crm_llamadas/assets/js/main.js"></script>
</body>
</html>