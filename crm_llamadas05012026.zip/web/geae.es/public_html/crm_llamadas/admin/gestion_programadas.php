<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();
requireRole('admin');

// Obtener teleoperadoras
$agents = $conexion->query("SELECT id, nombre FROM usuarios WHERE rol = 'agent' AND activo = 1");

// Filtros
$estado_filtro = $_GET['estado'] ?? '';
$agent_filtro = $_GET['agent'] ?? '';
$fecha_filtro = $_GET['fecha'] ?? date('Y-m-d');

// Marcar como completada
if (isset($_POST['completar'])) {
    $stmt = $conexion->prepare("UPDATE llamadas_programadas SET completada = 1 WHERE id = ?");
    $stmt->bind_param("i", $_POST['completar']);
    $stmt->execute();
    header("Location: gestion_programadas.php?" . $_SERVER['QUERY_STRING']);
    exit;
}

// Editar fecha
if (isset($_POST['editar_fecha'])) {
    $nueva_fecha = $_POST['nueva_fecha'];
    $id_programada = $_POST['editar_fecha'];
    $stmt = $conexion->prepare("UPDATE llamadas_programadas SET fecha_programada = ? WHERE id = ?");
    $stmt->bind_param("si", $nueva_fecha, $id_programada);
    $stmt->execute();
    header("Location: gestion_programadas.php?" . $_SERVER['QUERY_STRING']);
    exit;
}

// Consulta de llamadas programadas
$condiciones = "lp.completada = 0 AND DATE(lp.fecha_programada) = ?";
$params = [$fecha_filtro];
$tipos = "s";

if ($estado_filtro) {
    $condiciones .= " AND lp.estado_programado = ?";
    $params[] = $estado_filtro;
    $tipos .= "s";
}
if ($agent_filtro) {
    $condiciones .= " AND lp.id_teleoperadora = ?";
    $params[] = $agent_filtro;
    $tipos .= "i";
}

// JOIN con leads_activos para obtener datos del lead
$sql = "
    SELECT lp.*, la.empresa, la.telefono1, la.provincia, u.nombre AS teleoperadora
    FROM llamadas_programadas lp
    JOIN leads_activos la ON la.id = lp.id_lead AND la.id_teleoperadora = lp.id_teleoperadora
    JOIN usuarios u ON u.id = lp.id_teleoperadora
    WHERE $condiciones
    ORDER BY lp.fecha_programada ASC
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param($tipos, ...$params);
$stmt->execute();
$result = $stmt->get_result();
$programadas = [];
while ($row = $result->fetch_assoc()) {
    $programadas[] = $row;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Llamadas Programadas - CRM Llamadas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .estado-interesados { background-color: #e7f1ff; border-left: 4px solid #0d6efd; }
        .estado-mando-info { background-color: #fff8e1; border-left: 4px solid #ffc107; }
        .estado-volver { background-color: #f8f9fa; border-left: 4px solid #6c757d; }
    </style>
</head>
<body>
<?php require_once '../includes/navbar.php'; ?>
<div class="container-fluid mt-3">
    <h2>📞 Llamadas Programadas para el <strong><?= date('d/m/Y', strtotime($fecha_filtro)) ?></strong></h2>

    <!-- Filtros -->
    <div class="card p-3 mb-4">
        <form method="GET" class="row g-3">
            <div class="col-md-2">
                <label>Fecha</label>
                <input type="date" name="fecha" class="form-control" value="<?= htmlspecialchars($fecha_filtro) ?>" onchange="this.form.submit()">
            </div>
            <div class="col-md-2">
                <label>Estado</label>
                <select name="estado" class="form-select" onchange="this.form.submit()">
                    <option value="">Todos</option>
                    <option value="Interesados" <?= $estado_filtro === 'Interesados' ? 'selected' : '' ?>>Interesados</option>
                    <option value="Mando Info" <?= $estado_filtro === 'Mando Info' ? 'selected' : '' ?>>Mando Info</option>
                    <option value="Volver a Llamar" <?= $estado_filtro === 'Volver a Llamar' ? 'selected' : '' ?>>Volver a Llamar</option>
                </select>
            </div>
            <div class="col-md-3">
                <label>Teleoperadora</label>
                <select name="agent" class="form-select" onchange="this.form.submit()">
                    <option value="">Todas</option>
                    <?php foreach ($agents as $a): ?>
                        <option value="<?= $a['id'] ?>" <?= ($agent_filtro == $a['id']) ? 'selected' : '' ?>>
                            <?= $a['nombre'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>

    <?php if (empty($programadas)): ?>
        <div class="alert alert-info">✅ No hay llamadas programadas para este día con los filtros aplicados.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Empresa</th>
                        <th>Teléfono</th>
                        <th>Provincia</th>
                        <th>Teleoperadora</th>
                        <th>Estado</th>
                        <th>Hora</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($programadas as $p):
                        $clase_estado = match($p['estado_programado']) {
                            'Interesados' => 'estado-interesados',
                            'Mando Info' => 'estado-mando-info',
                            default => 'estado-volver'
                        };
                    ?>
                    <tr class="<?= $clase_estado ?>">
                        <td><?= htmlspecialchars($p['empresa']) ?></td>
                        <td><?= $p['telefono1'] ?></td>
                        <td><?= htmlspecialchars($p['provincia']) ?></td>
                        <td><?= $p['teleoperadora'] ?></td>
                        <td><?= $p['estado_programado'] ?></td>
                        <td><?= date('H:i', strtotime($p['fecha_programada'])) ?></td>
                        <td>
                            <!-- Completar -->
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="completar" value="<?= $p['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-success" 
                                        onclick="return confirm('¿Marcar esta llamada como completada?')">
                                    ✅ Hecha
                                </button>
                            </form>

                            <!-- Editar hora -->
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" 
                                    data-bs-target="#modalEditar<?= $p['id'] ?>">
                                🕒 Editar
                            </button>

                            <!-- Modal de edición -->
                            <div class="modal fade" id="modalEditar<?= $p['id'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5>Editar hora para <?= htmlspecialchars($p['empresa']) ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="POST">
                                            <div class="modal-body">
                                                <input type="hidden" name="editar_fecha" value="<?= $p['id'] ?>">
                                                <label>Nueva fecha y hora</label>
                                                <input type="datetime-local" name="nueva_fecha" class="form-control"
                                                       value="<?= date('Y-m-d\TH:i', strtotime($p['fecha_programada'])) ?>"
                                                       required>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                <button type="submit" class="btn btn-primary">Guardar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <!-- Resumen por estado -->
    <div class="row mt-4">
        <?php
        $resumen_estados = [];
        foreach (['Interesados', 'Mando Info', 'Volver a Llamar'] as $estado) {
            $stmt = $conexion->prepare("
                SELECT COUNT(*) AS total
                FROM llamadas_programadas lp
                JOIN leads_activos la ON la.id = lp.id_lead
                WHERE lp.completada = 0 
                  AND DATE(lp.fecha_programada) = ?
                  AND lp.estado_programado = ?
            ");
            $stmt->bind_param("ss", $fecha_filtro, $estado);
            $stmt->execute();
            $resumen_estados[$estado] = $stmt->get_result()->fetch_assoc()['total'];
        }
        ?>
        <div class="col-md-4">
            <div class="card text-bg-primary p-3">
                <h6>Interesados hoy</h6>
                <h3><?= $resumen_estados['Interesados'] ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-bg-warning p-3">
                <h6>Mando Info (RGPD)</h6>
                <h3><?= $resumen_estados['Mando Info'] ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-bg-secondary p-3">
                <h6>Volver a Llamar</h6>
                <h3><?= $resumen_estados['Volver a Llamar'] ?></h3>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>