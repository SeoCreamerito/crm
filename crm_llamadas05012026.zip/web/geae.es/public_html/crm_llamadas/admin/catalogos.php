<?php
/**
 * PANEL DE ADMINISTRACIÓN DE CATÁLOGOS
 * Ubicación: /admin/catalogos.php
 * 
 * Gestión de:
 * - Tipos de Regalos
 * - Tipos de Puestos
 * - Tipos de Titulaciones
 */

error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', 0);

require_once '../includes/config.php';

// Verificar sesión y rol
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../auth/login.php');
    exit;
}

if ($_SESSION['rol'] != 'admin') {
    die('Acceso denegado. Solo administradores pueden gestionar catálogos.');
}

// Obtener catálogo activo (por defecto: regalos)
$catalogo_activo = $_GET['catalogo'] ?? 'regalos';

// Mapeo de catálogos
$catalogos = [
    'regalos' => [
        'nombre' => 'Tipos de Regalos',
        'tabla' => 'tipos_regalos',
        'icono' => 'gift',
        'descripcion' => 'Gestiona los tipos de regalos e incentivos disponibles'
    ],
    'puestos' => [
        'nombre' => 'Tipos de Puestos',
        'tabla' => 'tipos_puestos',
        'icono' => 'briefcase',
        'descripcion' => 'Gestiona los puestos laborales disponibles'
    ],
    'titulaciones' => [
        'nombre' => 'Tipos de Titulaciones',
        'tabla' => 'tipos_titulaciones',
        'icono' => 'mortarboard',
        'descripcion' => 'Gestiona las titulaciones académicas disponibles'
    ]
];

// Validar catálogo
if (!isset($catalogos[$catalogo_activo])) {
    $catalogo_activo = 'regalos';
}

$catalogo = $catalogos[$catalogo_activo];

// Obtener datos del catálogo
$sql = "SELECT * FROM {$catalogo['tabla']} ORDER BY orden ASC, nombre ASC";
$result = $conn->query($sql);
$items = [];
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}

// Contar totales
$stats = [
    'total' => count($items),
    'activos' => count(array_filter($items, fn($i) => $i['activo'] == 1)),
    'inactivos' => count(array_filter($items, fn($i) => $i['activo'] == 0))
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogos - CRM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <style>
        .nav-catalogo {
            border-bottom: 2px solid #dee2e6;
            margin-bottom: 30px;
        }
        .nav-catalogo .nav-link {
            border: none;
            border-bottom: 3px solid transparent;
            color: #6c757d;
            padding: 15px 25px;
            font-weight: 500;
        }
        .nav-catalogo .nav-link:hover {
            color: #0d6efd;
            border-bottom-color: #0d6efd;
        }
        .nav-catalogo .nav-link.active {
            color: #0d6efd;
            border-bottom-color: #0d6efd;
            background: none;
        }
        .stat-card {
            border-left: 4px solid #0d6efd;
        }
        .badge-orden {
            background: #e9ecef;
            color: #495057;
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: 600;
        }
    </style>
</head>
<body class="bg-light">
    
    <?php include '../includes/navbar.php'; ?>

    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="bg-white border-bottom">
        <div class="container-fluid py-2">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="dashboard.php"><i class="bi bi-house-door"></i> Dashboard</a></li>
                <li class="breadcrumb-item active">Administración de Catálogos</li>
            </ol>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        
        <!-- Mensajes -->
        <?php if (isset($_SESSION['mensaje_exito'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= htmlspecialchars($_SESSION['mensaje_exito']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['mensaje_exito']); endif; ?>
        
        <?php if (isset($_SESSION['mensaje_error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= htmlspecialchars($_SESSION['mensaje_error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['mensaje_error']); endif; ?>
        
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2><i class="bi bi-gear"></i> Administración de Catálogos</h2>
                <p class="text-muted mb-0">Gestiona los catálogos del sistema</p>
            </div>
            <div>
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left"></i> Volver al Dashboard
                </a>
            </div>
        </div>
        
        <!-- Navegación de catálogos -->
        <ul class="nav nav-catalogo">
            <?php foreach ($catalogos as $key => $cat): ?>
            <li class="nav-item">
                <a class="nav-link <?= $key === $catalogo_activo ? 'active' : '' ?>" 
                   href="?catalogo=<?= $key ?>">
                    <i class="bi bi-<?= $cat['icono'] ?>"></i> <?= $cat['nombre'] ?>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
        
        <!-- Estadísticas -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted mb-1">Total</h6>
                                <h3 class="mb-0"><?= $stats['total'] ?></h3>
                            </div>
                            <div class="text-primary">
                                <i class="bi bi-<?= $catalogo['icono'] ?>" style="font-size: 2rem;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card" style="border-left-color: #198754;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted mb-1">Activos</h6>
                                <h3 class="mb-0 text-success"><?= $stats['activos'] ?></h3>
                            </div>
                            <div class="text-success">
                                <i class="bi bi-check-circle" style="font-size: 2rem;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card" style="border-left-color: #dc3545;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted mb-1">Inactivos</h6>
                                <h3 class="mb-0 text-danger"><?= $stats['inactivos'] ?></h3>
                            </div>
                            <div class="text-danger">
                                <i class="bi bi-x-circle" style="font-size: 2rem;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Panel principal -->
        <div class="card shadow">
            <div class="card-header bg-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0">
                            <i class="bi bi-<?= $catalogo['icono'] ?>"></i> <?= $catalogo['nombre'] ?>
                        </h5>
                        <small class="text-muted"><?= $catalogo['descripcion'] ?></small>
                    </div>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalNuevo">
                        <i class="bi bi-plus-circle"></i> Nuevo
                    </button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="tablaCatalogo" class="table table-hover">
                        <thead>
                            <tr>
                                <th width="60">Orden</th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th width="100">Estado</th>
                                <th width="150">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                            <tr>
                                <td>
                                    <span class="badge-orden"><?= $item['orden'] ?></span>
                                </td>
                                <td>
                                    <strong><?= htmlspecialchars($item['nombre']) ?></strong>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?= htmlspecialchars($item['descripcion'] ?? '-') ?>
                                    </small>
                                </td>
                                <td>
                                    <?php if ($item['activo']): ?>
                                    <span class="badge bg-success">Activo</span>
                                    <?php else: ?>
                                    <span class="badge bg-secondary">Inactivo</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" 
                                                class="btn btn-outline-primary btn-editar"
                                                data-id="<?= $item['id'] ?>"
                                                data-nombre="<?= htmlspecialchars($item['nombre']) ?>"
                                                data-descripcion="<?= htmlspecialchars($item['descripcion'] ?? '') ?>"
                                                data-orden="<?= $item['orden'] ?>"
                                                data-activo="<?= $item['activo'] ?>">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button type="button" 
                                                class="btn btn-outline-danger btn-eliminar"
                                                data-id="<?= $item['id'] ?>"
                                                data-nombre="<?= htmlspecialchars($item['nombre']) ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal Nuevo -->
    <div class="modal fade" id="modalNuevo" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="bi bi-plus-circle"></i> Nuevo <?= $catalogo['nombre'] ?>
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="ajax/guardar_catalogo.php">
                    <input type="hidden" name="tabla" value="<?= $catalogo['tabla'] ?>">
                    <input type="hidden" name="catalogo" value="<?= $catalogo_activo ?>">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Nombre <span class="text-danger">*</span></label>
                            <input type="text" name="nombre" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Descripción</label>
                            <textarea name="descripcion" class="form-control" rows="2"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Orden</label>
                                    <input type="number" name="orden" class="form-control" value="0" min="0">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Estado</label>
                                    <select name="activo" class="form-select">
                                        <option value="1">Activo</option>
                                        <option value="0">Inactivo</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save"></i> Guardar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Modal Editar -->
    <div class="modal fade" id="modalEditar" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title">
                        <i class="bi bi-pencil"></i> Editar <?= $catalogo['nombre'] ?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="ajax/actualizar_catalogo.php">
                    <input type="hidden" name="id" id="edit_id">
                    <input type="hidden" name="tabla" value="<?= $catalogo['tabla'] ?>">
                    <input type="hidden" name="catalogo" value="<?= $catalogo_activo ?>">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Nombre <span class="text-danger">*</span></label>
                            <input type="text" name="nombre" id="edit_nombre" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Descripción</label>
                            <textarea name="descripcion" id="edit_descripcion" class="form-control" rows="2"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Orden</label>
                                    <input type="number" name="orden" id="edit_orden" class="form-control" min="0">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Estado</label>
                                    <select name="activo" id="edit_activo" class="form-select">
                                        <option value="1">Activo</option>
                                        <option value="0">Inactivo</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-warning">
                            <i class="bi bi-save"></i> Actualizar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
    $(document).ready(function() {
        // DataTable
        $('#tablaCatalogo').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
            },
            order: [[0, 'asc']],
            pageLength: 25
        });
        
        // Editar
        $('.btn-editar').on('click', function() {
            $('#edit_id').val($(this).data('id'));
            $('#edit_nombre').val($(this).data('nombre'));
            $('#edit_descripcion').val($(this).data('descripcion'));
            $('#edit_orden').val($(this).data('orden'));
            $('#edit_activo').val($(this).data('activo'));
            $('#modalEditar').modal('show');
        });
        
        // Eliminar
        $('.btn-eliminar').on('click', function() {
            const id = $(this).data('id');
            const nombre = $(this).data('nombre');
            const tabla = '<?= $catalogo['tabla'] ?>';
            const catalogo = '<?= $catalogo_activo ?>';
            
            Swal.fire({
                title: '¿Eliminar?',
                html: `¿Estás seguro de eliminar <strong>${nombre}</strong>?<br><small class="text-danger">Esta acción no se puede deshacer</small>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.post('ajax/eliminar_catalogo.php', {
                        id: id,
                        tabla: tabla,
                        catalogo: catalogo
                    }, function(response) {
                        if (response.success) {
                            Swal.fire('Eliminado', response.mensaje, 'success').then(() => {
                                window.location.reload();
                            });
                        } else {
                            Swal.fire('Error', response.mensaje, 'error');
                        }
                    }, 'json');
                }
            });
        });
    });
    </script>
</body>
</html>
