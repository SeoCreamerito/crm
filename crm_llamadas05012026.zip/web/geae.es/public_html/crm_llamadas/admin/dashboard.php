<?php
/**
 * Dashboard de Administración - CRM Llamadas
 * Versión SIMPLIFICADA - gestion_cursos.php en mismo directorio
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Cargar configuración
require_once __DIR__ . '/../includes/config.php';

// Crear conexión MySQLi adicional para compatibilidad
if (!isset($conn)) {
    $host = 'localhost';
    $db   = 'geae_crm_llamadas';
    $user = 'geae_crm_llamadas';
    $pass = '&4222SFCrb1975';
    
    $conn = new mysqli($host, $user, $pass, $db);
    if ($conn->connect_error) {
        die("Error de conexión MySQLi: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");
}

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();
requireRole('admin');

$hoy = date('Y-m-d');

// Alertas: Teleoperadoras con pocos leads
$alertas_leads_bajos = [];
$stmt = $pdo->prepare("
    SELECT u.nombre, COUNT(l.id) AS leads
    FROM usuarios u
    LEFT JOIN leads_activos l ON l.id_teleoperadora = u.id
    WHERE u.rol = 'agent' AND u.activo = 1
    GROUP BY u.id
    HAVING leads <= 30 OR leads IS NULL
");
$stmt->execute();
$alertas_leads_bajos = $stmt->fetchAll();

// Leads sin asignar
$stmt = $pdo->query("SELECT COUNT(*) FROM leads_activos WHERE id_teleoperadora IS NULL");
$sinAsignar = $stmt->fetchColumn();

// KPI: Tasa de conversión
$tasa = 0;
$stmt = $pdo->query("
    SELECT 
        (SELECT COUNT(*) FROM historial_llamadas WHERE estado_nuevo LIKE '%Interesado%') AS interesados,
        (SELECT COUNT(*) FROM historial_llamadas) AS total
");
$kpi1 = $stmt->fetch();
if ($kpi1 && $kpi1['total'] > 0) {
    $tasa = round(($kpi1['interesados'] / $kpi1['total']) * 100, 2);
}

// KPI: Interesados pendientes hoy
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM llamadas_programadas
    WHERE DATE(fecha_programada) = :hoy 
    AND estado_programado = 'Interesados' 
    AND completada = 0
");
$stmt->execute([':hoy' => $hoy]);
$pendientes = $stmt->fetchColumn();

// KPI: Llamadas realizadas hoy
$stmt = $pdo->prepare("SELECT COUNT(*) FROM historial_llamadas WHERE DATE(fecha_llamada) = :hoy");
$stmt->execute([':hoy' => $hoy]);
$hoy_llamadas = $stmt->fetchColumn();

// KPI: Total leads activos
$stmt = $pdo->query("SELECT COUNT(*) FROM leads_activos");
$total_activos = $stmt->fetchColumn();

// KPI: Total cursos (leads con nombre_curso)
$stmt_curso = $pdo->query("SELECT COUNT(*) FROM leads_activos WHERE nombre_curso IS NOT NULL AND nombre_curso != ''");
$total_cursos = $stmt_curso->fetchColumn();

// KPI: Cursos pendientes
$stmt_curso_pend = $pdo->query("SELECT COUNT(*) FROM leads_activos WHERE nombre_curso IS NOT NULL AND nombre_curso != '' AND estado_curso = 'pendiente'");
$cursos_pendientes = $stmt_curso_pend->fetchColumn();

// Teleoperadoras activas
$stmt = $pdo->query("SELECT id, nombre FROM usuarios WHERE rol = 'agent' AND activo = 1 ORDER BY nombre");
$teleoperadoras = $stmt->fetchAll();

// Conteos para gráfico
$tablas_finales = [
    'leads_no_contesta' => 'No Contesta',
    'leads_creditos_agotados' => 'Créditos Agotados',
    'leads_no_interesa' => 'No Interesa',
    'leads_ellos_contestan' => 'Ellos Contestan',
    'leads_ellos_llaman' => 'Ellos Llaman',
    'leads_tardes' => 'Tardes',
    'leads_interesados' => 'Interesados'
];

$datos_grafico = [];
foreach ($tablas_finales as $tabla => $nombre) {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM $tabla");
        $datos_grafico[$nombre] = $stmt->fetchColumn();
    } catch (Exception $e) {
        $datos_grafico[$nombre] = 0;
    }
}

// Agregar cursos al gráfico
$datos_grafico['Cursos'] = $total_cursos;

// Estadísticas por teleoperadora
$stats_teleop = [];
foreach ($teleoperadoras as $t) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM leads_activos WHERE id_teleoperadora = :id");
    $stmt->execute([':id' => $t['id']]);
    $leads = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM historial_llamadas WHERE id_teleoperadora = :id AND DATE(fecha_llamada) = :hoy");
    $stmt->execute([':id' => $t['id'], ':hoy' => $hoy]);
    $llamadas_hoy = $stmt->fetchColumn();
    
    $stats_teleop[] = [
        'nombre' => $t['nombre'],
        'leads' => $leads,
        'llamadas_hoy' => $llamadas_hoy
    ];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - CRM Llamadas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #f3f4f6; }
        .navbar { background: linear-gradient(135deg, #4f46e5, #6366f1); }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .kpi-card { border-left: 4px solid; }
        .kpi-green { border-left-color: #10b981; }
        .kpi-blue { border-left-color: #3b82f6; }
        .kpi-orange { border-left-color: #f59e0b; }
        .kpi-red { border-left-color: #ef4444; }
        .kpi-purple { border-left-color: #8b5cf6; }
        .kpi-teal { border-left-color: #14b8a6; }
        .kpi-number { font-size: 2rem; font-weight: 700; }
        .quick-access-btn {
            transition: all 0.3s ease;
            height: 100%;
            min-height: 100px;
        }
        .quick-access-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .badge-notification {
            position: absolute;
            top: -5px;
            right: -5px;
            padding: 0.35em 0.6em;
            font-size: 0.75rem;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-dark mb-4">
    <div class="container-fluid">
        <span class="navbar-brand"><i class="bi bi-speedometer2 me-2"></i>Panel de Administración</span>
        <div class="d-flex align-items-center gap-3">
            <!-- ✅ RUTA SIMPLE - MISMO DIRECTORIO -->
            <a href="gestion_cursos.php" class="btn btn-outline-light btn-sm position-relative">
                <i class="bi bi-mortarboard me-1"></i>Gestión Cursos
                <?php if ($total_cursos > 0): ?>
                <span class="badge bg-warning text-dark badge-notification"><?php echo $total_cursos; ?></span>
                <?php endif; ?>
            </a>
            <span class="text-white"><i class="bi bi-person me-1"></i><?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
            <a href="../auth/logout.php" class="btn btn-outline-light btn-sm">Salir</a>
        </div>
    </div>
</nav>

<div class="container-fluid px-4">
    <!-- Alertas -->
    <?php if (!empty($alertas_leads_bajos)): ?>
    <div class="alert alert-warning alert-dismissible fade show">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <strong>Teleoperadoras con pocos leads asignados:</strong>
        <ul class="mb-0 mt-2">
            <?php foreach ($alertas_leads_bajos as $a): ?>
            <li><?php echo htmlspecialchars($a['nombre']); ?>: <?php echo $a['leads'] ?? 0; ?> leads</li>
            <?php endforeach; ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($sinAsignar > 50): ?>
    <div class="alert alert-info alert-dismissible fade show">
        <i class="bi bi-inbox me-2"></i>
        Hay <strong><?php echo $sinAsignar; ?></strong> leads sin asignar.
        <a href="asignar_leads.php" class="alert-link">Asignar ahora</a>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($cursos_pendientes > 10): ?>
    <div class="alert alert-warning alert-dismissible fade show">
        <i class="bi bi-mortarboard me-2"></i>
        Hay <strong><?php echo $cursos_pendientes; ?></strong> cursos en estado pendiente.
        <!-- ✅ RUTA SIMPLE - MISMO DIRECTORIO -->
        <a href="gestion_cursos.php" class="alert-link">Gestionar cursos</a>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- KPIs -->
    <div class="row mb-4">
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="card kpi-card kpi-green p-3">
                <h6 class="text-muted mb-2"><i class="bi bi-percent me-1"></i>Conversión</h6>
                <div class="kpi-number text-success"><?php echo $tasa; ?>%</div>
                <small class="text-muted">Interesados/Total</small>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="card kpi-card kpi-orange p-3">
                <h6 class="text-muted mb-2"><i class="bi bi-inbox me-1"></i>Sin Asignar</h6>
                <div class="kpi-number text-warning"><?php echo $sinAsignar; ?></div>
                <a href="asignar_leads.php" class="btn btn-sm btn-outline-warning mt-2">Asignar</a>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="card kpi-card kpi-red p-3">
                <h6 class="text-muted mb-2"><i class="bi bi-star me-1"></i>Interesados</h6>
                <div class="kpi-number text-danger"><?php echo $pendientes; ?></div>
                <a href="gestion_programadas.php" class="btn btn-sm btn-outline-danger mt-2">Ver</a>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="card kpi-card kpi-blue p-3">
                <h6 class="text-muted mb-2"><i class="bi bi-telephone me-1"></i>Hoy</h6>
                <div class="kpi-number text-primary"><?php echo $hoy_llamadas; ?></div>
                <small class="text-muted">Activos: <?php echo $total_activos; ?></small>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="card kpi-card kpi-purple p-3">
                <h6 class="text-muted mb-2"><i class="bi bi-mortarboard me-1"></i>Cursos</h6>
                <div class="kpi-number text-purple"><?php echo $total_cursos; ?></div>
                <!-- ✅ RUTA SIMPLE - MISMO DIRECTORIO -->
                <a href="gestion_cursos.php" class="btn btn-sm btn-outline-dark mt-2">Gestionar</a>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div class="card kpi-card kpi-teal p-3">
                <h6 class="text-muted mb-2"><i class="bi bi-exclamation-circle me-1"></i>Pendientes</h6>
                <div class="kpi-number text-info"><?php echo $cursos_pendientes; ?></div>
                <small class="text-muted">Cursos</small>
            </div>
        </div>
    </div>

    <!-- Gráficos y Estadísticas -->
    <div class="row">
        <div class="col-lg-8 mb-4">
            <div class="card p-4">
                <h5 class="mb-3"><i class="bi bi-bar-chart me-2"></i>Distribución de Estados</h5>
                <canvas id="estadosChart" height="120"></canvas>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card p-4">
                <h5 class="mb-3"><i class="bi bi-people me-2"></i>Teleoperadoras</h5>
                <div class="table-responsive">
                    <table class="table table-sm table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Nombre</th>
                                <th class="text-center">Leads</th>
                                <th class="text-center">Hoy</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($stats_teleop)): ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted">No hay teleoperadoras activas</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($stats_teleop as $t): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($t['nombre']); ?></td>
                                <td class="text-center">
                                    <span class="badge bg-<?php echo $t['leads'] <= 30 ? 'danger' : 'primary'; ?>">
                                        <?php echo $t['leads']; ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-<?php echo $t['llamadas_hoy'] > 0 ? 'success' : 'secondary'; ?>">
                                        <?php echo $t['llamadas_hoy']; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Accesos Rápidos -->
    <div class="row">
        <div class="col-12">
            <div class="card p-4">
                <h5 class="mb-3"><i class="bi bi-grid me-2"></i>Accesos Rápidos</h5>
                <div class="row g-3">
                    <div class="col-lg-2 col-md-4 col-sm-6">
                        <a href="gestion_usuarios.php" class="btn btn-outline-primary w-100 quick-access-btn">
                            <i class="bi bi-people d-block mb-2" style="font-size:2rem"></i>
                            <span class="d-block">Usuarios</span>
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6">
                        <a href="asignar_leads.php" class="btn btn-outline-success w-100 quick-access-btn">
                            <i class="bi bi-person-plus d-block mb-2" style="font-size:2rem"></i>
                            <span class="d-block">Asignar Leads</span>
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6">
                        <a href="importar_leads.php" class="btn btn-outline-info w-100 quick-access-btn">
                            <i class="bi bi-upload d-block mb-2" style="font-size:2rem"></i>
                            <span class="d-block">Importar</span>
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6">
                        <a href="gestion_estados.php" class="btn btn-outline-warning w-100 quick-access-btn">
                            <i class="bi bi-tags d-block mb-2" style="font-size:2rem"></i>
                            <span class="d-block">Estados</span>
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6">
                        <a href="reportes.php" class="btn btn-outline-secondary w-100 quick-access-btn">
                            <i class="bi bi-file-earmark-bar-graph d-block mb-2" style="font-size:2rem"></i>
                            <span class="d-block">Reportes</span>
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6">
                        <!-- ✅ RUTA SIMPLE - MISMO DIRECTORIO -->
                        <a href="gestion_cursos.php" class="btn btn-outline-dark w-100 quick-access-btn position-relative">
                            <i class="bi bi-mortarboard d-block mb-2" style="font-size:2rem"></i>
                            <span class="d-block">Cursos</span>
                            <?php if ($total_cursos > 0): ?>
                            <span class="position-absolute top-0 end-0 translate-middle badge rounded-pill bg-danger">
                                <?php echo $total_cursos; ?>
                                <span class="visually-hidden">cursos registrados</span>
                            </span>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
const ctx = document.getElementById('estadosChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_keys($datos_grafico)); ?>,
        datasets: [{
            label: 'Registros',
            data: <?php echo json_encode(array_values($datos_grafico)); ?>,
            backgroundColor: [
                '#6366f1', '#f59e0b', '#ef4444', '#10b981', 
                '#3b82f6', '#8b5cf6', '#ec4899', '#14b8a6'
            ],
            borderRadius: 8,
            borderSkipped: false,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: { display: false },
            tooltip: {
                backgroundColor: 'rgba(0,0,0,0.8)',
                padding: 12,
                cornerRadius: 8,
                titleFont: { size: 14, weight: 'bold' },
                bodyFont: { size: 13 }
            }
        },
        scales: {
            y: { 
                beginAtZero: true,
                grid: {
                    color: 'rgba(0,0,0,0.05)'
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        }
    }
});
</script>
</body>
</html>
