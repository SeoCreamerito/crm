<?php
/**
 * Asignar Leads - CRM Llamadas
 * Corregido para usar PDO
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();
requireRole('admin');

$mensaje = '';

// --- ASIGNACIÓN INDIVIDUAL ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['asignar_individual'])) {
    $lead_id = (int)$_POST['lead_id'];
    $teleoperadora_id = (int)$_POST['teleoperadora_id'];
    if ($lead_id > 0 && $teleoperadora_id > 0) {
        $stmt = $pdo->prepare("UPDATE leads_activos SET id_teleoperadora = :teleop, intentos_no_contesta = 0 WHERE id = :id");
        $stmt->execute([':teleop' => $teleoperadora_id, ':id' => $lead_id]);
        $mensaje = "✅ Lead asignado correctamente.";
    }
}

// --- ASIGNACIÓN MASIVA ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['asignar_masiva'])) {
    $teleoperadora_id = (int)$_POST['teleoperadora_id_masiva'];
    $cantidad = min(100, max(1, (int)$_POST['cantidad_leads']));
    $provincia = isset($_POST['provincia_filtro']) ? trim($_POST['provincia_filtro']) : '';
    $actividad = isset($_POST['actividad_filtro']) ? trim($_POST['actividad_filtro']) : '';

    if ($teleoperadora_id > 0) {
        $where = "id_teleoperadora IS NULL";
        $params = [];
        
        if ($provincia !== '') {
            $where .= " AND provincia = :provincia";
            $params[':provincia'] = $provincia;
        }
        if ($actividad !== '') {
            $where .= " AND actividad = :actividad";
            $params[':actividad'] = $actividad;
        }

        $sql = "SELECT id FROM leads_activos WHERE $where ORDER BY RAND() LIMIT $cantidad";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $leads = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (count($leads) > 0) {
            $placeholders = implode(',', array_fill(0, count($leads), '?'));
            $stmt = $pdo->prepare("UPDATE leads_activos SET id_teleoperadora = ?, intentos_no_contesta = 0 WHERE id IN ($placeholders)");
            $stmt->execute(array_merge([$teleoperadora_id], $leads));
            $mensaje = "✅ " . count($leads) . " leads asignados.";
        } else {
            $mensaje = "❌ No hay leads disponibles con esos filtros.";
        }
    }
}

// --- OBTENER DATOS ---

// Teleoperadoras
$stmt = $pdo->query("SELECT id, nombre, apellidos FROM usuarios WHERE rol = 'agent' AND activo = 1 ORDER BY nombre, apellidos");
$teleoperadoras = $stmt->fetchAll();

// Leads sin asignar
$stmt = $pdo->query("SELECT id, empresa, telefono1 FROM leads_activos WHERE id_teleoperadora IS NULL ORDER BY empresa LIMIT 50");
$leads_sin_asignar = $stmt->fetchAll();

// Total sin asignar
$stmt = $pdo->query("SELECT COUNT(*) FROM leads_activos WHERE id_teleoperadora IS NULL");
$total_sin_asignar = $stmt->fetchColumn();

// Provincias
$stmt = $pdo->query("SELECT DISTINCT provincia FROM leads_activos WHERE provincia IS NOT NULL AND provincia != '' ORDER BY provincia");
$provincias = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Actividades
$stmt = $pdo->query("SELECT DISTINCT actividad FROM leads_activos WHERE actividad IS NOT NULL AND actividad != '' ORDER BY actividad");
$actividades = $stmt->fetchAll(PDO::FETCH_COLUMN);

// --- RESUMEN DE ASIGNACIONES ---
$resumen = [];
foreach ($teleoperadoras as $agente) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM leads_activos WHERE id_teleoperadora = :id");
    $stmt->execute([':id' => $agente['id']]);
    $total = $stmt->fetchColumn();
    
    $resumen[] = [
        'id' => $agente['id'],
        'nombre' => $agente['nombre'],
        'apellidos' => $agente['apellidos'] ?? '',
        'leads_asignados' => (int)$total
    ];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Asignar Leads - CRM Llamadas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background: #f3f4f6; }
        .navbar { background: linear-gradient(135deg, #4f46e5, #6366f1); }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
    </style>
</head>
<body>
<nav class="navbar navbar-dark mb-4">
    <div class="container-fluid">
        <a href="dashboard.php" class="navbar-brand"><i class="bi bi-arrow-left me-2"></i>Dashboard</a>
        <span class="text-white"><i class="bi bi-person-plus me-2"></i>Asignar Leads</span>
    </div>
</nav>

<div class="container-fluid px-4">
    <?php if ($mensaje): ?>
        <div class="alert <?php echo strpos($mensaje, '❌') !== false ? 'alert-danger' : 'alert-success'; ?> alert-dismissible fade show">
            <?php echo $mensaje; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Info general -->
    <div class="alert alert-info mb-4">
        <i class="bi bi-info-circle me-2"></i>
        <strong><?php echo $total_sin_asignar; ?></strong> leads sin asignar en total
    </div>

    <!-- Resumen de asignaciones -->
    <div class="card mb-4">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <span><i class="bi bi-bar-chart me-2"></i><strong>Resumen de Asignaciones</strong></span>
            <span class="badge bg-primary"><?php echo count($resumen); ?> teleoperadoras</span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Teleoperadora</th>
                            <th class="text-center">Leads Asignados</th>
                            <th class="text-center">Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($resumen)): ?>
                            <?php foreach ($resumen as $r): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($r['nombre'] . ' ' . $r['apellidos']); ?></td>
                                <td class="text-center"><strong><?php echo $r['leads_asignados']; ?></strong></td>
                                <td class="text-center">
                                    <?php if ($r['leads_asignados'] == 0): ?>
                                        <span class="badge bg-danger">Sin leads</span>
                                    <?php elseif ($r['leads_asignados'] <= 30): ?>
                                        <span class="badge bg-warning text-dark">Menos de 30</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">OK</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted">No hay teleoperadoras activas</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Asignación individual -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white">
                    <i class="bi bi-person-check me-2"></i><strong>Asignación Individual</strong>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Seleccionar lead sin asignar</label>
                            <select name="lead_id" class="form-select" required>
                                <option value="">-- Elija un lead --</option>
                                <?php foreach ($leads_sin_asignar as $l): ?>
                                <option value="<?php echo $l['id']; ?>"><?php echo htmlspecialchars($l['empresa']); ?> (<?php echo $l['telefono1']; ?>)</option>
                                <?php endforeach; ?>
                            </select>
                            <small class="text-muted">Mostrando primeros 50</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Asignar a teleoperadora</label>
                            <select name="teleoperadora_id" class="form-select" required>
                                <option value="">-- Elija teleoperadora --</option>
                                <?php foreach ($teleoperadoras as $t): ?>
                                <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['nombre'] . ' ' . ($t['apellidos'] ?? '')); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" name="asignar_individual" class="btn btn-primary w-100">
                            <i class="bi bi-check-lg me-2"></i>Asignar Lead
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Asignación masiva -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white">
                    <i class="bi bi-people me-2"></i><strong>Asignación Masiva</strong>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Asignar a teleoperadora</label>
                            <select name="teleoperadora_id_masiva" class="form-select" required>
                                <option value="">-- Elija teleoperadora --</option>
                                <?php foreach ($teleoperadoras as $t): ?>
                                <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['nombre'] . ' ' . ($t['apellidos'] ?? '')); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Cantidad de leads</label>
                            <input type="number" name="cantidad_leads" class="form-control" value="10" min="1" max="100" required>
                            <small class="text-muted">Máximo 100 leads por asignación</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Filtrar por provincia</label>
                            <select name="provincia_filtro" class="form-select">
                                <option value="">Todas las provincias</option>
                                <?php foreach ($provincias as $p): ?>
                                <option value="<?php echo htmlspecialchars($p); ?>"><?php echo htmlspecialchars($p); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Filtrar por actividad</label>
                            <select name="actividad_filtro" class="form-select">
                                <option value="">Todas las actividades</option>
                                <?php foreach ($actividades as $a): ?>
                                <option value="<?php echo htmlspecialchars($a); ?>"><?php echo htmlspecialchars($a); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" name="asignar_masiva" class="btn btn-success w-100">
                            <i class="bi bi-people me-2"></i>Asignar Masivamente
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
