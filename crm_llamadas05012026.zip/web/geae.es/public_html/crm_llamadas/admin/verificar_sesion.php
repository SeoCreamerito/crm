<?php
/**
 * VERIFICADOR DE SESIÓN - Diagnóstico
 * Sube este archivo a /admin/ como verificar_sesion.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Verificador de Sesión</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 900px;
            margin: 40px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .success { color: #10b981; font-weight: bold; }
        .error { color: #ef4444; font-weight: bold; }
        .warning { color: #f59e0b; font-weight: bold; }
        code {
            background: #f3f4f6;
            padding: 2px 8px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th, table td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #e5e7eb;
        }
        table th {
            background: #f9fafb;
        }
        .check-item {
            padding: 12px;
            margin: 8px 0;
            border-left: 4px solid #cbd5e1;
            background: #f9fafb;
        }
        .check-item.pass {
            border-left-color: #10b981;
            background: #f0fdf4;
        }
        .check-item.fail {
            border-left-color: #ef4444;
            background: #fef2f2;
        }
    </style>
</head>
<body>

<h1>🔐 Verificador de Sesión - CRM</h1>
<p><strong>Fecha:</strong> <?php echo date('d/m/Y H:i:s'); ?></p>

<div class="card">
    <h2>1. Estado de la Sesión PHP</h2>
    <?php
    $sesion_activa = session_status() === PHP_SESSION_ACTIVE;
    ?>
    <div class="check-item <?php echo $sesion_activa ? 'pass' : 'fail'; ?>">
        <?php if ($sesion_activa): ?>
            ✅ <strong>Sesión PHP activa</strong>
            <br><small>Session ID: <?php echo session_id(); ?></small>
        <?php else: ?>
            ❌ <strong>Sesión PHP NO activa</strong>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <h2>2. Variables de Sesión</h2>
    <?php if (empty($_SESSION)): ?>
        <div class="check-item fail">
            ❌ <strong>No hay variables de sesión</strong>
            <p>Esto significa que NO has iniciado sesión.</p>
        </div>
    <?php else: ?>
        <div class="check-item pass">
            ✅ <strong>Variables de sesión presentes</strong>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Variable</th>
                    <th>Valor</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($_SESSION as $key => $value): ?>
                <tr>
                    <td><code><?php echo htmlspecialchars($key); ?></code></td>
                    <td><?php echo htmlspecialchars(is_array($value) ? json_encode($value) : $value); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<div class="card">
    <h2>3. Verificación de Autenticación</h2>
    
    <?php
    $tiene_id = isset($_SESSION['id_usuario']);
    $tiene_rol = isset($_SESSION['rol']);
    $tiene_nombre = isset($_SESSION['nombre']);
    
    $rol_actual = $_SESSION['rol'] ?? 'ninguno';
    $roles_permitidos = ['admin', 'gestion_cursos'];
    $rol_valido = in_array($rol_actual, $roles_permitidos);
    ?>
    
    <div class="check-item <?php echo $tiene_id ? 'pass' : 'fail'; ?>">
        <?php if ($tiene_id): ?>
            ✅ Tiene <code>id_usuario</code>: <?php echo $_SESSION['id_usuario']; ?>
        <?php else: ?>
            ❌ NO tiene <code>id_usuario</code>
        <?php endif; ?>
    </div>
    
    <div class="check-item <?php echo $tiene_rol ? 'pass' : 'fail'; ?>">
        <?php if ($tiene_rol): ?>
            ✅ Tiene <code>rol</code>: <strong><?php echo htmlspecialchars($rol_actual); ?></strong>
        <?php else: ?>
            ❌ NO tiene <code>rol</code>
        <?php endif; ?>
    </div>
    
    <div class="check-item <?php echo $rol_valido ? 'pass' : 'fail'; ?>">
        <?php if ($rol_valido): ?>
            ✅ El rol <strong><?php echo htmlspecialchars($rol_actual); ?></strong> tiene acceso a Gestión de Cursos
        <?php else: ?>
            ❌ El rol <strong><?php echo htmlspecialchars($rol_actual); ?></strong> NO tiene acceso
            <br><small>Roles permitidos: <?php echo implode(', ', $roles_permitidos); ?></small>
        <?php endif; ?>
    </div>
    
    <div class="check-item <?php echo $tiene_nombre ? 'pass' : 'fail'; ?>">
        <?php if ($tiene_nombre): ?>
            ✅ Tiene <code>nombre</code>: <?php echo htmlspecialchars($_SESSION['nombre']); ?>
        <?php else: ?>
            ❌ NO tiene <code>nombre</code>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <h2>4. Información de Cookies</h2>
    <?php
    $tiene_cookie_sesion = isset($_COOKIE[session_name()]);
    ?>
    <div class="check-item <?php echo $tiene_cookie_sesion ? 'pass' : 'fail'; ?>">
        <?php if ($tiene_cookie_sesion): ?>
            ✅ Cookie de sesión presente: <code><?php echo session_name(); ?></code>
        <?php else: ?>
            ❌ NO hay cookie de sesión
        <?php endif; ?>
    </div>
    
    <?php if (!empty($_COOKIE)): ?>
    <h4>Cookies disponibles:</h4>
    <table>
        <thead>
            <tr>
                <th>Cookie</th>
                <th>Valor (primeros 50 caracteres)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($_COOKIE as $name => $value): ?>
            <tr>
                <td><code><?php echo htmlspecialchars($name); ?></code></td>
                <td><?php echo htmlspecialchars(substr($value, 0, 50)); ?><?php echo strlen($value) > 50 ? '...' : ''; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<div class="card">
    <h2>5. Prueba de Acceso a Dashboard</h2>
    <p>Intenta acceder al dashboard:</p>
    <a href="dashboard.php" class="btn" style="display: inline-block; padding: 10px 20px; background: #4f46e5; color: white; text-decoration: none; border-radius: 5px;">
        Ir a Dashboard
    </a>
</div>

<div class="card" style="background: <?php echo (!$tiene_id || !$rol_valido) ? '#fef2f2' : '#f0fdf4'; ?>; border: 2px solid <?php echo (!$tiene_id || !$rol_valido) ? '#ef4444' : '#10b981'; ?>;">
    <h2>📊 Diagnóstico Final</h2>
    
    <?php if (!$sesion_activa): ?>
        <p class="error">❌ La sesión PHP no está activa</p>
        <p><strong>Solución:</strong> Verifica la configuración de PHP</p>
    
    <?php elseif (empty($_SESSION)): ?>
        <p class="error">❌ NO hay variables de sesión (no has iniciado sesión)</p>
        <p><strong>Solución:</strong></p>
        <ol>
            <li>Ve a: <a href="../auth/login.php">Login</a></li>
            <li>Inicia sesión con tu usuario</li>
            <li>Vuelve a esta página</li>
        </ol>
    
    <?php elseif (!$tiene_id): ?>
        <p class="error">❌ La sesión no tiene <code>id_usuario</code></p>
        <p><strong>Solución:</strong> Cierra sesión y vuelve a iniciar</p>
        <a href="../auth/logout.php">Cerrar Sesión</a>
    
    <?php elseif (!$tiene_rol): ?>
        <p class="error">❌ La sesión no tiene <code>rol</code></p>
        <p><strong>Solución:</strong> Verifica que tu usuario tenga un rol asignado en la base de datos</p>
    
    <?php elseif (!$rol_valido): ?>
        <p class="error">❌ Tu rol actual (<?php echo htmlspecialchars($rol_actual); ?>) no tiene acceso a Gestión de Cursos</p>
        <p><strong>Roles permitidos:</strong> <?php echo implode(', ', $roles_permitidos); ?></p>
        <p><strong>Solución:</strong> Contacta al administrador para cambiar tu rol</p>
    
    <?php else: ?>
        <p class="success">✅ ¡Todo está correcto!</p>
        <p>Deberías poder acceder a Gestión de Cursos sin problemas.</p>
        <p><strong>Prueba ahora:</strong> <a href="gestion_cursos.php">Ir a Gestión de Cursos</a></p>
    <?php endif; ?>
</div>

<div class="card">
    <h2>6. Enlaces Útiles</h2>
    <ul>
        <li><a href="../auth/login.php">Iniciar Sesión</a></li>
        <li><a href="../auth/logout.php">Cerrar Sesión</a></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="gestion_cursos.php">Gestión de Cursos</a></li>
    </ul>
</div>

<p style="text-align: center; color: #6b7280; margin-top: 40px;">
    <small>Verificador de Sesión - CRM v1.0 | <?php echo date('d/m/Y H:i:s'); ?></small>
</p>

</body>
</html>
