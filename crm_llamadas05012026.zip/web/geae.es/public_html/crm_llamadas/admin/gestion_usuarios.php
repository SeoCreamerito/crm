<?php
/**
 * Gestión de Usuarios - CRM Llamadas
 * Corregido para usar PDO
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();
requireRole('admin');

$error = '';
$success = '';

// ------------------------
// 1. CREAR USUARIO
// ------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['crear'])) {
    $nombre = trim($_POST['nombre']);
    $apellidos = trim($_POST['apellidos'] ?? '');
    $dni = trim($_POST['dni'] ?? '');
    $num_ss = !empty($_POST['num_ss']) ? trim($_POST['num_ss']) : null;
    $puesto = !empty($_POST['puesto']) ? trim($_POST['puesto']) : 'Teleoperadora';
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $rol = $_POST['rol'];

    if (empty($nombre) || empty($email) || empty($password)) {
        $error = "Nombre, email y contraseña son obligatorios.";
    } else {
        // Verificar email único
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = :email");
        $stmt->execute([':email' => $email]);
        if ($stmt->fetch()) {
            $error = "El email ya está registrado.";
        } else {
            // Verificar DNI único si se proporciona
            if (!empty($dni)) {
                $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE dni = :dni");
                $stmt->execute([':dni' => $dni]);
                if ($stmt->fetch()) {
                    $error = "El DNI ya está registrado.";
                }
            }
            
            if (empty($error)) {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("
                    INSERT INTO usuarios (nombre, apellidos, dni, num_ss, puesto, email, password, rol, activo) 
                    VALUES (:nombre, :apellidos, :dni, :num_ss, :puesto, :email, :password, :rol, 1)
                ");
                try {
                    $stmt->execute([
                        ':nombre' => $nombre,
                        ':apellidos' => $apellidos,
                        ':dni' => $dni ?: null,
                        ':num_ss' => $num_ss,
                        ':puesto' => $puesto,
                        ':email' => $email,
                        ':password' => $hashed,
                        ':rol' => $rol
                    ]);
                    $success = "Usuario creado correctamente.";
                } catch (PDOException $e) {
                    $error = "Error al crear el usuario: " . $e->getMessage();
                }
            }
        }
    }
}

// ------------------------
// 2. EDITAR USUARIO
// ------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar'])) {
    $id = (int)$_POST['id'];
    $nombre = trim($_POST['nombre']);
    $apellidos = trim($_POST['apellidos'] ?? '');
    $dni = trim($_POST['dni'] ?? '');
    $num_ss = !empty($_POST['num_ss']) ? trim($_POST['num_ss']) : null;
    $puesto = !empty($_POST['puesto']) ? trim($_POST['puesto']) : 'Teleoperadora';
    $email = trim($_POST['email']);
    $rol = $_POST['rol'];
    $activo = isset($_POST['activo']) ? 1 : 0;

    if (empty($nombre) || empty($email)) {
        $error = "Nombre y email son obligatorios.";
    } else {
        // Verificar email único (excluyendo a sí mismo)
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = :email AND id != :id");
        $stmt->execute([':email' => $email, ':id' => $id]);
        if ($stmt->fetch()) {
            $error = "El email ya está registrado por otro usuario.";
        } else {
            // Verificar DNI único si se proporciona
            if (!empty($dni)) {
                $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE dni = :dni AND id != :id");
                $stmt->execute([':dni' => $dni, ':id' => $id]);
                if ($stmt->fetch()) {
                    $error = "El DNI ya está registrado por otro usuario.";
                }
            }
            
            if (empty($error)) {
                try {
                    if (!empty($_POST['password_nueva'])) {
                        $password_hash = password_hash($_POST['password_nueva'], PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("
                            UPDATE usuarios 
                            SET nombre = :nombre, apellidos = :apellidos, dni = :dni, num_ss = :num_ss, 
                                puesto = :puesto, email = :email, password = :password, rol = :rol, activo = :activo
                            WHERE id = :id
                        ");
                        $stmt->execute([
                            ':nombre' => $nombre,
                            ':apellidos' => $apellidos,
                            ':dni' => $dni ?: null,
                            ':num_ss' => $num_ss,
                            ':puesto' => $puesto,
                            ':email' => $email,
                            ':password' => $password_hash,
                            ':rol' => $rol,
                            ':activo' => $activo,
                            ':id' => $id
                        ]);
                    } else {
                        $stmt = $pdo->prepare("
                            UPDATE usuarios 
                            SET nombre = :nombre, apellidos = :apellidos, dni = :dni, num_ss = :num_ss, 
                                puesto = :puesto, email = :email, rol = :rol, activo = :activo
                            WHERE id = :id
                        ");
                        $stmt->execute([
                            ':nombre' => $nombre,
                            ':apellidos' => $apellidos,
                            ':dni' => $dni ?: null,
                            ':num_ss' => $num_ss,
                            ':puesto' => $puesto,
                            ':email' => $email,
                            ':rol' => $rol,
                            ':activo' => $activo,
                            ':id' => $id
                        ]);
                    }
                    $success = "Usuario actualizado correctamente.";
                } catch (PDOException $e) {
                    $error = "Error al actualizar: " . $e->getMessage();
                }
            }
        }
    }
}

// ------------------------
// 3. OBTENER LISTA DE USUARIOS
// ------------------------
$stmt = $pdo->query("
    SELECT id, nombre, apellidos, dni, num_ss, puesto, email, rol, activo 
    FROM usuarios 
    ORDER BY rol, nombre, apellidos
");
$usuarios = $stmt->fetchAll();

// ------------------------
// 4. CARGAR USUARIO PARA EDITAR
// ------------------------
$usuario_editar = null;
if (isset($_GET['editar']) && is_numeric($_GET['editar'])) {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = :id");
    $stmt->execute([':id' => $_GET['editar']]);
    $usuario_editar = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuarios - CRM Llamadas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background: #f3f4f6; }
        .navbar { background: linear-gradient(135deg, #4f46e5, #6366f1); }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
    </style>
</head>
<body>
<nav class="navbar navbar-dark mb-4">
    <div class="container-fluid">
        <a href="dashboard.php" class="navbar-brand"><i class="bi bi-arrow-left me-2"></i>Dashboard</a>
        <span class="text-white"><i class="bi bi-people me-2"></i>Gestión de Usuarios</span>
    </div>
</nav>

<div class="container-fluid px-4">
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Formulario de creación o edición -->
    <div class="card mb-4">
        <div class="card-header bg-white">
            <?php if ($usuario_editar): ?>
                <i class="bi bi-pencil me-2"></i><strong>Editar Usuario:</strong> <?php echo htmlspecialchars($usuario_editar['nombre'] . ' ' . ($usuario_editar['apellidos'] ?? '')); ?>
                <a href="gestion_usuarios.php" class="btn btn-sm btn-outline-secondary float-end">Cancelar</a>
            <?php else: ?>
                <i class="bi bi-person-plus me-2"></i><strong>Añadir Nuevo Usuario</strong>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="POST">
                <?php if ($usuario_editar): ?>
                    <input type="hidden" name="editar" value="1">
                    <input type="hidden" name="id" value="<?php echo $usuario_editar['id']; ?>">
                <?php endif; ?>
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Nombre *</label>
                        <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($usuario_editar['nombre'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Apellidos</label>
                        <input type="text" name="apellidos" class="form-control" value="<?php echo htmlspecialchars($usuario_editar['apellidos'] ?? ''); ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">DNI/NIE</label>
                        <input type="text" name="dni" class="form-control" value="<?php echo htmlspecialchars($usuario_editar['dni'] ?? ''); ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Nº Seg. Social</label>
                        <input type="text" name="num_ss" class="form-control" value="<?php echo htmlspecialchars($usuario_editar['num_ss'] ?? ''); ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Puesto</label>
                        <input type="text" name="puesto" class="form-control" value="<?php echo htmlspecialchars($usuario_editar['puesto'] ?? 'Teleoperadora'); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($usuario_editar['email'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <?php if ($usuario_editar): ?>
                            <label class="form-label">Nueva Contraseña</label>
                            <input type="password" name="password_nueva" class="form-control" minlength="6">
                            <small class="text-muted">Dejar vacío para mantener la actual</small>
                        <?php else: ?>
                            <label class="form-label">Contraseña *</label>
                            <input type="password" name="password" class="form-control" minlength="6" required>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Rol *</label>
                        <select name="rol" class="form-select" required>
                            <option value="admin" <?php echo ($usuario_editar['rol'] ?? '') === 'admin' ? 'selected' : ''; ?>>Administrador</option>
                            <option value="agent" <?php echo ($usuario_editar['rol'] ?? '') === 'agent' ? 'selected' : ''; ?>>Teleoperadora</option>
                            <option value="inspeccion" <?php echo ($usuario_editar['rol'] ?? '') === 'inspeccion' ? 'selected' : ''; ?>>Inspección</option>
                            <option value="gestion_cursos" <?php echo ($usuario_editar['rol'] ?? '') === 'gestion_cursos' ? 'selected' : ''; ?>>Gestión Cursos</option>
                        </select>
                    </div>
                    <?php if ($usuario_editar): ?>
                    <div class="col-md-1">
                        <label class="form-label">Activo</label>
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" name="activo" <?php echo !empty($usuario_editar['activo']) ? 'checked' : ''; ?>>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" name="<?php echo $usuario_editar ? 'editar' : 'crear'; ?>" class="btn btn-<?php echo $usuario_editar ? 'warning' : 'success'; ?> w-100">
                            <i class="bi bi-<?php echo $usuario_editar ? 'check' : 'plus'; ?>-lg me-1"></i>
                            <?php echo $usuario_editar ? 'Actualizar' : 'Crear'; ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Lista de usuarios -->
    <div class="card">
        <div class="card-header bg-white">
            <i class="bi bi-list-ul me-2"></i><strong>Usuarios Registrados (<?php echo count($usuarios); ?>)</strong>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Nombre</th>
                            <th>DNI</th>
                            <th>Email</th>
                            <th>Rol</th>
                            <th>Activo</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $u): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($u['nombre'] . ' ' . ($u['apellidos'] ?? '')); ?></strong><br>
                                <small class="text-muted"><?php echo htmlspecialchars($u['puesto'] ?? ''); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($u['dni'] ?? '—'); ?></td>
                            <td><?php echo htmlspecialchars($u['email']); ?></td>
                            <td>
                                <?php
                                $roles = [
                                    'admin' => '<span class="badge bg-danger">Admin</span>',
                                    'agent' => '<span class="badge bg-primary">Teleoperadora</span>',
                                    'inspeccion' => '<span class="badge bg-secondary">Inspección</span>',
                                    'gestion_cursos' => '<span class="badge bg-success">Cursos</span>'
                                ];
                                echo $roles[$u['rol']] ?? $u['rol'];
                                ?>
                            </td>
                            <td>
                                <?php if ($u['activo']): ?>
                                    <i class="bi bi-check-circle-fill text-success"></i>
                                <?php else: ?>
                                    <i class="bi bi-x-circle-fill text-danger"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="gestion_usuarios.php?editar=<?php echo $u['id']; ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-pencil"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
