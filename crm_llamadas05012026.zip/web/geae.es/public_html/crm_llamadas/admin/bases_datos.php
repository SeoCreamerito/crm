<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();
requireRole('admin');

// Manejar edición de lead
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_lead'])) {
    $id = (int)$_POST['id'];
    $tabla = $_POST['tabla'] ?? 'leads_activos';
    
    if (!in_array($tabla, ['leads_activos', 'leads_no_interesa', 'leads_no_contesta', 'leads_creditos_agotados', 'leads_ellos_contestan', 'leads_ellos_llaman', 'leads_tardes', 'leads_curso'])) {
        $_SESSION['mensaje'] = "❌ Tabla no válida.";
    } else {
        // Campos a actualizar
        $campos = [
            'empresa', 'telefono1', 'telefono2', 'provincia', 'actividad', 'cif', 'direccion', 
            'poblacion', 'cp', 'tipovia', 'numerocalle', 'cnaecod', 'comunidad', 'facturacion', 
            'nr_trabajadores', 'gerentes_autonomos', 'cautonoma', 'codoperador', 'razonoperador'
        ];
        
        $updates = [];
        $params = [];
        $tipos = '';
        
        foreach ($campos as $campo) {
            if (isset($_POST[$campo])) {
                $valor = trim($_POST[$campo]);
                $updates[] = "`$campo` = ?";
                $params[] = $valor === '' ? null : $valor;
                $tipos .= 's';
            }
        }
        
        // Validación básica
        if (empty($_POST['empresa']) || empty($_POST['telefono1'])) {
            $_SESSION['mensaje'] = "❌ Empresa y Teléfono 1 son obligatorios.";
        } elseif (count($updates) > 0) {
            $updates_str = implode(', ', $updates);
            $params[] = $id;
            $tipos .= 'i';
            
            $stmt = $conexion->prepare("UPDATE `$tabla` SET $updates_str WHERE id = ?");
            $stmt->bind_param($tipos, ...$params);
            if ($stmt->execute()) {
                $_SESSION['mensaje'] = "✅ Lead actualizado correctamente.";
            } else {
                $_SESSION['mensaje'] = "❌ Error al actualizar: " . $stmt->error;
            }
        }
        
        // Redirigir para evitar reenvío
        $filtro_params = $_GET;
        $filtro_params['mensaje'] = $_SESSION['mensaje'];
        unset($_SESSION['mensaje']);
        $query_string = http_build_query($filtro_params);
        header("Location: bases_datos.php?$query_string");
        exit;
    }
}

// Tablas destino (para mover leads)
$tablas_destino = [
    'leads_no_interesa',
    'leads_no_contesta',
    'leads_creditos_agotados',
    'leads_ellos_contestan',
    'leads_ellos_llaman',
    'leads_tardes',
    'leads_curso'
];

// Tablas disponibles (estados)
$tablas_disponibles = [
    'leads_activos' => '🎯 Leads Activos (Sin procesar)',
    'leads_no_interesa' => '❌ No Interesa',
    'leads_no_contesta' => '📞 No Contesta',
    'leads_creditos_agotados' => '💳 Créditos Agotados',
    'leads_ellos_contestan' => '✅ Ellos Contestan',
    'leads_ellos_llaman' => '📞 Ellos Llaman',
    'leads_tardes' => '🌙 Tardes',
    'leads_curso' => '🎓 Curso'
];

// Manejar acciones masivas
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion_masiva'])) {
    $ids = $_POST['ids'] ?? [];
    $accion = $_POST['accion_masiva'];
    $tabla_origen = $_POST['tabla_origen'] ?? 'leads_activos';
    
    if (empty($ids)) {
        $_SESSION['mensaje'] = "❌ No se seleccionaron leads.";
    } else {
        if ($accion === 'reasignar' && isset($_POST['teleoperadora_destino'])) {
            $destino = (int)$_POST['teleoperadora_destino'];
            foreach ($ids as $id) {
                $conexion->query("UPDATE leads_activos SET id_teleoperadora = $destino, intentos_no_contesta = 0 WHERE id = " . (int)$id);
            }
            $_SESSION['mensaje'] = "✅ Leads reasignados correctamente.";
        } elseif ($accion === 'mover' && isset($_POST['tabla_destino']) && in_array($_POST['tabla_destino'], $tablas_destino)) {
            $destino = $_POST['tabla_destino'];
            foreach ($ids as $id) {
                // Copiar a tabla destino
                $lead = $conexion->query("SELECT * FROM `$tabla_origen` WHERE id = " . (int)$id)->fetch_assoc();
                if ($lead) {
                    $columns = implode(',', array_keys($lead));
                    $values = "'" . implode("','", array_map(fn($v) => $conexion->real_escape_string($v ?? ''), $lead)) . "'";
                    $conexion->query("INSERT INTO `$destino` ($columns) VALUES ($values)");
                    // Eliminar de origen
                    $conexion->query("DELETE FROM `$tabla_origen` WHERE id = " . (int)$id);
                }
            }
            $_SESSION['mensaje'] = "✅ Leads movidos a " . $tablas_disponibles[$destino] . ".";
        } elseif ($accion === 'sin_asignar' && $tabla_origen === 'leads_activos') {
            foreach ($ids as $id) {
                $conexion->query("UPDATE leads_activos SET id_teleoperadora = NULL WHERE id = " . (int)$id);
            }
            $_SESSION['mensaje'] = "✅ Leads marcados como 'Sin asignar'.";
        }
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }
}

// Mostrar mensaje si existe
$mensaje = $_SESSION['mensaje'] ?? '';
if ($mensaje) {
    unset($_SESSION['mensaje']);
}

// Teleoperadoras
$teleoperadoras = [];
$result = $conexion->query("SELECT id, nombre, apellidos FROM usuarios WHERE rol = 'agent' AND activo = 1 ORDER BY nombre, apellidos");
while ($row = $result->fetch_assoc()) {
    $teleoperadoras[] = $row;
}

// Actividades
$actividades = [];
$tabla = $_GET['tabla'] ?? 'leads_activos';
if (in_array($tabla, array_keys($tablas_disponibles))) {
    $actividad_result = $conexion->query("SELECT DISTINCT actividad FROM `$tabla` WHERE actividad IS NOT NULL AND actividad != '' ORDER BY actividad");
    while ($row = $actividad_result->fetch_assoc()) {
        $actividades[] = $row['actividad'];
    }
}

// Filtros
$teleoperadora_filtro = $_GET['teleoperadora'] ?? null;
$actividad_filtro = $_GET['actividad'] ?? null;
$busqueda_filtro = $_GET['busqueda'] ?? null;
$pagina = (int)($_GET['pagina'] ?? 1);
$por_pagina = 25;
$offset = ($pagina - 1) * $por_pagina;

// Consulta
$condiciones = "1=1";
if ($busqueda_filtro) {
    $busqueda_like = "%" . $conexion->real_escape_string($busqueda_filtro) . "%";
    $condiciones .= " AND (empresa LIKE '$busqueda_like' OR telefono1 LIKE '$busqueda_like')";
}
if ($tabla === 'leads_activos' && $teleoperadora_filtro) {
    $condiciones .= " AND id_teleoperadora = " . (int)$teleoperadora_filtro;
}
if ($actividad_filtro) {
    $condiciones .= " AND actividad = '" . $conexion->real_escape_string($actividad_filtro) . "'";
}

$count_result = $conexion->query("SELECT COUNT(*) as total FROM `$tabla` WHERE $condiciones");
$total_registros = $count_result->fetch_assoc()['total'];
$total_paginas = ceil($total_registros / $por_pagina);

$resultado = $conexion->query("SELECT * FROM `$tabla` WHERE $condiciones ORDER BY empresa LIMIT $por_pagina OFFSET $offset");
$leads = [];
if ($resultado) {
    while ($row = $resultado->fetch_assoc()) {
        $leads[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bases de Datos - CRM Llamadas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/crm_llamadas/assets/css/main.css">
    <style>
        .lead-table th, .lead-table td { vertical-align: middle; padding: 0.75rem; }
        .lead-table .btn-sm { padding: 0.25rem 0.5rem; font-size: 0.875rem; }
        .lead-table td { word-wrap: break-word; max-width: 200px; }
        .modal-lg { max-width: 900px; }
        /* Asegurar que las celdas no se expandan */
        .lead-table td, .lead-table th {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        /* Para hacer que el texto dentro de las celdas sea legible */
        .lead-table td {
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    </style>
</head>
<body>

<?php require_once '../includes/navbar.php'; ?>

<div class="container-fluid mt-3">
    <h2 class="d-flex align-items-center gap-2">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-primary">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="16" x2="16" y1="12" y2="12"></line>
            <line x1="12" x2="12" y1="12" y2="12"></line>
            <line x1="8" x2="8" y1="12" y2="12"></line>
        </svg>
        Bases de Datos - Explorador de Leads
    </h2>

    <?php if ($mensaje): ?>
        <div class="alert <?= strpos($mensaje, '❌') === 0 ? 'alert-danger' : 'alert-success' ?> mb-4">
            <?= htmlspecialchars($mensaje) ?>
        </div>
    <?php endif; ?>

    <div class="card p-4 mb-4">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label class="form-label fw-bold">Estado (Tabla)</label>
                <select name="tabla" class="form-select" onchange="this.form.submit()">
                    <?php foreach ($tablas_disponibles as $tabla_key => $label): ?>
                    <option value="<?= $tabla_key ?>" <?= ($tabla === $tabla_key) ? 'selected' : '' ?>>
                        <?= $label ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <?php if ($tabla === 'leads_activos'): ?>
            <div class="col-md-3">
                <label class="form-label fw-bold">Teleoperadora</label>
                <select name="teleoperadora" class="form-select" onchange="this.form.submit()">
                    <option value="">Todas</option>
                    <?php foreach ($teleoperadoras as $t): ?>
                    <option value="<?= $t['id'] ?>" <?= ($teleoperadora_filtro == $t['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($t['nombre'] . ' ' . $t['apellidos']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <div class="col-md-3">
                <label class="form-label fw-bold">Actividad</label>
                <select name="actividad" class="form-select" onchange="this.form.submit()">
                    <option value="">Todas</option>
                    <?php foreach ($actividades as $act): ?>
                    <option value="<?= htmlspecialchars($act) ?>" <?= ($actividad_filtro === $act) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($act) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label fw-bold">Buscar (Empresa o Teléfono)</label>
                <input type="text" name="busqueda" class="form-control" value="<?= htmlspecialchars($busqueda_filtro ?? '') ?>" placeholder="Ej: Empresa X o 611222333">
            </div>

            <div class="col-md-12 d-flex justify-content-between align-items-end">
                <button type="submit" class="btn btn-primary">🔍 Aplicar Filtros</button>
                <?php if ($busqueda_filtro || $teleoperadora_filtro || $actividad_filtro): ?>
                <a href="?tabla=<?= $tabla ?>" class="btn btn-outline-secondary">↺ Limpiar</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <?php if (!empty($leads)): ?>
        <form method="POST" id="formAccionMasiva">
            <input type="hidden" name="tabla_origen" value="<?= $tabla ?>">
            
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row g-2">
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="seleccionarTodo">
                                <label class="form-check-label" for="seleccionarTodo">Seleccionar todos</label>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="d-flex gap-2">
                                <?php if ($tabla === 'leads_activos'): ?>
                                <select name="accion_masiva" class="form-select" style="width: auto;">
                                    <option value="">Acción masiva</option>
                                    <option value="reasignar">Reasignar a teleoperadora</option>
                                    <option value="sin_asignar">Marcar como Sin asignar</option>
                                    <option value="mover">Mover a estado</option>
                                </select>
                                <select name="teleoperadora_destino" class="form-select d-none" id="selectReasignar">
                                    <option value="">-- Seleccionar --</option>
                                    <?php foreach ($teleoperadoras as $t): ?>
                                    <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['nombre'] . ' ' . $t['apellidos']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select name="tabla_destino" class="form-select d-none" id="selectMover">
                                    <option value="">-- Seleccionar estado --</option>
                                    <?php foreach ($tablas_destino as $td): ?>
                                    <option value="<?= $td ?>"><?= $tablas_disponibles[$td] ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <?php else: ?>
                                <select name="accion_masiva" class="form-select" style="width: auto;">
                                    <option value="">Acción masiva</option>
                                    <option value="mover">Mover a estado</option>
                                </select>
                                <select name="tabla_destino" class="form-select d-none" id="selectMover">
                                    <option value="">-- Seleccionar estado --</option>
                                    <?php foreach ($tablas_destino as $td): ?>
                                        <?php if ($td !== $tabla): ?>
                                    <option value="<?= $td ?>"><?= $tablas_disponibles[$td] ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                                <?php endif; ?>
                                <button type="submit" class="btn btn-success" id="btnAccionMasiva" disabled>
                                    Aplicar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?= $tablas_disponibles[$tabla] ?> <small class="text-muted">(<?= $total_registros ?> registros)</small></h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered mb-0 lead-table">
                            <thead class="table-light">
                                <tr>
                                    <th style="width: 40px;">
                                        <input type="checkbox" id="checkHeader">
                                    </th>
                                    <th>Empresa</th>
                                    <th>Teléfono 1</th>
                                    <th>Provincia</th>
                                    <th>Actividad</th>
                                    <?php if ($tabla === 'leads_activos'): ?>
                                    <th>Teleoperadora</th>
                                    <?php endif; ?>
                                    <th style="width: 160px;">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($leads as $lead): ?>
                                <tr>
                                    <td class="text-center">
                                        <input type="checkbox" name="ids[]" value="<?= $lead['id'] ?>" class="checkLead">
                                    </td>
                                    <td><?= htmlspecialchars($lead['empresa']) ?></td>
                                    <td><?= htmlspecialchars($lead['telefono1']) ?></td>
                                    <td><?= htmlspecialchars($lead['provincia'] ?? '—') ?></td>
                                    <td><?= htmlspecialchars($lead['actividad'] ?? '—') ?></td>
                                    <?php if ($tabla === 'leads_activos'): ?>
                                    <td>
                                        <?php
                                        if (!empty($lead['id_teleoperadora'])) {
                                            $teleop = $conexion->query("SELECT nombre, apellidos FROM usuarios WHERE id = " . (int)$lead['id_teleoperadora'])->fetch_assoc();
                                            echo htmlspecialchars($teleop['nombre'] . ' ' . $teleop['apellidos']);
                                        } else {
                                            echo '<span class="text-muted">—</span>';
                                        }
                                        ?>
                                    </td>
                                    <?php endif; ?>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-outline-info me-1" type="button" data-bs-toggle="modal" data-bs-target="#modal<?= $lead['id'] ?>">
                                            Ver
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning" type="button" data-bs-toggle="modal" data-bs-target="#editarModal<?= $lead['id'] ?>">
                                            Editar
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </form>

        <?php foreach ($leads as $lead): ?>
            <div class="modal fade" id="modal<?= $lead['id'] ?>" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Detalles: <?= htmlspecialchars($lead['empresa']) ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <table class="table table-sm">
                                <?php foreach ($lead as $key => $value): ?>
                                    <?php if ($value !== null && $value !== ''): ?>
                                <tr>
                                    <td width="30%"><strong><?= htmlspecialchars(str_replace('_', ' ', ucwords($key))) ?></strong></td>
                                    <td><?= htmlspecialchars($value) ?></td>
                                </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="editarModal<?= $lead['id'] ?>" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <form method="POST">
                            <input type="hidden" name="editar_lead" value="1">
                            <input type="hidden" name="id" value="<?= $lead['id'] ?>">
                            <input type="hidden" name="tabla" value="<?= $tabla ?>">
                            <div class="modal-header">
                                <h5 class="modal-title">Editar Lead: <?= htmlspecialchars($lead['empresa']) ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Empresa *</label>
                                            <input type="text" name="empresa" class="form-control" value="<?= htmlspecialchars($lead['empresa']) ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Teléfono 1 *</label>
                                            <input type="text" name="telefono1" class="form-control" value="<?= htmlspecialchars($lead['telefono1']) ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Teléfono 2</label>
                                            <input type="text" name="telefono2" class="form-control" value="<?= htmlspecialchars($lead['telefono2'] ?? '') ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">CIF</label>
                                            <input type="text" name="cif" class="form-control" value="<?= htmlspecialchars($lead['cif'] ?? '') ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Actividad</label>
                                            <input type="text" name="actividad" class="form-control" value="<?= htmlspecialchars($lead['actividad'] ?? '') ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Provincia</label>
                                            <input type="text" name="provincia" class="form-control" value="<?= htmlspecialchars($lead['provincia'] ?? '') ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Población</label>
                                            <input type="text" name="poblacion" class="form-control" value="<?= htmlspecialchars($lead['poblacion'] ?? '') ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Dirección</label>
                                            <input type="text" name="direccion" class="form-control" value="<?= htmlspecialchars($lead['direccion'] ?? '') ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Código Postal</label>
                                            <input type="text" name="cp" class="form-control" value="<?= htmlspecialchars($lead['cp'] ?? '') ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Tipo Vía</label>
                                            <input type="text" name="tipovia" class="form-control" value="<?= htmlspecialchars($lead['tipovia'] ?? '') ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Nº Calle</label>
                                            <input type="text" name="numerocalle" class="form-control" value="<?= htmlspecialchars($lead['numerocalle'] ?? '') ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">CNAE</label>
                                            <input type="text" name="cnaecod" class="form-control" value="<?= htmlspecialchars($lead['cnaecod'] ?? '') ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Comunidad</label>
                                            <input type="text" name="comunidad" class="form-control" value="<?= htmlspecialchars($lead['comunidad'] ?? '') ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Facturación</label>
                                            <input type="text" name="facturacion" class="form-control" value="<?= htmlspecialchars($lead['facturacion'] ?? '') ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Nº Trabajadores</label>
                                            <input type="text" name="nr_trabajadores" class="form-control" value="<?= htmlspecialchars($lead['nr_trabajadores'] ?? '') ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Gerentes/Autónomos</label>
                                            <input type="text" name="gerentes_autonomos" class="form-control" value="<?= htmlspecialchars($lead['gerentes_autonomos'] ?? '') ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">C. Autónoma</label>
                                            <input type="text" name="cautonoma" class="form-control" value="<?= htmlspecialchars($lead['cautonoma'] ?? '') ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Código Operador</label>
                                            <input type="text" name="codoperador" class="form-control" value="<?= htmlspecialchars($lead['codoperador'] ?? '') ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Razón Operador</label>
                                            <input type="text" name="razonoperador" class="form-control" value="<?= htmlspecialchars($lead['razonoperador'] ?? '') ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if ($total_paginas > 1): ?>
        <div class="card-footer d-flex justify-content-center">
            <nav>
                <ul class="pagination mb-0">
                    <?php if ($pagina > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?tabla=<?= $tabla ?>&<?= http_build_query(array_filter([
                            'teleoperadora' => $teleoperadora_filtro,
                            'actividad' => $actividad_filtro,
                            'busqueda' => $busqueda_filtro,
                            'pagina' => $pagina - 1
                        ])) ?>">Anterior</a>
                    </li>
                    <?php endif; ?>

                    <?php for ($i = max(1, $pagina - 2); $i <= min($total_paginas, $pagina + 2); $i++): ?>
                    <li class="page-item <?= ($i == $pagina) ? 'active' : '' ?>">
                        <a class="page-link" href="?tabla=<?= $tabla ?>&<?= http_build_query(array_filter([
                            'teleoperadora' => $teleoperadora_filtro,
                            'actividad' => $actividad_filtro,
                            'busqueda' => $busqueda_filtro,
                            'pagina' => $i
                        ])) ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>

                    <?php if ($pagina < $total_paginas): ?>
                    <li class="page-item">
                        <a class="page-link" href="?tabla=<?= $tabla ?>&<?= http_build_query(array_filter([
                            'teleoperadora' => $teleoperadora_filtro,
                            'actividad' => $actividad_filtro,
                            'busqueda' => $busqueda_filtro,
                            'pagina' => $pagina + 1
                        ])) ?>">Siguiente</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="alert alert-info text-center py-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mb-2">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" x2="12" y1="8" y2="12"></line>
                <line x1="12" x2="12.01" y1="16" y2="16"></line>
            </svg>
            <p class="mb-0">No se encontraron leads con los filtros seleccionados.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Seleccionar todos
document.getElementById('seleccionarTodo').addEventListener('change', function() {
    const checkboxes = document.querySelectorAll('.checkLead');
    checkboxes.forEach(cb => cb.checked = this.checked);
    actualizarBotonAccion();
});

// Actualizar estado del botón de acción
function actualizarBotonAccion() {
    const haySeleccionados = document.querySelectorAll('.checkLead:checked').length > 0;
    const accion = document.querySelector('[name="accion_masiva"]').value;
    document.getElementById('btnAccionMasiva').disabled = !haySeleccionados || !accion;
    
    // Mostrar/Ocultar selectores adicionales
    document.getElementById('selectReasignar').classList.toggle('d-none', accion !== 'reasignar');
    document.getElementById('selectMover').classList.toggle('d-none', accion !== 'mover');
}

// Eventos
document.querySelector('[name="accion_masiva"]').addEventListener('change', actualizarBotonAccion);
document.querySelectorAll('.checkLead').forEach(cb => cb.addEventListener('change', actualizarBotonAccion));
</script>
<script src="/crm_llamadas/assets/js/main.js"></script>
</body>
</html>