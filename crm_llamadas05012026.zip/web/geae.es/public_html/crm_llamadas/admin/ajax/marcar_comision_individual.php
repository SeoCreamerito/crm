<?php
/**
 * AJAX: Marcar Comisión Individual como Pagada/Pendiente
 * 
 * Ubicación: /admin/ajax/marcar_comision_individual.php
 */

require_once '../../includes/config.php';
require_once '../../includes/auth.php';

// Verificar que es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'admin') {
    echo json_encode(['success' => false, 'mensaje' => 'Acceso denegado']);
    exit;
}

header('Content-Type: application/json');

$id_lead = (int)($_POST['id_lead'] ?? 0);
$pagada = (int)($_POST['pagada'] ?? 0);

if ($id_lead == 0) {
    echo json_encode(['success' => false, 'mensaje' => 'ID de lead inválido']);
    exit;
}

try {
    $sql = "UPDATE leads_activos SET comision_pagada = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        throw new Exception('Error preparando consulta: ' . $conn->error);
    }
    
    $stmt->bind_param("ii", $pagada, $id_lead);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'mensaje' => $pagada ? 'Comisión marcada como pagada' : 'Comisión marcada como pendiente'
        ]);
    } else {
        throw new Exception('Error ejecutando consulta: ' . $stmt->error);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'mensaje' => 'Error: ' . $e->getMessage()
    ]);
}
?>
