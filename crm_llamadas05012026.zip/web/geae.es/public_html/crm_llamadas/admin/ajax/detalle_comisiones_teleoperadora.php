<?php
/**
 * AJAX: Detalle de Comisiones por Teleoperadora
 * 
 * Muestra el listado detallado de todas las ventas de cursos
 * realizadas por una teleoperadora en un período específico
 */

require_once '../../includes/config.php';
require_once '../../includes/auth.php';

verificarRol(['admin']);

$id_teleoperadora = isset($_POST['id_teleoperadora']) ? (int)$_POST['id_teleoperadora'] : 0;
$mes = isset($_POST['mes']) ? (int)$_POST['mes'] : date('m');
$anio = isset($_POST['anio']) ? (int)$_POST['anio'] : date('Y');

if ($id_teleoperadora == 0) {
    echo '<div class="alert alert-danger">ID de teleoperadora inválido</div>';
    exit;
}

// Obtener ventas del período
$sql = "SELECT 
    l.id,
    l.empresa,
    l.nombre_curso,
    l.nombre_alumno,
    l.dni_alumno,
    l.credito_formacion,
    l.importe_comision,
    l.comision_pagada,
    l.fecha_cierre_venta,
    l.estado_curso,
    l.fecha_inicio,
    l.fecha_fin
FROM leads_activos l
WHERE l.id_teleoperadora_origen = ?
  AND l.nombre_curso IS NOT NULL
  AND MONTH(l.fecha_cierre_venta) = ?
  AND YEAR(l.fecha_cierre_venta) = ?
ORDER BY l.fecha_cierre_venta DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $id_teleoperadora, $mes, $anio);
$stmt->execute();
$result = $stmt->get_result();

$ventas = [];
$total_creditos = 0;
$total_comisiones = 0;
$comisiones_pagadas = 0;
$comisiones_pendientes = 0;

while ($row = $result->fetch_assoc()) {
    $ventas[] = $row;
    $total_creditos += $row['credito_formacion'];
    $total_comisiones += $row['importe_comision'];
    
    if ($row['comision_pagada'] == 1) {
        $comisiones_pagadas += $row['importe_comision'];
    } else {
        $comisiones_pendientes += $row['importe_comision'];
    }
}

$stmt->close();
?>

<!-- Resumen -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-light">
            <div class="card-body text-center">
                <h6 class="text-muted">Total Ventas</h6>
                <h4><?= count($ventas) ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-light">
            <div class="card-body text-center">
                <h6 class="text-muted">Créditos Vendidos</h6>
                <h4><?= number_format($total_creditos, 2) ?>€</h4>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body text-center">
                <h6>Comisiones Pagadas</h6>
                <h4><?= number_format($comisiones_pagadas, 2) ?>€</h4>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning">
            <div class="card-body text-center">
                <h6>Comisiones Pendientes</h6>
                <h4><?= number_format($comisiones_pendientes, 2) ?>€</h4>
            </div>
        </div>
    </div>
</div>

<!-- Tabla de ventas -->
<?php if (count($ventas) > 0): ?>
<div class="table-responsive">
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th>Fecha Venta</th>
                <th>Empresa</th>
                <th>Curso</th>
                <th>Alumno</th>
                <th>DNI</th>
                <th>Crédito</th>
                <th>Comisión</th>
                <th>Estado Curso</th>
                <th>Pago</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($ventas as $venta): ?>
            <tr>
                <td><?= date('d/m/Y', strtotime($venta['fecha_cierre_venta'])) ?></td>
                <td>
                    <strong><?= htmlspecialchars($venta['empresa']) ?></strong>
                </td>
                <td><?= htmlspecialchars($venta['nombre_curso']) ?></td>
                <td><?= htmlspecialchars($venta['nombre_alumno']) ?></td>
                <td><?= htmlspecialchars($venta['dni_alumno']) ?></td>
                <td><?= number_format($venta['credito_formacion'], 2) ?>€</td>
                <td><strong><?= number_format($venta['importe_comision'], 2) ?>€</strong></td>
                <td>
                    <?php
                    $estado_badges = [
                        'pendiente' => 'warning',
                        'en_proceso' => 'info',
                        'completado' => 'success',
                        'cancelado' => 'danger'
                    ];
                    $badge = $estado_badges[$venta['estado_curso']] ?? 'secondary';
                    ?>
                    <span class="badge bg-<?= $badge ?>">
                        <?= ucfirst($venta['estado_curso']) ?>
                    </span>
                </td>
                <td>
                    <?php if ($venta['comision_pagada'] == 1): ?>
                    <span class="badge bg-success">
                        <i class="bi bi-check-circle"></i> Pagada
                    </span>
                    <?php else: ?>
                    <span class="badge bg-warning text-dark">
                        <i class="bi bi-clock"></i> Pendiente
                    </span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($venta['comision_pagada'] == 0): ?>
                    <button class="btn btn-sm btn-success btn-marcar-pagada" 
                            data-id="<?= $venta['id'] ?>">
                        <i class="bi bi-check"></i>
                    </button>
                    <?php else: ?>
                    <button class="btn btn-sm btn-outline-secondary btn-desmarcar-pagada" 
                            data-id="<?= $venta['id'] ?>">
                        <i class="bi bi-x"></i>
                    </button>
                    <?php endif; ?>
                    
                    <a href="../cursos/detalle_curso.php?id=<?= $venta['id'] ?>" 
                       class="btn btn-sm btn-outline-primary"
                       target="_blank">
                        <i class="bi bi-eye"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr class="table-primary">
                <th colspan="5" class="text-end">TOTALES:</th>
                <th><?= number_format($total_creditos, 2) ?>€</th>
                <th><strong><?= number_format($total_comisiones, 2) ?>€</strong></th>
                <th colspan="3"></th>
            </tr>
        </tfoot>
    </table>
</div>

<script>
// Marcar comisión individual como pagada
$('.btn-marcar-pagada').on('click', function() {
    const idLead = $(this).data('id');
    const btn = $(this);
    
    $.ajax({
        url: 'marcar_comision_individual.php',
        type: 'POST',
        data: { id_lead: idLead, pagada: 1 },
        success: function(response) {
            if (response.success) {
                btn.closest('tr').find('td:nth-child(9)').html(
                    '<span class="badge bg-success"><i class="bi bi-check-circle"></i> Pagada</span>'
                );
                btn.replaceWith(
                    '<button class="btn btn-sm btn-outline-secondary btn-desmarcar-pagada" data-id="' + idLead + '">' +
                    '<i class="bi bi-x"></i></button>'
                );
                
                Swal.fire({
                    icon: 'success',
                    title: '¡Marcada como pagada!',
                    timer: 1500,
                    showConfirmButton: false
                });
            }
        }
    });
});

// Desmarcar comisión como pagada
$(document).on('click', '.btn-desmarcar-pagada', function() {
    const idLead = $(this).data('id');
    const btn = $(this);
    
    Swal.fire({
        title: '¿Desmarcar como pagada?',
        text: 'La comisión volverá a estar pendiente',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, desmarcar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'marcar_comision_individual.php',
                type: 'POST',
                data: { id_lead: idLead, pagada: 0 },
                success: function(response) {
                    if (response.success) {
                        btn.closest('tr').find('td:nth-child(9)').html(
                            '<span class="badge bg-warning text-dark"><i class="bi bi-clock"></i> Pendiente</span>'
                        );
                        btn.replaceWith(
                            '<button class="btn btn-sm btn-success btn-marcar-pagada" data-id="' + idLead + '">' +
                            '<i class="bi bi-check"></i></button>'
                        );
                        
                        Swal.fire({
                            icon: 'success',
                            title: 'Desmarcada',
                            timer: 1500,
                            showConfirmButton: false
                        });
                    }
                }
            });
        }
    });
});
</script>

<?php else: ?>
<div class="alert alert-info">
    <i class="bi bi-info-circle"></i> No hay ventas registradas en este período para esta teleoperadora.
</div>
<?php endif; ?>
