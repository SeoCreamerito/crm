<?php
/**
 * ELIMINAR ITEM DE CATÁLOGO
 * Ubicación: /admin/ajax/eliminar_catalogo.php
 */

require_once '../../includes/config.php';

header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['id_usuario']) || $_SESSION['rol'] != 'admin') {
    echo json_encode(['success' => false, 'mensaje' => 'Acceso denegado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $id = (int)($_POST['id'] ?? 0);
    $tabla = $_POST['tabla'] ?? '';
    
    // Validar tabla permitida
    $tablas_permitidas = ['tipos_regalos', 'tipos_puestos', 'tipos_titulaciones'];
    if (!in_array($tabla, $tablas_permitidas)) {
        echo json_encode(['success' => false, 'mensaje' => 'Tabla no válida']);
        exit;
    }
    
    // Validar ID
    if ($id == 0) {
        echo json_encode(['success' => false, 'mensaje' => 'ID no válido']);
        exit;
    }
    
    // Eliminar
    $sql = "DELETE FROM {$tabla} WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        echo json_encode(['success' => false, 'mensaje' => 'Error al preparar consulta']);
        exit;
    }
    
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'mensaje' => 'Item eliminado correctamente'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'mensaje' => 'Error al eliminar: ' . $stmt->error
        ]);
    }
    
    $stmt->close();
}
?>
