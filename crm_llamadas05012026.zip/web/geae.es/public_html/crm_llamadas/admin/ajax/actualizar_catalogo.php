<?php
/**
 * ACTUALIZAR ITEM DE CATÁLOGO
 * Ubicación: /admin/ajax/actualizar_catalogo.php
 */

require_once '../../includes/config.php';

header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['id_usuario']) || $_SESSION['rol'] != 'admin') {
    echo json_encode(['success' => false, 'mensaje' => 'Acceso denegado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $id = (int)($_POST['id'] ?? 0);
    $tabla = $_POST['tabla'] ?? '';
    $catalogo = $_POST['catalogo'] ?? '';
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $orden = (int)($_POST['orden'] ?? 0);
    $activo = (int)($_POST['activo'] ?? 1);
    
    // Validar tabla permitida
    $tablas_permitidas = ['tipos_regalos', 'tipos_puestos', 'tipos_titulaciones'];
    if (!in_array($tabla, $tablas_permitidas)) {
        echo json_encode(['success' => false, 'mensaje' => 'Tabla no válida']);
        exit;
    }
    
    // Validar
    if ($id == 0 || empty($nombre)) {
        echo json_encode(['success' => false, 'mensaje' => 'Datos incompletos']);
        exit;
    }
    
    // Actualizar
    $sql = "UPDATE {$tabla} SET nombre = ?, descripcion = ?, orden = ?, activo = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        echo json_encode(['success' => false, 'mensaje' => 'Error al preparar consulta']);
        exit;
    }
    
    $stmt->bind_param("ssiii", $nombre, $descripcion, $orden, $activo, $id);
    
    if ($stmt->execute()) {
        $_SESSION['mensaje_exito'] = "✅ Item actualizado correctamente";
        header("Location: ../catalogos.php?catalogo={$catalogo}");
    } else {
        $_SESSION['mensaje_error'] = "Error al actualizar: " . $stmt->error;
        header("Location: ../catalogos.php?catalogo={$catalogo}");
    }
    
    $stmt->close();
    exit;
}
?>
