<?php
/**
 * AJAX: Marcar Comisiones como Pagadas (Masivo)
 * 
 * Ubicación: /admin/ajax/marcar_comisiones_pagadas.php
 */

require_once '../../includes/config.php';
require_once '../../includes/auth.php';

// Verificar que es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'admin') {
    echo json_encode(['success' => false, 'mensaje' => 'Acceso denegado']);
    exit;
}

header('Content-Type: application/json');

$teleoperadoras = $_POST['teleoperadoras'] ?? [];
$mes = (int)($_POST['mes'] ?? date('m'));
$anio = (int)($_POST['anio'] ?? date('Y'));

if (empty($teleoperadoras)) {
    echo json_encode(['success' => false, 'mensaje' => 'No se seleccionaron teleoperadoras']);
    exit;
}

try {
    $placeholders = implode(',', array_fill(0, count($teleoperadoras), '?'));
    
    $sql = "UPDATE leads_activos 
            SET comision_pagada = 1
            WHERE id_teleoperadora_origen IN ($placeholders)
              AND MONTH(fecha_cierre_venta) = ?
              AND YEAR(fecha_cierre_venta) = ?
              AND nombre_curso IS NOT NULL";
    
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        throw new Exception('Error preparando consulta: ' . $conn->error);
    }
    
    // Bind parameters dinámicamente
    $types = str_repeat('i', count($teleoperadoras)) . 'ii';
    $params = array_merge($teleoperadoras, [$mes, $anio]);
    $stmt->bind_param($types, ...$params);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'mensaje' => 'Comisiones marcadas como pagadas correctamente',
            'registros_actualizados' => $stmt->affected_rows
        ]);
    } else {
        throw new Exception('Error ejecutando consulta: ' . $stmt->error);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'mensaje' => 'Error: ' . $e->getMessage()
    ]);
}
?>
