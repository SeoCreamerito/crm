<?php
/**
 * GUARDAR ITEM DE CATÁLOGO
 * Ubicación: /admin/ajax/guardar_catalogo.php
 */

require_once '../../includes/config.php';

header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['id_usuario']) || $_SESSION['rol'] != 'admin') {
    echo json_encode(['success' => false, 'mensaje' => 'Acceso denegado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $tabla = $_POST['tabla'] ?? '';
    $catalogo = $_POST['catalogo'] ?? '';
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $orden = (int)($_POST['orden'] ?? 0);
    $activo = (int)($_POST['activo'] ?? 1);
    
    // Validar tabla permitida
    $tablas_permitidas = ['tipos_regalos', 'tipos_puestos', 'tipos_titulaciones'];
    if (!in_array($tabla, $tablas_permitidas)) {
        echo json_encode(['success' => false, 'mensaje' => 'Tabla no válida']);
        exit;
    }
    
    // Validar nombre
    if (empty($nombre)) {
        echo json_encode(['success' => false, 'mensaje' => 'El nombre es obligatorio']);
        exit;
    }
    
    // Insertar
    $sql = "INSERT INTO {$tabla} (nombre, descripcion, orden, activo) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        echo json_encode(['success' => false, 'mensaje' => 'Error al preparar consulta']);
        exit;
    }
    
    $stmt->bind_param("ssii", $nombre, $descripcion, $orden, $activo);
    
    if ($stmt->execute()) {
        $_SESSION['mensaje_exito'] = "✅ Item creado correctamente";
        header("Location: ../catalogos.php?catalogo={$catalogo}");
    } else {
        $_SESSION['mensaje_error'] = "Error al guardar: " . $stmt->error;
        header("Location: ../catalogos.php?catalogo={$catalogo}");
    }
    
    $stmt->close();
    exit;
}
?>
