<?php
/**
 * COMISIONES.PHP - VERSION DEBUG
 * Usar temporalmente para ver errores
 */

// Mostrar todos los errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "1. Script iniciado<br>";

// Verificar que config.php existe
if (!file_exists('../includes/config.php')) {
    die("ERROR: No se encuentra ../includes/config.php<br>Ruta actual: " . __DIR__);
}
echo "2. config.php encontrado<br>";

require_once '../includes/config.php';
echo "3. config.php cargado<br>";

// Verificar conexión a BD
if (!isset($conn)) {
    die("ERROR: Variable \$conn no está definida en config.php");
}
echo "4. Conexión a BD OK<br>";

// Verificar que auth.php existe
if (!file_exists('../includes/auth.php')) {
    die("ERROR: No se encuentra ../includes/auth.php");
}
echo "5. auth.php encontrado<br>";

require_once '../includes/auth.php';
echo "6. auth.php cargado<br>";

// Verificar sesión
if (!isset($_SESSION)) {
    session_start();
}
echo "7. Sesión iniciada<br>";

// Verificar usuario logueado
if (!isset($_SESSION['id_usuario'])) {
    die("ERROR: No hay usuario logueado. Debes iniciar sesión primero.");
}
echo "8. Usuario logueado: ID " . $_SESSION['id_usuario'] . "<br>";

// Verificar rol
if (!isset($_SESSION['rol'])) {
    die("ERROR: No se encontró el rol del usuario");
}
echo "9. Rol del usuario: " . $_SESSION['rol'] . "<br>";

// Verificar que es admin
if ($_SESSION['rol'] != 'admin') {
    die("ERROR: Solo los administradores pueden acceder a esta página. Tu rol es: " . $_SESSION['rol']);
}
echo "10. Usuario es administrador ✓<br>";

// Probar consulta simple
echo "<br><strong>Probando consulta a la base de datos...</strong><br>";

$sql = "SELECT COUNT(*) as total FROM leads_activos WHERE nombre_curso IS NOT NULL";
$result = $conn->query($sql);

if (!$result) {
    die("ERROR en la consulta: " . $conn->error);
}

$row = $result->fetch_assoc();
echo "11. Total de cursos en la BD: " . $row['total'] . "<br>";

// Probar que las columnas existen
echo "<br><strong>Verificando columnas de trazabilidad...</strong><br>";

$columnas = ['id_teleoperadora_origen', 'fecha_cierre_venta', 'comision_pagada', 'importe_comision'];

foreach ($columnas as $col) {
    $sql = "SELECT $col FROM leads_activos LIMIT 1";
    $result = $conn->query($sql);
    if ($result) {
        echo "✓ Columna '$col' existe<br>";
    } else {
        echo "✗ ERROR: Columna '$col' NO existe: " . $conn->error . "<br>";
    }
}

echo "<br><strong>✅ DIAGNÓSTICO COMPLETADO</strong><br>";
echo "<strong>Si ves este mensaje, el problema está en el HTML/JavaScript del archivo original.</strong><br>";
echo "<br><a href='comisiones_original.php'>Probar versión original</a>";
?>
