<?php
/**
 * Importador de Leads - CRM Llamadas
 * Corregido para usar PDO
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();
requireRole('admin');

// Función para convertir archivo CSV a UTF-8 sin BOM
function convertCsvToUtf8($inputFile) {
    $content = file_get_contents($inputFile);
    
    // Eliminar BOM si existe
    $bom = pack('H*', 'EFBBBF');
    if (substr($content, 0, 3) === $bom) {
        $content = substr($content, 3);
    }
    
    // Detectar codificación
    $detected = mb_detect_encoding($content, ['UTF-8', 'ISO-8859-1', 'Windows-1252'], true);
    
    // Convertir a UTF-8 si no lo está
    if ($detected && $detected !== 'UTF-8') {
        $content = mb_convert_encoding($content, 'UTF-8', $detected);
    }
    
    // Guardar archivo convertido
    $outputFile = tempnam(sys_get_temp_dir(), 'utf8_');
    file_put_contents($outputFile, $content);
    
    return $outputFile;
}

// Función para limpiar caracteres inválidos
function cleanUtf8($value) {
    if ($value === null || $value === '') {
        return null;
    }
    
    $value = preg_replace('/[^\x{0009}\x{000a}\x{000d}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}]+/u', '', $value);
    
    return $value === '' ? null : $value;
}

// Función para verificar teléfono en cualquier tabla (PDO)
function telefonoExisteEnCualquierTablaPDO($pdo, $telefono) {
    $tablas = ['leads_activos', 'leads_no_contesta', 'leads_creditos_agotados', 
               'leads_no_interesa', 'leads_interesados', 'leads_curso',
               'leads_ellos_contestan', 'leads_ellos_llaman', 'leads_tardes'];
    
    foreach ($tablas as $tabla) {
        try {
            $stmt = $pdo->prepare("SELECT id FROM $tabla WHERE telefono1 = :tel OR telefono2 = :tel LIMIT 1");
            $stmt->execute([':tel' => $telefono]);
            if ($stmt->fetch()) {
                return true;
            }
        } catch (PDOException $e) {
            // Tabla no existe, continuar
        }
    }
    return false;
}

// Función para limpiar teléfono español
function cleanSpanishPhoneLocal($phone) {
    if (!$phone) return null;
    $cleaned = preg_replace('/[^\d]/', '', $phone);
    if (strlen($cleaned) === 9 && in_array($cleaned[0], ['6', '7', '8', '9'])) {
        return $cleaned;
    }
    return null;
}

// Definir campos de la base de datos
$dbFields = [
    ['value' => '', 'label' => '-- No importar --', 'required' => false],
    ['value' => 'actividad', 'label' => 'Actividad', 'required' => false],
    ['value' => 'empresa', 'label' => 'Empresa', 'required' => true],
    ['value' => 'tipovia', 'label' => 'Tipo Vía', 'required' => false],
    ['value' => 'direccion', 'label' => 'Dirección', 'required' => false],
    ['value' => 'numerocalle', 'label' => 'Número Calle', 'required' => false],
    ['value' => 'poblacion', 'label' => 'Población', 'required' => false],
    ['value' => 'provincia', 'label' => 'Provincia', 'required' => false],
    ['value' => 'cp', 'label' => 'Código Postal', 'required' => false],
    ['value' => 'telefono1', 'label' => 'Teléfono 1', 'required' => true],
    ['value' => 'telefono2', 'label' => 'Teléfono 2', 'required' => false],
    ['value' => 'cnaecod', 'label' => 'CNAE', 'required' => false],
    ['value' => 'comunidad', 'label' => 'Comunidad Autónoma', 'required' => false],
    ['value' => 'facturacion', 'label' => 'Facturación', 'required' => false],
    ['value' => 'nr_trabajadores', 'label' => 'Nº Trabajadores', 'required' => false],
    ['value' => 'cif', 'label' => 'CIF', 'required' => false],
    ['value' => 'gerentes_autonomos', 'label' => 'Gerentes/Autónomos', 'required' => false],
    ['value' => 'cautonoma', 'label' => 'C. Autónoma (Código)', 'required' => false],
    ['value' => 'codoperador', 'label' => 'Código Operador', 'required' => false],
    ['value' => 'razonoperador', 'label' => 'Razón Operador', 'required' => false],
    ['value' => 'email', 'label' => 'Email', 'required' => false]
];

// Sugerencias automáticas
function autoSuggestMapping($header) {
    $normalized = strtolower(trim($header));
    $suggestions = [
        'actividad' => 'actividad',
        'empresa' => 'empresa',
        'tipo via' => 'tipovia',
        'tipovia' => 'tipovia',
        'direccion' => 'direccion',
        'dirección' => 'direccion',
        'numero' => 'numerocalle',
        'numerocalle' => 'numerocalle',
        'poblacion' => 'poblacion',
        'población' => 'poblacion',
        'provincia' => 'provincia',
        'cp' => 'cp',
        'codigo postal' => 'cp',
        'telefono' => 'telefono1',
        'teléfono' => 'telefono1',
        'telefono1' => 'telefono1',
        'tlf' => 'telefono1',
        'telefono2' => 'telefono2',
        'teléfono2' => 'telefono2',
        'cnae' => 'cnaecod',
        'cnaecod' => 'cnaecod',
        'comunidad' => 'comunidad',
        'facturacion' => 'facturacion',
        'facturación' => 'facturacion',
        'trabajadores' => 'nr_trabajadores',
        'nr_trabajadores' => 'nr_trabajadores',
        'cif' => 'cif',
        'gerentes' => 'gerentes_autonomos',
        'autonomos' => 'gerentes_autonomos',
        'cautonoma' => 'cautonoma',
        'codoperador' => 'codoperador',
        'razonoperador' => 'razonoperador',
        'email' => 'email',
        'mail' => 'email',
        'correo' => 'email'
    ];
    return $suggestions[$normalized] ?? '';
}

$currentStep = $_POST['step'] ?? ($_SESSION['import_step'] ?? 1);
$mensaje = '';

// Resetear si se pide
if (isset($_GET['step']) && $_GET['step'] == 1) {
    unset($_SESSION['archivo_csv'], $_SESSION['separator'], $_SESSION['headers'], 
          $_SESSION['preview'], $_SESSION['mapping'], $_SESSION['import_step']);
    $currentStep = 1;
}

// Paso 1: Subir y convertir archivo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $currentStep == 1 && isset($_FILES['archivo_csv'])) {
    $archivo = $_FILES['archivo_csv'];
    if ($archivo['error'] === UPLOAD_ERR_OK) {
        $tempFile = tempnam(sys_get_temp_dir(), 'import_');
        if (move_uploaded_file($archivo['tmp_name'], $tempFile)) {
            $utf8File = convertCsvToUtf8($tempFile);
            unlink($tempFile);
            
            $contenido = file_get_contents($utf8File);
            $lineas = array_filter(explode("\n", $contenido));
            
            if (!empty($lineas)) {
                $sep = strpos($lineas[0], ';') !== false ? ';' : ',';
                $headers = str_getcsv($lineas[0], $sep, '"', "\\");
                $preview = [];
                for ($i = 1; $i <= min(3, count($lineas) - 1); $i++) {
                    $preview[] = str_getcsv($lineas[$i], $sep, '"', "\\");
                }
                
                $_SESSION['archivo_csv'] = $utf8File;
                $_SESSION['separator'] = $sep;
                $_SESSION['headers'] = $headers;
                $_SESSION['preview'] = $preview;
                
                $mapping = [];
                foreach ($headers as $header) {
                    $mapping[] = autoSuggestMapping($header);
                }
                $_SESSION['mapping'] = $mapping;
                
                $_SESSION['import_step'] = 2;
                header("Location: importar_leads.php");
                exit;
            } else {
                $mensaje = "❌ Archivo vacío.";
            }
        }
    }
}

// Paso 2: Guardar mapeo y avanzar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $currentStep == 2) {
    if (isset($_POST['mapping'])) {
        $_SESSION['mapping'] = $_POST['mapping'];
        $_SESSION['import_step'] = 3;
        header("Location: importar_leads.php");
        exit;
    }
}

// Paso 3: Importar
if ($currentStep == 3) {
    if (isset($_SESSION['archivo_csv'])) {
        $archivo = $_SESSION['archivo_csv'];
        $sep = $_SESSION['separator'];
        $headers = $_SESSION['headers'];
        $mapping = $_SESSION['mapping'];
        
        $leads_importados = 0;
        $leads_errores = 0;
        $leads_duplicados = 0;
        $errores_detalles = [];
        $duplicados_detalles = [];
        
        if (!file_exists($archivo)) {
            $mensaje = "❌ Error: Archivo temporal no disponible.";
            $currentStep = 1;
        } else {
            $contenido = file_get_contents($archivo);
            $lineas = array_filter(explode("\n", $contenido));
            
            $requiredFields = ['empresa', 'telefono1'];
            $mappedFields = array_filter($mapping);
            $missingFields = array_diff($requiredFields, $mappedFields);
            
            if (!empty($missingFields)) {
                $mensaje = "❌ Faltan campos obligatorios: " . implode(', ', $missingFields);
                $currentStep = 2;
                $_SESSION['import_step'] = 2;
            } else {
                // Preparar statement una sola vez
                $stmt = $pdo->prepare("
                    INSERT INTO leads_activos (
                        empresa, telefono1, telefono2, cif, actividad, tipovia, direccion, 
                        numerocalle, poblacion, provincia, cp, cnaecod, comunidad, 
                        facturacion, nr_trabajadores, gerentes_autonomos, cautonoma, 
                        codoperador, razonoperador, email
                    ) VALUES (
                        :empresa, :telefono1, :telefono2, :cif, :actividad, :tipovia, :direccion,
                        :numerocalle, :poblacion, :provincia, :cp, :cnaecod, :comunidad,
                        :facturacion, :nr_trabajadores, :gerentes_autonomos, :cautonoma,
                        :codoperador, :razonoperador, :email
                    )
                ");
                
                for ($i = 1; $i < count($lineas); $i++) {
                    $fila = str_getcsv($lineas[$i], $sep, '"', "\\");
                    if (count($fila) < 2) continue;
                    
                    $leadData = [];
                    foreach ($mapping as $idx => $campo) {
                        if ($campo && isset($fila[$idx])) {
                            $valor = trim($fila[$idx]);
                            $leadData[$campo] = ($valor === '') ? null : $valor;
                        }
                    }
                    
                    if (empty($leadData['empresa']) || empty($leadData['telefono1'])) {
                        $errores_detalles[] = ['fila' => $i + 1, 'error' => 'Empresa o Teléfono 1 vacío'];
                        $leads_errores++;
                        continue;
                    }
                    
                    $telefono1_clean = cleanSpanishPhoneLocal($leadData['telefono1']);
                    if (!$telefono1_clean) {
                        $errores_detalles[] = ['fila' => $i + 1, 'error' => 'Teléfono 1 inválido: ' . $leadData['telefono1']];
                        $leads_errores++;
                        continue;
                    }
                    
                    if (telefonoExisteEnCualquierTablaPDO($pdo, $telefono1_clean)) {
                        $duplicados_detalles[] = ['fila' => $i + 1, 'telefono' => $telefono1_clean];
                        $leads_duplicados++;
                        continue;
                    }
                    
                    try {
                        $stmt->execute([
                            ':empresa' => cleanUtf8($leadData['empresa']),
                            ':telefono1' => $telefono1_clean,
                            ':telefono2' => isset($leadData['telefono2']) ? cleanSpanishPhoneLocal($leadData['telefono2']) : null,
                            ':cif' => cleanUtf8($leadData['cif'] ?? null),
                            ':actividad' => cleanUtf8($leadData['actividad'] ?? null),
                            ':tipovia' => cleanUtf8($leadData['tipovia'] ?? null),
                            ':direccion' => cleanUtf8($leadData['direccion'] ?? null),
                            ':numerocalle' => cleanUtf8($leadData['numerocalle'] ?? null),
                            ':poblacion' => cleanUtf8($leadData['poblacion'] ?? null),
                            ':provincia' => cleanUtf8($leadData['provincia'] ?? null),
                            ':cp' => cleanUtf8($leadData['cp'] ?? null),
                            ':cnaecod' => cleanUtf8($leadData['cnaecod'] ?? null),
                            ':comunidad' => cleanUtf8($leadData['comunidad'] ?? null),
                            ':facturacion' => cleanUtf8($leadData['facturacion'] ?? null),
                            ':nr_trabajadores' => cleanUtf8($leadData['nr_trabajadores'] ?? null),
                            ':gerentes_autonomos' => cleanUtf8($leadData['gerentes_autonomos'] ?? null),
                            ':cautonoma' => cleanUtf8($leadData['cautonoma'] ?? null),
                            ':codoperador' => cleanUtf8($leadData['codoperador'] ?? null),
                            ':razonoperador' => cleanUtf8($leadData['razonoperador'] ?? null),
                            ':email' => cleanUtf8($leadData['email'] ?? null)
                        ]);
                        $leads_importados++;
                    } catch (PDOException $e) {
                        $errores_detalles[] = ['fila' => $i + 1, 'error' => 'Error BD: ' . $e->getMessage()];
                        $leads_errores++;
                    }
                }
                
                $mensaje = "✅ Importación completada:<br>
                          • <strong>$leads_importados</strong> leads importados<br>
                          • <strong>$leads_errores</strong> con errores<br>
                          • <strong>$leads_duplicados</strong> duplicados omitidos";
                
                if (file_exists($archivo)) {
                    unlink($archivo);
                }
                unset($_SESSION['archivo_csv'], $_SESSION['separator'], $_SESSION['headers'], 
                      $_SESSION['preview'], $_SESSION['mapping'], $_SESSION['import_step']);
            }
        }
    }
    $currentStep = 4;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Importador de Leads - CRM Llamadas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background: #f3f4f6; }
        .navbar { background: linear-gradient(135deg, #4f46e5, #6366f1); }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .step-indicator { display: flex; gap: 1rem; margin-bottom: 2rem; }
        .step { padding: 0.5rem 1rem; border-radius: 20px; background: #e5e7eb; color: #6b7280; }
        .step.active { background: #4f46e5; color: white; }
        .step.completed { background: #10b981; color: white; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark mb-4">
    <div class="container-fluid">
        <a href="dashboard.php" class="navbar-brand"><i class="bi bi-arrow-left me-2"></i>Dashboard</a>
        <span class="text-white"><i class="bi bi-upload me-2"></i>Importar Leads</span>
    </div>
</nav>

<div class="container-fluid px-4">
    <!-- Steps -->
    <div class="step-indicator">
        <span class="step <?php echo $currentStep >= 1 ? ($currentStep > 1 ? 'completed' : 'active') : ''; ?>">
            <i class="bi bi-upload me-1"></i>1. Subir
        </span>
        <span class="step <?php echo $currentStep >= 2 ? ($currentStep > 2 ? 'completed' : 'active') : ''; ?>">
            <i class="bi bi-arrow-left-right me-1"></i>2. Mapear
        </span>
        <span class="step <?php echo $currentStep >= 3 ? ($currentStep > 3 ? 'completed' : 'active') : ''; ?>">
            <i class="bi bi-database me-1"></i>3. Importar
        </span>
        <span class="step <?php echo $currentStep >= 4 ? 'active' : ''; ?>">
            <i class="bi bi-check-lg me-1"></i>4. Listo
        </span>
    </div>

    <?php if ($mensaje): ?>
        <div class="alert <?php echo strpos($mensaje, '❌') !== false ? 'alert-danger' : 'alert-success'; ?>">
            <?php echo $mensaje; ?>
        </div>
    <?php endif; ?>

    <?php if ($currentStep == 1): ?>
    <div class="card p-4">
        <h5 class="mb-3"><i class="bi bi-file-earmark-arrow-up me-2"></i>Subir archivo CSV</h5>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="step" value="1">
            <div class="mb-3">
                <label class="form-label">Archivo CSV</label>
                <input type="file" name="archivo_csv" class="form-control" accept=".csv" required>
                <div class="form-text">
                    Compatible con cualquier formato: Excel CSV, UTF-8, Windows-1252, con/sin BOM
                </div>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-arrow-right me-1"></i>Continuar
            </button>
        </form>
    </div>
    <?php endif; ?>

    <?php if ($currentStep == 2): ?>
    <div class="card p-4">
        <h5 class="mb-4"><i class="bi bi-arrow-left-right me-2"></i>Mapear columnas</h5>
        <form method="POST">
            <input type="hidden" name="step" value="2">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Columna del archivo</th>
                            <th>Vista previa</th>
                            <th>Campo de destino</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($_SESSION['headers'] as $i => $header): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($header); ?></strong></td>
                            <td class="text-muted"><?php echo htmlspecialchars($_SESSION['preview'][0][$i] ?? ''); ?></td>
                            <td>
                                <select name="mapping[<?php echo $i; ?>]" class="form-select">
                                    <?php foreach ($dbFields as $field): ?>
                                    <option value="<?php echo $field['value']; ?>" <?php echo ($_SESSION['mapping'][$i] ?? '') == $field['value'] ? 'selected' : ''; ?>>
                                        <?php echo $field['label']; ?> <?php echo $field['required'] ? '*' : ''; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="alert alert-warning mt-3">
                <i class="bi bi-exclamation-triangle me-2"></i>
                <strong>Campos obligatorios (*):</strong> Empresa, Teléfono 1
            </div>
            <div class="d-flex justify-content-between mt-3">
                <a href="importar_leads.php?step=1" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Volver
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-arrow-right me-1"></i>Importar Ahora
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <?php if ($currentStep == 3): ?>
    <div class="card p-4 text-center">
        <div class="spinner-border text-primary mb-3" role="status"></div>
        <h5>Procesando importación...</h5>
        <p class="text-muted">Esto puede tardar unos segundos.</p>
    </div>
    <?php endif; ?>

    <?php if ($currentStep == 4): ?>
    <div class="card p-4 text-center">
        <i class="bi bi-check-circle text-success" style="font-size: 4rem;"></i>
        <h4 class="mt-3">Importación Finalizada</h4>
        <div class="mt-4">
            <a href="importar_leads.php?step=1" class="btn btn-outline-primary me-2">
                <i class="bi bi-plus-lg me-1"></i>Nueva Importación
            </a>
            <a href="asignar_leads.php" class="btn btn-success">
                <i class="bi bi-person-plus me-1"></i>Asignar Leads
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
