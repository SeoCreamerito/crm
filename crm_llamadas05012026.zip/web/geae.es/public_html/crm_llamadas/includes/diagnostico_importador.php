<?php
/**
 * IMPORTADOR DE CURSOS - VERSIÓN DIAGNÓSTICO
 * 
 * Esta versión incluye diagnóstico detallado de la estructura de la tabla
 * antes de intentar importar
 */

// =====================================================
// CONFIGURACIÓN DE BASE DE DATOS
// =====================================================
$db_config = [
    'host' => 'localhost',
    'database' => 'geae_crm_llamadas',
    'username' => 'geae_crm_llamadas',
    'password' => '&4222SFCrb1975',
    'charset' => 'utf8mb4'
];

// =====================================================
// CONEXIÓN A BASE DE DATOS
// =====================================================

try {
    $dsn = "mysql:host={$db_config['host']};dbname={$db_config['database']};charset={$db_config['charset']}";
    $pdo = new PDO($dsn, $db_config['username'], $db_config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
    echo "✓ Conexión a base de datos establecida\n\n";
} catch (PDOException $e) {
    die("ERROR: No se pudo conectar a la base de datos\n" . 
        "Host: {$db_config['host']}\n" .
        "Database: {$db_config['database']}\n" .
        "Error: " . $e->getMessage() . "\n");
}

// =====================================================
// DIAGNÓSTICO DE ESTRUCTURA
// =====================================================

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║          DIAGNÓSTICO DE ESTRUCTURA - TABLA CURSOS          ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

// Verificar que existe la tabla cursos
$stmt = $pdo->query("SHOW TABLES LIKE 'cursos'");
if ($stmt->rowCount() == 0) {
    die("❌ ERROR: La tabla 'cursos' no existe en la base de datos.\n" .
        "   Debes ejecutar primero el script: 01_estructura_tablas_cursos.sql\n");
}
echo "✓ Tabla 'cursos' existe\n\n";

// Obtener todas las columnas de la tabla cursos
echo "Columnas en la tabla 'cursos':\n";
echo str_repeat("-", 60) . "\n";

$stmt = $pdo->query("DESCRIBE cursos");
$columns = $stmt->fetchAll();
$columnNames = [];

foreach ($columns as $col) {
    $columnNames[] = $col['Field'];
    printf("%-30s %-15s %s\n", 
        $col['Field'], 
        $col['Type'], 
        $col['Null'] == 'YES' ? 'NULL' : 'NOT NULL'
    );
}

echo "\n";

// Verificar columnas críticas
$requiredColumns = [
    'id',
    'id_teleoperadora',
    'id_empresa',
    'id_alumno',
    'nombre_curso',
    'estado'
];

echo "Verificación de columnas críticas:\n";
echo str_repeat("-", 60) . "\n";

$missingColumns = [];
foreach ($requiredColumns as $col) {
    if (in_array($col, $columnNames)) {
        echo "✓ $col\n";
    } else {
        echo "❌ $col - FALTA\n";
        $missingColumns[] = $col;
    }
}

// Verificar columnas opcionales importantes
$optionalColumns = [
    'id_usuario_creador',
    'creado_en',
    'actualizado_en'
];

echo "\nColumnas opcionales:\n";
echo str_repeat("-", 60) . "\n";

foreach ($optionalColumns as $col) {
    if (in_array($col, $columnNames)) {
        echo "✓ $col - presente\n";
    } else {
        echo "⚠ $col - ausente (se adaptará)\n";
    }
}

if (!empty($missingColumns)) {
    echo "\n❌ ERROR: Faltan columnas críticas en la tabla cursos:\n";
    foreach ($missingColumns as $col) {
        echo "   - $col\n";
    }
    echo "\nDebes ejecutar el script SQL completo: 01_estructura_tablas_cursos.sql\n";
    exit(1);
}

echo "\n";
echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║                   DIAGNÓSTICO COMPLETO                     ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

// Verificar otras tablas necesarias
$requiredTables = [
    'empresas',
    'alumnos',
    'catalogo_regalos',
    'catalogo_puestos',
    'catalogo_titulaciones'
];

echo "Verificación de tablas relacionadas:\n";
echo str_repeat("-", 60) . "\n";

$missingTables = [];
foreach ($requiredTables as $table) {
    $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
    if ($stmt->rowCount() > 0) {
        echo "✓ $table\n";
    } else {
        echo "❌ $table - FALTA\n";
        $missingTables[] = $table;
    }
}

if (!empty($missingTables)) {
    echo "\n❌ ERROR: Faltan tablas necesarias:\n";
    foreach ($missingTables as $table) {
        echo "   - $table\n";
    }
    echo "\nDebes ejecutar el script SQL completo: 01_estructura_tablas_cursos.sql\n";
    exit(1);
}

echo "\n✓ Todas las tablas necesarias están presentes\n";

// Generar query de INSERT dinámicamente basado en columnas existentes
echo "\n";
echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║              GENERANDO QUERY DE INSERT                     ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

// Columnas que intentaremos usar en el INSERT
$insertColumns = [
    'id_teleoperadora',
    'id_empresa',
    'id_alumno',
    'id_fundae',
    'codigo_curso',
    'id_curso_catalogo',
    'nombre_curso',
    'horas_curso',
    'fecha_inicio',
    'fecha_fin',
    'notificacion_inicio',
    'notificacion_fin',
    'credito_formacion',
    'cofinanciacion',
    'id_regalo',
    'fecha_envio_tarjeta',
    'fecha_envio_regalo',
    'envio_claves',
    'fecha_envio_claves',
    'claves_no_oficial_fecha',
    'estado'
];

// Agregar id_usuario_creador solo si existe
if (in_array('id_usuario_creador', $columnNames)) {
    $insertColumns[] = 'id_usuario_creador';
    echo "✓ Se incluirá 'id_usuario_creador' en el INSERT\n";
} else {
    echo "⚠ 'id_usuario_creador' no existe, se omitirá del INSERT\n";
}

// Verificar que todas las columnas existen
$availableColumns = [];
foreach ($insertColumns as $col) {
    if (in_array($col, $columnNames)) {
        $availableColumns[] = $col;
    } else {
        echo "⚠ Columna '$col' no existe en la tabla, se omitirá\n";
    }
}

echo "\nColumnas que se usarán en el INSERT (" . count($availableColumns) . "):\n";
echo implode(", ", $availableColumns) . "\n";

echo "\n";
echo "═══════════════════════════════════════════════════════════\n";
echo "RESUMEN: La estructura de tu tabla es compatible ✓\n";
echo "═══════════════════════════════════════════════════════════\n\n";

echo "Ahora puedes ejecutar el importador normal:\n";
echo "php 02_importar_csv_standalone.php\n\n";
