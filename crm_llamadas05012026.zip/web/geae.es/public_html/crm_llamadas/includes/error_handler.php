<?php
/**
 * MANEJADOR GLOBAL DE ERRORES - CRM LLAMADAS
 * 
 * Este archivo captura TODOS los errores de PHP y los muestra de forma clara
 * 
 * INSTALACIÓN:
 * 1. Subir este archivo a: /crm_llamadas/includes/error_handler.php
 * 2. Añadir al inicio de config.php: require_once __DIR__ . '/error_handler.php';
 * 
 * MODO DEBUG: Muestra errores en pantalla (para desarrollo)
 * MODO PRODUCCIÓN: Guarda en log y muestra mensaje genérico
 */

// ============================================================================
// CONFIGURACIÓN
// ============================================================================

// Cambiar a false en producción
define('DEBUG_MODE', true);

// Ruta del archivo de log
define('ERROR_LOG_FILE', __DIR__ . '/../logs/error_log.txt');

// ============================================================================
// FUNCIONES DE LOGGING
// ============================================================================

/**
 * Crear directorio de logs si no existe
 */
function crearDirectorioLogs() {
    $logDir = dirname(ERROR_LOG_FILE);
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
}

/**
 * Escribir en el log
 */
function escribirLog($mensaje) {
    crearDirectorioLogs();
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $url = $_SERVER['REQUEST_URI'] ?? 'Unknown';
    
    $logEntry = sprintf(
        "[%s] [IP: %s] [URL: %s]\n%s\n%s\n\n",
        $timestamp,
        $ip,
        $url,
        $mensaje,
        str_repeat('-', 80)
    );
    
    @file_put_contents(ERROR_LOG_FILE, $logEntry, FILE_APPEND);
}

/**
 * Mostrar error bonito en pantalla
 */
function mostrarErrorPantalla($tipo, $mensaje, $archivo, $linea, $trace = null) {
    // Si es petición AJAX, devolver JSON
    if (defined('AJAX_MODE') || 
        (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') ||
        strpos($_SERVER['REQUEST_URI'] ?? '', '/ajax/') !== false) {
        
        header('Content-Type: application/json');
        echo json_encode([
            'error' => true,
            'tipo' => $tipo,
            'mensaje' => $mensaje,
            'archivo' => $archivo,
            'linea' => $linea,
            'trace' => $trace
        ]);
        return;
    }
    
    // Si ya se enviaron headers, usar output simple
    if (headers_sent()) {
        echo "\n\n=== ERROR PHP ===\n";
        echo "Tipo: $tipo\n";
        echo "Mensaje: $mensaje\n";
        echo "Archivo: $archivo\n";
        echo "Línea: $linea\n";
        if ($trace) {
            echo "\nStack Trace:\n$trace\n";
        }
        return;
    }
    
    // CSS inline para el error
    $html = '<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error - CRM Llamadas</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .error-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 900px;
            width: 100%;
            overflow: hidden;
        }
        .error-header {
            background: #dc3545;
            color: white;
            padding: 30px;
            text-align: center;
        }
        .error-header h1 {
            font-size: 48px;
            margin-bottom: 10px;
        }
        .error-header p {
            font-size: 18px;
            opacity: 0.9;
        }
        .error-body {
            padding: 30px;
        }
        .error-section {
            margin-bottom: 25px;
            padding: 20px;
            background: #f8f9fa;
            border-left: 4px solid #dc3545;
            border-radius: 5px;
        }
        .error-section h3 {
            color: #dc3545;
            margin-bottom: 10px;
            font-size: 18px;
        }
        .error-section p {
            color: #333;
            line-height: 1.6;
            font-size: 14px;
        }
        .error-code {
            background: #2d3748;
            color: #68d391;
            padding: 15px;
            border-radius: 5px;
            font-family: "Courier New", monospace;
            font-size: 13px;
            overflow-x: auto;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .error-file {
            color: #667eea;
            font-weight: bold;
        }
        .error-line {
            color: #f6ad55;
            font-weight: bold;
        }
        .error-trace {
            background: #2d3748;
            color: #a0aec0;
            padding: 15px;
            border-radius: 5px;
            font-family: "Courier New", monospace;
            font-size: 12px;
            max-height: 300px;
            overflow-y: auto;
            margin-top: 15px;
        }
        .error-footer {
            background: #f8f9fa;
            padding: 20px 30px;
            text-align: center;
            border-top: 1px solid #dee2e6;
        }
        .error-footer p {
            color: #6c757d;
            font-size: 14px;
        }
        .btn-back {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 12px 30px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 15px;
            transition: background 0.3s;
        }
        .btn-back:hover {
            background: #5568d3;
        }
        .timestamp {
            color: #6c757d;
            font-size: 12px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-header">
            <h1>⚠️ Error PHP</h1>
            <p>Se ha producido un error en la aplicación</p>
        </div>
        
        <div class="error-body">
            <div class="error-section">
                <h3>🔴 Tipo de Error</h3>
                <p><strong>' . htmlspecialchars($tipo) . '</strong></p>
            </div>
            
            <div class="error-section">
                <h3>💬 Mensaje</h3>
                <div class="error-code">' . htmlspecialchars($mensaje) . '</div>
            </div>
            
            <div class="error-section">
                <h3>📄 Ubicación</h3>
                <p>
                    <strong>Archivo:</strong> <span class="error-file">' . htmlspecialchars($archivo) . '</span><br>
                    <strong>Línea:</strong> <span class="error-line">' . htmlspecialchars($linea) . '</span>
                </p>
            </div>';
    
    if ($trace) {
        $html .= '
            <div class="error-section">
                <h3>🔍 Stack Trace</h3>
                <div class="error-trace">' . htmlspecialchars($trace) . '</div>
            </div>';
    }
    
    $html .= '
            <div class="error-section">
                <h3>💡 ¿Qué Hacer?</h3>
                <p>
                    1. <strong>Copia el mensaje de error completo</strong><br>
                    2. Verifica el archivo y línea indicados<br>
                    3. Revisa si faltan archivos o hay errores de sintaxis<br>
                    4. Consulta el log de errores en <code>/logs/error_log.txt</code>
                </p>
            </div>
        </div>
        
        <div class="error-footer">
            <p class="timestamp">Error capturado el ' . date('d/m/Y H:i:s') . '</p>
            <a href="javascript:history.back()" class="btn-back">← Volver Atrás</a>
        </div>
    </div>
</body>
</html>';
    
    echo $html;
}

// ============================================================================
// MANEJADORES DE ERRORES
// ============================================================================

/**
 * Manejador de errores normales (warnings, notices, etc.)
 */
function manejarError($errno, $errstr, $errfile, $errline) {
    // Ignorar errores suprimidos con @
    if (!(error_reporting() & $errno)) {
        return false;
    }
    
    $tipos = [
        E_ERROR => 'ERROR',
        E_WARNING => 'WARNING',
        E_PARSE => 'PARSE ERROR',
        E_NOTICE => 'NOTICE',
        E_CORE_ERROR => 'CORE ERROR',
        E_CORE_WARNING => 'CORE WARNING',
        E_COMPILE_ERROR => 'COMPILE ERROR',
        E_COMPILE_WARNING => 'COMPILE WARNING',
        E_USER_ERROR => 'USER ERROR',
        E_USER_WARNING => 'USER WARNING',
        E_USER_NOTICE => 'USER NOTICE',
        E_STRICT => 'STRICT NOTICE',
        E_RECOVERABLE_ERROR => 'RECOVERABLE ERROR',
        E_DEPRECATED => 'DEPRECATED',
        E_USER_DEPRECATED => 'USER DEPRECATED'
    ];
    
    $tipoError = $tipos[$errno] ?? 'UNKNOWN ERROR';
    
    // Log del error
    $logMsg = sprintf(
        "%s: %s in %s on line %d",
        $tipoError,
        $errstr,
        $errfile,
        $errline
    );
    escribirLog($logMsg);
    
    // Mostrar en pantalla si está en modo debug
    if (DEBUG_MODE) {
        // Solo mostrar errores serios en pantalla
        if (in_array($errno, [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR])) {
            mostrarErrorPantalla($tipoError, $errstr, $errfile, $errline);
            exit(1);
        }
    }
    
    return true;
}

/**
 * Manejador de errores fatales
 */
function manejarErrorFatal() {
    $error = error_get_last();
    
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        $tipos = [
            E_ERROR => 'FATAL ERROR',
            E_PARSE => 'PARSE ERROR',
            E_CORE_ERROR => 'CORE ERROR',
            E_COMPILE_ERROR => 'COMPILE ERROR'
        ];
        
        $tipoError = $tipos[$error['type']] ?? 'FATAL ERROR';
        
        // Log del error
        $logMsg = sprintf(
            "%s: %s in %s on line %d",
            $tipoError,
            $error['message'],
            $error['file'],
            $error['line']
        );
        escribirLog($logMsg);
        
        // Limpiar buffer de salida
        while (ob_get_level()) {
            ob_end_clean();
        }
        
        // Mostrar error
        if (DEBUG_MODE) {
            mostrarErrorPantalla(
                $tipoError,
                $error['message'],
                $error['file'],
                $error['line']
            );
        } else {
            // Modo producción - mensaje genérico
            http_response_code(500);
            echo '<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Error</title></head>
<body style="font-family:Arial;text-align:center;padding:50px;">
<h1>Error del Servidor</h1>
<p>Se ha producido un error. Por favor, contacta con el administrador.</p>
</body></html>';
        }
    }
}

/**
 * Manejador de excepciones no capturadas
 */
function manejarExcepcion($exception) {
    $logMsg = sprintf(
        "EXCEPCIÓN NO CAPTURADA: %s in %s on line %d\nStack trace:\n%s",
        $exception->getMessage(),
        $exception->getFile(),
        $exception->getLine(),
        $exception->getTraceAsString()
    );
    escribirLog($logMsg);
    
    if (DEBUG_MODE) {
        mostrarErrorPantalla(
            'EXCEPCIÓN',
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine(),
            $exception->getTraceAsString()
        );
    } else {
        http_response_code(500);
        echo 'Error del servidor. Contacta con el administrador.';
    }
}

// ============================================================================
// ACTIVAR MANEJADORES
// ============================================================================

// Configurar PHP
ini_set('display_errors', DEBUG_MODE ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', ERROR_LOG_FILE);

// Registrar manejadores
set_error_handler('manejarError');
set_exception_handler('manejarExcepcion');
register_shutdown_function('manejarErrorFatal');

// ============================================================================
// FUNCIÓN AUXILIAR PARA DEBUG
// ============================================================================

/**
 * Función para debugging rápido
 * Uso: debug($variable, 'Nombre de variable');
 */
function debug($var, $label = '') {
    if (!DEBUG_MODE) return;
    
    echo '<div style="background:#f8f9fa;border:2px solid #007bff;padding:15px;margin:10px;border-radius:5px;">';
    if ($label) {
        echo '<strong style="color:#007bff;">' . htmlspecialchars($label) . ':</strong><br>';
    }
    echo '<pre style="margin:10px 0;color:#333;">';
    print_r($var);
    echo '</pre></div>';
}

// Log de inicio (opcional, comentar en producción)
if (DEBUG_MODE) {
    escribirLog("=== INICIO DE SESIÓN ===");
}
?>
