<?php
/**
 * Lector de Excel para importación de cursos
 * Usa shell_exec con Python si PhpSpreadsheet no está disponible
 */

function leerExcelCursos($filepath) {
    $extension = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));
    
    // Mapeo de columnas del Excel a campos de BD
    $col_map = [
        0 => 'asignado_a',           // A
        1 => 'tipo_regalo',          // B
        2 => 'envio_tarjeta',        // C
        3 => 'fecha_envio_regalo',   // D
        7 => 'cif',                  // H
        8 => 'empresa',              // I
        9 => 'fecha_inicio',         // J
        10 => 'fecha_fin',           // K
        11 => 'horas_curso',         // L
        14 => 'credito_formacion',   // O
        16 => 'nombre_curso',        // Q
        17 => 'representante_legal', // R
        18 => 'dni_representante',   // S (primer DNI)
        19 => 'nombre_alumno',       // T
        20 => 'dni_alumno',          // U (segundo DNI)
        21 => 'telefono_alumno',     // V
        22 => 'email_alumno',        // W
        23 => 'puesto_alumno',       // X
        24 => 'titulacion_alumno',   // Y
        25 => 'nombre_asesoria',     // Z
        26 => 'telefono_asesoria',   // AA
        27 => 'email_asesoria',      // AB
        28 => 'comentario_asesoria', // AC
        33 => 'contacto_administrativo', // AH
        34 => 'telefono_administrativo', // AI
        35 => 'email_administrativo',    // AJ
        36 => 'comentario_general'       // AK
    ];
    
    $registros = [];
    
    // Usar Python con openpyxl para leer el Excel
    $escaped_path = escapeshellarg($filepath);
    $col_map_json = json_encode($col_map);
    
    $python_script = <<<PYTHON
import json
import sys
import openpyxl
from datetime import datetime

try:
    wb = openpyxl.load_workbook($escaped_path, data_only=True)
    sheet = wb.active
    
    col_map = $col_map_json
    registros = []
    
    for row_num in range(3, sheet.max_row + 1):
        # Verificar si hay empresa (columna I = índice 8)
        empresa_cell = sheet.cell(row=row_num, column=9)
        if not empresa_cell.value:
            continue
        
        registro = {}
        for col_idx, campo in col_map.items():
            col_idx = int(col_idx)
            cell = sheet.cell(row=row_num, column=col_idx + 1)
            valor = cell.value
            
            if valor is None:
                valor = None
            elif hasattr(valor, 'strftime'):
                valor = valor.strftime('%Y-%m-%d')
            elif isinstance(valor, (int, float)):
                if campo in ['horas_curso']:
                    valor = int(valor)
                elif campo in ['credito_formacion']:
                    valor = float(valor)
                else:
                    valor = str(valor)
            else:
                valor = str(valor).strip() if valor else None
            
            registro[campo] = valor
        
        if registro.get('empresa'):
            registros.append(registro)
    
    print(json.dumps(registros))
    
except Exception as e:
    print(json.dumps([]))
    sys.stderr.write(str(e))
PYTHON;

    $output = shell_exec("python3 << 'EOF'\n$python_script\nEOF");
    
    if ($output) {
        $registros = json_decode($output, true);
        if (is_array($registros)) {
            return $registros;
        }
    }
    
    // Si Python falla, intentar con CSV
    if ($extension === 'csv') {
        return leerCSVCursos($filepath);
    }
    
    return [];
}

function leerCSVCursos($filepath) {
    $registros = [];
    
    if (($handle = fopen($filepath, "r")) !== FALSE) {
        $row_num = 0;
        while (($data = fgetcsv($handle, 0, ";")) !== FALSE) {
            $row_num++;
            if ($row_num < 3) continue; // Saltar encabezados
            
            if (empty($data[8])) continue; // Sin empresa
            
            $registro = [
                'asignado_a' => $data[0] ?? null,
                'tipo_regalo' => $data[1] ?? null,
                'cif' => $data[7] ?? null,
                'empresa' => $data[8] ?? null,
                'fecha_inicio' => $data[9] ?? null,
                'fecha_fin' => $data[10] ?? null,
                'horas_curso' => $data[11] ?? null,
                'credito_formacion' => $data[14] ?? null,
                'nombre_curso' => $data[16] ?? null,
                'representante_legal' => $data[17] ?? null,
                'dni_representante' => $data[18] ?? null,
                'nombre_alumno' => $data[19] ?? null,
                'dni_alumno' => $data[20] ?? null,
                'telefono_alumno' => $data[21] ?? null,
                'email_alumno' => $data[22] ?? null,
                'puesto_alumno' => $data[23] ?? null,
                'titulacion_alumno' => $data[24] ?? null,
                'nombre_asesoria' => $data[25] ?? null,
                'telefono_asesoria' => $data[26] ?? null,
                'email_asesoria' => $data[27] ?? null,
                'contacto_administrativo' => $data[33] ?? null,
                'telefono_administrativo' => $data[34] ?? null,
                'email_administrativo' => $data[35] ?? null,
                'comentario_general' => $data[36] ?? null
            ];
            
            $registros[] = $registro;
        }
        fclose($handle);
    }
    
    return $registros;
}
