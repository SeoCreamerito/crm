<?php
/**
 * Funciones Auxiliares - CRM Llamadas
 * Adaptado a la estructura real de la base de datos
 */

/**
 * Obtener todos los estados de llamada
 */
function getEstadosLlamada($pdo) {
    $stmt = $pdo->query("SELECT * FROM estados_llamada ORDER BY prioridad ASC, nombre ASC");
    return $stmt->fetchAll();
}

/**
 * Obtener estado por nombre
 */
function getEstadoByNombre($pdo, $nombre) {
    $stmt = $pdo->prepare("SELECT * FROM estados_llamada WHERE nombre = :nombre");
    $stmt->execute([':nombre' => $nombre]);
    return $stmt->fetch();
}

/**
 * Obtener lead por ID
 */
function getLeadById($pdo, $id) {
    $stmt = $pdo->prepare("
        SELECT la.*, u.nombre as nombre_teleoperadora
        FROM leads_activos la
        LEFT JOIN usuarios u ON la.id_teleoperadora = u.id
        WHERE la.id = :id
    ");
    $stmt->execute([':id' => $id]);
    return $stmt->fetch();
}

/**
 * Obtener historial de llamadas de un lead
 */
function getHistorialLlamadas($pdo, $id_lead) {
    $stmt = $pdo->prepare("
        SELECT h.*, u.nombre as nombre_teleoperadora
        FROM historial_llamadas h
        LEFT JOIN usuarios u ON h.id_teleoperadora = u.id
        WHERE h.id_lead = :id_lead
        ORDER BY h.fecha_llamada DESC
    ");
    $stmt->execute([':id_lead' => $id_lead]);
    return $stmt->fetchAll();
}

/**
 * Registrar llamada en historial
 * Columnas de historial_llamadas:
 * - id, id_lead, desde_tabla, id_teleoperadora, estado_anterior, estado_nuevo, notas, verificado, telefono_usado, fecha_llamada
 */
function registrarLlamada($pdo, $datos) {
    $stmt = $pdo->prepare("
        INSERT INTO historial_llamadas 
        (id_lead, desde_tabla, id_teleoperadora, estado_anterior, estado_nuevo, notas, verificado, telefono_usado)
        VALUES (:id_lead, :desde_tabla, :id_teleop, :estado_ant, :estado_nuevo, :notas, :verificado, :telefono)
    ");
    $stmt->execute([
        ':id_lead' => $datos['id_lead'],
        ':desde_tabla' => $datos['desde_tabla'] ?? 'leads_activos',
        ':id_teleop' => $datos['id_teleoperadora'],
        ':estado_ant' => $datos['estado_anterior'] ?? null,
        ':estado_nuevo' => $datos['estado_nuevo'],
        ':notas' => $datos['notas'] ?? null,
        ':verificado' => $datos['verificado'] ?? 0,
        ':telefono' => $datos['telefono_usado'] ?? null
    ]);
    return $pdo->lastInsertId();
}

/**
 * Programar llamada
 * Columnas de llamadas_programadas:
 * - id, id_lead, desde_tabla, id_teleoperadora, fecha_programada, estado_programado, completada, estado
 */
function programarLlamada($pdo, $datos) {
    // Marcar programaciones anteriores como completadas/reasignadas
    $stmt = $pdo->prepare("UPDATE llamadas_programadas SET estado = 'reasignada', completada = 1 WHERE id_lead = :id_lead AND completada = 0");
    $stmt->execute([':id_lead' => $datos['id_lead']]);
    
    // Nueva programación
    $stmt = $pdo->prepare("
        INSERT INTO llamadas_programadas 
        (id_lead, desde_tabla, id_teleoperadora, fecha_programada, estado_programado, completada, estado)
        VALUES (:id_lead, :desde_tabla, :id_teleop, :fecha, :estado_prog, 0, 'pendiente')
    ");
    $stmt->execute([
        ':id_lead' => $datos['id_lead'],
        ':desde_tabla' => $datos['desde_tabla'] ?? 'leads_activos',
        ':id_teleop' => $datos['id_teleoperadora'],
        ':fecha' => $datos['fecha_programada'],
        ':estado_prog' => $datos['estado_programado'] ?? $datos['estado_nuevo'] ?? 'Pendiente'
    ]);
    return $pdo->lastInsertId();
}

/**
 * Mover lead a tabla final
 */
function moverLeadATablaFinal($pdo, $id_lead, $tabla_destino, $estado_id = null) {
    $tablas_validas = [
        'leads_no_contesta', 'leads_creditos_agotados', 'leads_no_interesa', 
        'leads_interesados', 'leads_ellos_contestan', 'leads_ellos_llaman', 
        'leads_tardes', 'leads_mando_info', 'leads_curso'
    ];
    
    if (!in_array($tabla_destino, $tablas_validas)) {
        throw new Exception("Tabla destino no válida: $tabla_destino");
    }
    
    $pdo->beginTransaction();
    try {
        // Obtener lead
        $stmt = $pdo->prepare("SELECT * FROM leads_activos WHERE id = :id");
        $stmt->execute([':id' => $id_lead]);
        $lead = $stmt->fetch();
        if (!$lead) throw new Exception("Lead no encontrado");
        
        // Campos comunes en todas las tablas destino
        $campos_base = [
            'actividad', 'empresa', 'tipovia', 'direccion', 'numerocalle', 'poblacion', 
            'provincia', 'cp', 'telefono1', 'telefono2', 'cnaecod', 'comunidad', 
            'facturacion', 'nr_trabajadores', 'cif', 'gerentes_autonomos', 'cautonoma', 
            'codoperador', 'razonoperador', 'email', 'verificado', 'intentos_no_contesta'
        ];
        
        $campos_insert = [];
        $valores = [];
        foreach ($campos_base as $campo) {
            if (array_key_exists($campo, $lead)) {
                $campos_insert[] = $campo;
                $valores[":$campo"] = $lead[$campo];
            }
        }
        
        // Añadir estado_id si existe
        $campos_insert[] = 'estado_id';
        $valores[':estado_id'] = $estado_id;
        
        $sql = "INSERT INTO $tabla_destino (" . implode(',', $campos_insert) . ") VALUES (:" . implode(',:', $campos_insert) . ")";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($valores);
        
        // Eliminar de leads_activos
        $stmt = $pdo->prepare("DELETE FROM leads_activos WHERE id = :id");
        $stmt->execute([':id' => $id_lead]);
        
        // Marcar llamadas programadas como completadas
        $stmt = $pdo->prepare("UPDATE llamadas_programadas SET estado = 'completada', completada = 1 WHERE id_lead = :id_lead AND completada = 0");
        $stmt->execute([':id_lead' => $id_lead]);
        
        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Incrementar intentos de no contesta
 */
function incrementarIntentosNoContesta($pdo, $id_lead) {
    $stmt = $pdo->prepare("UPDATE leads_activos SET intentos_no_contesta = intentos_no_contesta + 1 WHERE id = :id");
    $stmt->execute([':id' => $id_lead]);
    
    $stmt = $pdo->prepare("SELECT intentos_no_contesta FROM leads_activos WHERE id = :id");
    $stmt->execute([':id' => $id_lead]);
    return $stmt->fetchColumn();
}

/**
 * Marcar lead como verificado
 */
function marcarVerificado($pdo, $id_lead, $verificado = true) {
    $stmt = $pdo->prepare("UPDATE leads_activos SET verificado = :v WHERE id = :id");
    $stmt->execute([':v' => $verificado ? 1 : 0, ':id' => $id_lead]);
}

/**
 * Marcar consentimiento RGPD
 */
function marcarConsentimientoRGPD($pdo, $id_lead) {
    $stmt = $pdo->prepare("UPDATE leads_activos SET consentimiento_rgpd = 1, fecha_consentimiento_rgpd = NOW() WHERE id = :id");
    $stmt->execute([':id' => $id_lead]);
}

/**
 * Obtener teleoperadoras activas
 */
function getTeleoperadoras($pdo) {
    $stmt = $pdo->query("SELECT id, nombre, email FROM usuarios WHERE rol = 'agent' AND activo = 1 ORDER BY nombre");
    return $stmt->fetchAll();
}

/**
 * Obtener el siguiente lead para gestionar
 * Prioridad: 1) Programadas hoy, 2) Sin gestionar (nuevos), 3) Atrasadas
 */
function obtenerSiguienteLead($pdo, $id_teleop, $id_actual, $fecha_hoy) {
    $siguiente = null;
    
    // 1. Llamadas programadas para hoy (pendientes)
    $stmt = $pdo->prepare("
        SELECT la.id
        FROM llamadas_programadas lp
        INNER JOIN leads_activos la ON lp.id_lead = la.id
        WHERE lp.id_teleoperadora = :id_teleop
        AND DATE(lp.fecha_programada) = :fecha
        AND lp.completada = 0
        AND lp.estado = 'pendiente'
        AND la.id != :id_actual
        ORDER BY lp.fecha_programada ASC
        LIMIT 1
    ");
    $stmt->execute([':id_teleop' => $id_teleop, ':fecha' => $fecha_hoy, ':id_actual' => $id_actual]);
    $siguiente = $stmt->fetchColumn();
    
    // 2. Leads sin gestionar (sin historial = "Nuevos")
    if (!$siguiente) {
        $stmt = $pdo->prepare("
            SELECT la.id
            FROM leads_activos la
            LEFT JOIN historial_llamadas h ON la.id = h.id_lead
            WHERE la.id_teleoperadora = :id_teleop
            AND la.id != :id_actual
            AND h.id IS NULL
            ORDER BY la.creado_en ASC
            LIMIT 1
        ");
        $stmt->execute([':id_teleop' => $id_teleop, ':id_actual' => $id_actual]);
        $siguiente = $stmt->fetchColumn();
    }
    
    // 3. Llamadas atrasadas
    if (!$siguiente) {
        $stmt = $pdo->prepare("
            SELECT la.id
            FROM llamadas_programadas lp
            INNER JOIN leads_activos la ON lp.id_lead = la.id
            WHERE lp.id_teleoperadora = :id_teleop
            AND DATE(lp.fecha_programada) < :fecha
            AND lp.completada = 0
            AND lp.estado = 'pendiente'
            AND la.id != :id_actual
            ORDER BY lp.fecha_programada ASC
            LIMIT 1
        ");
        $stmt->execute([':id_teleop' => $id_teleop, ':fecha' => $fecha_hoy, ':id_actual' => $id_actual]);
        $siguiente = $stmt->fetchColumn();
    }
    
    return $siguiente;
}
?>
