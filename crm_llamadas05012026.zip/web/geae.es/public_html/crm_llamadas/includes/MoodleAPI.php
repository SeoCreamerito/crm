<?php
/**
 * CLASE: MoodleAPI - VERSIÓN INTEGRADA CRM GEAE
 * Gestión de integración con Moodle 5.0 vía API REST
 * 
 * INTEGRADA CON:
 * - Tabla cursos existente
 * - Tabla catalogo_cursos
 * - Sistema de auditoría completo
 * 
 * @author CRM GEAE
 * @version 2.0 - Integrada
 * @date 2025-01-03
 */

class MoodleAPI {
    
    private $pdo;
    private $url_base;
    private $token;
    private $endpoint = '/webservice/rest/server.php';
    private $format = 'json';
    
    // Endpoints requeridos
    private $endpoints_requeridos = [
        'core_webservice_get_site_info',
        'core_user_create_users',
        'enrol_manual_enrol_users',
        'core_course_get_courses',
        'core_user_get_users_by_field'
    ];
    
    /**
     * Constructor
     */
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->cargarConfiguracion();
    }
    
    /**
     * Cargar configuración desde BD
     */
    private function cargarConfiguracion() {
        $stmt = $this->pdo->query("SELECT * FROM moodle_configuracion ORDER BY id DESC LIMIT 1");
        $config = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($config) {
            $this->url_base = rtrim($config['url_base'], '/');
            $this->token = $config['token_api'];
        } else {
            // Crear configuración inicial si no existe
            $this->pdo->exec("
                INSERT INTO moodle_configuracion (url_base, token_api, estado_conexion) 
                VALUES ('https://www.geae.es/plataforma', '580bed506280fbd3e81fa180dfaafc00', 'inactiva')
            ");
            $this->url_base = 'https://www.geae.es/plataforma';
            $this->token = '580bed506280fbd3e81fa180dfaafc00';
        }
    }
    
    /**
     * Realizar llamada a la API de Moodle
     * 
     * @param string $function Nombre de la función a llamar
     * @param array $params Parámetros de la función
     * @return array Respuesta de Moodle
     */
    private function call($function, $params = []) {
        $url = $this->url_base . $this->endpoint;
        
        // Preparar parámetros
        $requestParams = [
            'wstoken' => $this->token,
            'wsfunction' => $function,
            'moodlewsrestformat' => $this->format
        ];
        
        // Agregar parámetros de la función
        $requestParams = array_merge($requestParams, $params);
        
        // Realizar petición con cURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($requestParams));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        // Verificar errores de cURL
        if ($error) {
            throw new Exception("Error de conexión cURL: " . $error);
        }
        
        if ($httpCode !== 200) {
            throw new Exception("Error HTTP {$httpCode} al conectar con Moodle");
        }
        
        // Decodificar respuesta
        $data = json_decode($response, true);
        
        // Verificar error en respuesta de Moodle
        if (isset($data['exception']) || isset($data['errorcode'])) {
            $errorMsg = $data['message'] ?? $data['debuginfo'] ?? 'Error desconocido';
            throw new Exception("Error Moodle: " . $errorMsg);
        }
        
        return $data;
    }
    
    /**
     * Probar conexión con Moodle
     * 
     * @return array ['success' => bool, 'message' => string, 'data' => array]
     */
    public function testConexion() {
        try {
            $info = $this->call('core_webservice_get_site_info');
            
            // Actualizar estado en BD
            $stmt = $this->pdo->prepare("
                UPDATE moodle_configuracion 
                SET estado_conexion = 'activa',
                    ultimo_test_conexion = NOW(),
                    mensaje_ultimo_test = :mensaje
                WHERE id = (SELECT id FROM (SELECT id FROM moodle_configuracion ORDER BY id DESC LIMIT 1) as temp)
            ");
            $stmt->execute([
                ':mensaje' => 'Conexión exitosa con ' . ($info['sitename'] ?? 'Moodle')
            ]);
            
            return [
                'success' => true,
                'message' => 'Conexión exitosa',
                'data' => [
                    'sitename' => $info['sitename'] ?? 'N/A',
                    'version' => $info['version'] ?? 'N/A',
                    'username' => $info['username'] ?? 'N/A'
                ]
            ];
            
        } catch (Exception $e) {
            // Actualizar estado en BD
            $stmt = $this->pdo->prepare("
                UPDATE moodle_configuracion 
                SET estado_conexion = 'error',
                    ultimo_test_conexion = NOW(),
                    mensaje_ultimo_test = :mensaje
                WHERE id = (SELECT id FROM (SELECT id FROM moodle_configuracion ORDER BY id DESC LIMIT 1) as temp)
            ");
            $stmt->execute([':mensaje' => $e->getMessage()]);
            
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'data' => null
            ];
        }
    }
    
    /**
     * Validar endpoints requeridos
     * 
     * @return array ['success' => bool, 'missing' => array, 'available' => array]
     */
    public function validarEndpoints() {
        try {
            $info = $this->call('core_webservice_get_site_info');
            
            // Extraer funciones disponibles
            $funciones_disponibles = [];
            if (isset($info['functions'])) {
                foreach ($info['functions'] as $func) {
                    $funciones_disponibles[] = $func['name'];
                }
            }
            
            // Verificar endpoints requeridos
            $missing = [];
            foreach ($this->endpoints_requeridos as $endpoint) {
                if (!in_array($endpoint, $funciones_disponibles)) {
                    $missing[] = $endpoint;
                }
            }
            
            // Guardar en BD
            $stmt = $this->pdo->prepare("
                UPDATE moodle_configuracion 
                SET endpoints_validados = :endpoints
                WHERE id = (SELECT id FROM (SELECT id FROM moodle_configuracion ORDER BY id DESC LIMIT 1) as temp)
            ");
            $stmt->execute([
                ':endpoints' => json_encode($funciones_disponibles)
            ]);
            
            return [
                'success' => empty($missing),
                'missing' => $missing,
                'available' => $funciones_disponibles
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'missing' => $this->endpoints_requeridos,
                'available' => []
            ];
        }
    }
    
    /**
     * Obtener todos los cursos de Moodle
     * 
     * @return array Lista de cursos
     */
    public function getCursos() {
        try {
            $cursos = $this->call('core_course_get_courses');
            
            // Filtrar sitio principal (ID 1)
            $resultado = [];
            foreach ($cursos as $curso) {
                if ($curso['id'] != 1) {
                    $resultado[] = [
                        'id' => $curso['id'],
                        'fullname' => $curso['fullname'],
                        'shortname' => $curso['shortname'],
                        'visible' => $curso['visible'] ?? 1
                    ];
                }
            }
            
            return $resultado;
            
        } catch (Exception $e) {
            throw new Exception("Error al obtener cursos: " . $e->getMessage());
        }
    }
    
    /**
     * Buscar curso por nombre
     * 
     * @param string $nombre_curso Nombre del curso (ej: OFICIAL_ENERO_2026)
     * @return array|null Datos del curso o null si no existe
     */
    public function buscarCursoPorNombre($nombre_curso) {
        $cursos = $this->getCursos();
        
        foreach ($cursos as $curso) {
            if (stripos($curso['fullname'], $nombre_curso) !== false || 
                stripos($curso['shortname'], $nombre_curso) !== false) {
                return $curso;
            }
        }
        
        return null;
    }
    
    /**
     * Verificar si usuario existe en Moodle por email
     * 
     * @param string $email Email del usuario
     * @return array|null Datos del usuario o null si no existe
     */
    public function buscarUsuarioPorEmail($email) {
        try {
            $params = [
                'field' => 'email',
                'values[0]' => $email
            ];
            
            $usuarios = $this->call('core_user_get_users_by_field', $params);
            
            return !empty($usuarios) ? $usuarios[0] : null;
            
        } catch (Exception $e) {
            // Si el usuario no existe, Moodle puede devolver error
            return null;
        }
    }
    
    /**
     * Crear usuario en Moodle
     * 
     * @param array $datos Datos del usuario
     * @return array Respuesta con ID del usuario creado
     */
    public function crearUsuario($datos) {
        // Validar campos obligatorios
        $required = ['username', 'password', 'firstname', 'lastname', 'email'];
        foreach ($required as $field) {
            if (empty($datos[$field])) {
                throw new Exception("El campo '{$field}' es obligatorio");
            }
        }
        
        // Preparar parámetros
        $params = [
            'users[0][username]' => $datos['username'],
            'users[0][password]' => $datos['password'],
            'users[0][firstname]' => $datos['firstname'],
            'users[0][lastname]' => $datos['lastname'],
            'users[0][email]' => $datos['email'],
            'users[0][auth]' => $datos['auth'] ?? 'manual',
            'users[0][lang]' => $datos['lang'] ?? 'es',
            'users[0][timezone]' => $datos['timezone'] ?? 'Europe/Madrid'
        ];
        
        // Campos opcionales
        if (!empty($datos['city'])) {
            $params['users[0][city]'] = $datos['city'];
        }
        if (!empty($datos['country'])) {
            $params['users[0][country]'] = $datos['country'];
        }
        
        try {
            $response = $this->call('core_user_create_users', $params);
            
            if (isset($response[0]['id'])) {
                return [
                    'success' => true,
                    'user_id' => $response[0]['id'],
                    'username' => $response[0]['username']
                ];
            } else {
                throw new Exception("Respuesta inesperada de Moodle");
            }
            
        } catch (Exception $e) {
            throw new Exception("Error al crear usuario: " . $e->getMessage());
        }
    }
    
    /**
     * Matricular usuario en curso
     * 
     * @param int $user_id ID del usuario en Moodle
     * @param int $course_id ID del curso en Moodle
     * @param int $role_id ID del rol (5 = estudiante por defecto)
     * @return bool
     */
    public function matricularUsuario($user_id, $course_id, $role_id = 5) {
        $params = [
            'enrolments[0][roleid]' => $role_id,
            'enrolments[0][userid]' => $user_id,
            'enrolments[0][courseid]' => $course_id
        ];
        
        try {
            $response = $this->call('enrol_manual_enrol_users', $params);
            
            // Si no hay excepción, la matriculación fue exitosa
            return true;
            
        } catch (Exception $e) {
            throw new Exception("Error al matricular usuario: " . $e->getMessage());
        }
    }
    
    /**
     * Proceso completo: crear usuario Y matricular
     * Ahora integrado con tabla cursos existente
     * 
     * @param int $id_curso ID de la tabla cursos
     * @param array $datos_usuario Datos del usuario
     * @param int $course_id ID del curso en Moodle
     * @return array Resultado del proceso
     */
    public function crearYMatricularIntegrado($id_curso, $datos_usuario, $course_id) {
        $resultado = [
            'success' => false,
            'user_id' => null,
            'username' => null,
            'paso_fallido' => null,
            'mensaje_error' => null,
            'estado' => 'pendiente'
        ];
        
        $this->pdo->beginTransaction();
        
        try {
            // PASO 1: Crear usuario
            $usuario_creado = $this->crearUsuario($datos_usuario);
            $resultado['user_id'] = $usuario_creado['user_id'];
            $resultado['username'] = $usuario_creado['username'];
            $resultado['estado'] = 'usuario_creado';
            
            // Actualizar tabla cursos
            $stmt = $this->pdo->prepare("
                UPDATE cursos 
                SET moodle_user_id = :user_id,
                    moodle_estado = 'usuario_creado',
                    claves_no_oficiales = :credenciales
                WHERE id = :id_curso
            ");
            $stmt->execute([
                ':user_id' => $usuario_creado['user_id'],
                ':credenciales' => "Usuario: {$datos_usuario['username']} | Password: {$datos_usuario['password']}",
                ':id_curso' => $id_curso
            ]);
            
            // PASO 2: Matricular
            $this->matricularUsuario($usuario_creado['user_id'], $course_id);
            $resultado['estado'] = 'matriculado';
            
            // Actualizar tabla cursos
            $stmt = $this->pdo->prepare("
                UPDATE cursos 
                SET moodle_estado = 'matriculado',
                    moodle_matricula_fecha = NOW()
                WHERE id = :id_curso
            ");
            $stmt->execute([':id_curso' => $id_curso]);
            
            // PASO 3: Registrar en log de auditoría
            $this->registrarEnLogAuditoria($id_curso, $datos_usuario, $usuario_creado, $course_id, 'matriculado');
            
            $resultado['success'] = true;
            $this->pdo->commit();
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $resultado['paso_fallido'] = $resultado['user_id'] ? 'matricular' : 'crear_usuario';
            $resultado['mensaje_error'] = $e->getMessage();
            
            // Actualizar estado de error en cursos
            $stmt = $this->pdo->prepare("
                UPDATE cursos 
                SET moodle_estado = 'error',
                    moodle_error = :error
                WHERE id = :id_curso
            ");
            $stmt->execute([
                ':error' => $e->getMessage(),
                ':id_curso' => $id_curso
            ]);
            
            // Registrar en log
            $this->registrarEnLogAuditoria($id_curso, $datos_usuario, $resultado, $course_id, 'error', $e->getMessage());
        }
        
        return $resultado;
    }
    
    /**
     * Registrar en log de auditoría
     */
    private function registrarEnLogAuditoria($id_curso, $datos_usuario, $resultado_moodle, $course_id, $estado, $error = null) {
        $usuario_crm = $_SESSION['usuario'] ?? [];
        
        $stmt = $this->pdo->prepare("
            INSERT INTO moodle_altas_log (
                id_curso, nombre, apellidos, email, dni,
                username_moodle, password_temporal_hash,
                moodle_user_id, moodle_course_id,
                fecha_hora_utc, fecha_hora_local, timezone,
                ip_origen, usuario_crm_id, usuario_crm_nombre,
                estado, paso_fallido, mensaje_error,
                hash_registro
            ) VALUES (
                :id_curso, :nombre, :apellidos, :email, :dni,
                :username, :password_hash,
                :moodle_user_id, :moodle_course_id,
                UTC_TIMESTAMP(), NOW(), 'Europe/Madrid',
                :ip, :usuario_crm_id, :usuario_crm_nombre,
                :estado, :paso_fallido, :mensaje_error,
                :hash
            )
        ");
        
        $hash_data = json_encode([
            'id_curso' => $id_curso,
            'email' => $datos_usuario['email'],
            'timestamp' => time()
        ]);
        
        $stmt->execute([
            ':id_curso' => $id_curso,
            ':nombre' => $datos_usuario['firstname'],
            ':apellidos' => $datos_usuario['lastname'],
            ':email' => $datos_usuario['email'],
            ':dni' => $datos_usuario['dni'] ?? null,
            ':username' => $resultado_moodle['username'] ?? null,
            ':password_hash' => password_hash($datos_usuario['password'], PASSWORD_DEFAULT),
            ':moodle_user_id' => $resultado_moodle['user_id'] ?? null,
            ':moodle_course_id' => $course_id,
            ':ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            ':usuario_crm_id' => $usuario_crm['id'] ?? 0,
            ':usuario_crm_nombre' => $usuario_crm['nombre'] ?? 'Sistema',
            ':estado' => $estado,
            ':paso_fallido' => $resultado_moodle['paso_fallido'] ?? null,
            ':mensaje_error' => $error,
            ':hash' => hash('sha256', $hash_data)
        ]);
    }
    
    /**
     * Generar username único basado en email
     * 
     * @param string $email
     * @return string
     */
    public function generarUsername($email) {
        $base = strtolower(explode('@', $email)[0]);
        $base = preg_replace('/[^a-z0-9]/', '', $base);
        
        // Verificar si ya existe
        $username = $base;
        $contador = 1;
        
        while ($this->buscarUsuarioPorEmail($username . '@temp.com') !== null) {
            $username = $base . $contador;
            $contador++;
        }
        
        return $username;
    }
    
    /**
     * Generar contraseña temporal segura
     * 
     * @param int $length Longitud de la contraseña
     * @return string
     */
    public function generarPasswordTemporal($length = 12) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%';
        $password = '';
        
        for ($i = 0; $i < $length; $i++) {
            $password .= $chars[random_int(0, strlen($chars) - 1)];
        }
        
        return $password;
    }
    
    /**
     * Sincronizar catálogo de cursos con Moodle
     * 
     * @return array Resumen de sincronización
     */
    public function sincronizarCatalogoCursos() {
        try {
            $cursos_moodle = $this->getCursos();
            $sincronizados = 0;
            
            foreach ($cursos_moodle as $curso) {
                // Buscar en catálogo por nombre similar
                $stmt = $this->pdo->prepare("
                    SELECT id FROM catalogo_cursos
                    WHERE nombre LIKE :nombre
                    AND id_moodle IS NULL
                    LIMIT 1
                ");
                $stmt->execute([':nombre' => '%' . $curso['shortname'] . '%']);
                $row = $stmt->fetch();
                
                if ($row) {
                    // Actualizar
                    $update = $this->pdo->prepare("
                        UPDATE catalogo_cursos
                        SET id_moodle = :id_moodle,
                            url_moodle = :url,
                            sincronizado_moodle = 1,
                            fecha_sincronizacion = NOW(),
                            estado_moodle = 'activo'
                        WHERE id = :id
                    ");
                    $update->execute([
                        ':id_moodle' => $curso['id'],
                        ':url' => $this->url_base . '/course/view.php?id=' . $curso['id'],
                        ':id' => $row['id']
                    ]);
                    $sincronizados++;
                }
            }
            
            return [
                'success' => true,
                'total_moodle' => count($cursos_moodle),
                'sincronizados' => $sincronizados
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}
