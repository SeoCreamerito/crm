<?php if (!isset($_SESSION['user_id'])) return; ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= ($_SESSION['rol'] === 'admin') ? 'admin/dashboard.php' : (($_SESSION['rol'] === 'agent') ? 'agent/panel.php' : 'inspeccion/fichajes_consulta.php') ?>">
      CRM Llamadas
    </a>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        <?php if ($_SESSION['rol'] === 'admin'): ?>
          <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="gestion_usuarios.php">Usuarios</a></li>
          <li class="nav-item"><a class="nav-link" href="importar_leads.php">Importar</a></li>
          <li class="nav-item"><a class="nav-link" href="asignar_leads.php">Asignar</a></li>
          <li class="nav-item"><a class="nav-link" href="moodle_gestion.php"><i class="bi bi-mortarboard-fill"></i> Moodle</a></li>
    <a class="nav-link" href="bases_datos.php"> Bases de Datos</a>
</li>
<a href="catalogos.php" class="nav-link">
    <i class="bi bi-gear"></i> Catálogos
</a>
          <li class="nav-item"><a class="nav-link" href="gestion_programadas.php">Programadas</a></li>
          <li class="nav-item"><a class="nav-link" href="fichajes.php">Fichajes</a></li>
        <?php elseif ($_SESSION['rol'] === 'agent'): ?>
          <li class="nav-item"><a class="nav-link" href="panel.php">Mi Panel</a></li>
          <li class="nav-item"><a class="nav-link" href="fichaje.php">Fichaje</a></li>
        <?php elseif ($_SESSION['rol'] === 'inspeccion'): ?>
          <li class="nav-item"><a class="nav-link" href="fichajes_consulta.php">Fichajes</a></li>
        <?php endif; ?>
      </ul>
      
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
            <?= htmlspecialchars($_SESSION['nombre']) ?> (<?= $_SESSION['rol'] ?>)
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="../auth/logout.php">Cerrar sesión</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>