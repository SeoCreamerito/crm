<?php
/**
 * IMPORTADOR DE CURSOS DESDE CSV - VERSIÓN STANDALONE
 * 
 * Esta versión NO requiere el archivo config.php
 * Configura la conexión directamente aquí
 * 
 * USO:
 * 1. Editar la configuración de BD abajo
 * 2. Colocar el archivo cursosonline.csv en la misma carpeta que este script
 * 3. Ejecutar: php 02_importar_csv_standalone.php
 * 
 * O especificar ruta del CSV:
 * php 02_importar_csv_standalone.php /ruta/completa/al/archivo.csv
 */

// =====================================================
// CONFIGURACIÓN DE BASE DE DATOS
// =====================================================
$db_config = [
    'host' => 'localhost',
    'database' => 'geae_crm_llamadas',
    'username' => 'geae_crm_llamadas',
    'password' => '&4222SFCrb1975',
    'charset' => 'utf8mb4'
];

// =====================================================
// CONFIGURACIÓN DEL ARCHIVO CSV
// =====================================================

// Por defecto busca el CSV en la misma carpeta que el script
$csv_file = __DIR__ . '/cursosonline.csv';

// O puedes especificar una ruta absoluta:
// $csv_file = '/var/www/html/uploads/cursosonline.csv';

// O pasar la ruta como argumento: php script.php /ruta/al/csv
if (isset($argv[1]) && !empty($argv[1])) {
    $csv_file = $argv[1];
}

$delimiter = ';';
$encoding = 'UTF-8';

// =====================================================
// CONEXIÓN A BASE DE DATOS
// =====================================================

try {
    $dsn = "mysql:host={$db_config['host']};dbname={$db_config['database']};charset={$db_config['charset']}";
    $pdo = new PDO($dsn, $db_config['username'], $db_config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
    echo "✓ Conexión a base de datos establecida\n\n";
} catch (PDOException $e) {
    die("ERROR: No se pudo conectar a la base de datos\n" . 
        "Host: {$db_config['host']}\n" .
        "Database: {$db_config['database']}\n" .
        "Error: " . $e->getMessage() . "\n");
}

// =====================================================
// ESTADÍSTICAS
// =====================================================
$stats = [
    'procesados' => 0,
    'importados' => 0,
    'errores' => 0,
    'empresas_creadas' => 0,
    'alumnos_creados' => 0,
    'cursos_creados' => 0,
    'duplicados' => 0
];

$errores = [];

// =====================================================
// FUNCIONES AUXILIARES
// =====================================================

/**
 * Limpiar y normalizar texto
 */
function limpiarTexto($texto) {
    if (empty($texto)) return null;
    $texto = trim($texto);
    // Eliminar BOM UTF-8 si existe
    $texto = str_replace("\xEF\xBB\xBF", '', $texto);
    return $texto === '' ? null : $texto;
}

/**
 * Convertir fecha del CSV (varios formatos posibles)
 */
function convertirFecha($fecha) {
    if (empty($fecha)) return null;
    
    $fecha = limpiarTexto($fecha);
    if (!$fecha) return null;
    
    // Intentar varios formatos
    $formatos = ['d/m/Y', 'd-m-Y', 'Y-m-d', 'd/m/y', 'd-m-y'];
    
    foreach ($formatos as $formato) {
        $dt = DateTime::createFromFormat($formato, $fecha);
        if ($dt !== false) {
            return $dt->format('Y-m-d');
        }
    }
    
    return null;
}

/**
 * Buscar o crear teleoperadora por nombre
 */
function buscarTeleoperadora($pdo, $nombre) {
    if (empty($nombre)) return null;
    
    $nombre = limpiarTexto($nombre);
    if (!$nombre) return null;
    
    $stmt = $pdo->prepare("
        SELECT id FROM usuarios 
        WHERE LOWER(nombre) = LOWER(?) 
        AND rol IN ('agent', 'admin', 'gestion_cursos')
        LIMIT 1
    ");
    $stmt->execute([$nombre]);
    $result = $stmt->fetch();
    
    return $result ? $result['id'] : null;
}

/**
 * Buscar o crear regalo
 */
function buscarCrearRegalo($pdo, $nombre) {
    if (empty($nombre)) return null;
    
    $nombre = limpiarTexto($nombre);
    if (!$nombre) return null;
    
    // Buscar
    $stmt = $pdo->prepare("SELECT id FROM catalogo_regalos WHERE nombre = ? LIMIT 1");
    $stmt->execute([$nombre]);
    $result = $stmt->fetch();
    
    if ($result) {
        return $result['id'];
    }
    
    // Crear
    $stmt = $pdo->prepare("INSERT INTO catalogo_regalos (nombre) VALUES (?)");
    $stmt->execute([$nombre]);
    return $pdo->lastInsertId();
}

/**
 * Buscar o crear puesto
 */
function buscarCrearPuesto($pdo, $nombre) {
    if (empty($nombre)) return null;
    
    $nombre = limpiarTexto($nombre);
    if (!$nombre) return null;
    
    // Buscar
    $stmt = $pdo->prepare("SELECT id FROM catalogo_puestos WHERE UPPER(nombre) = UPPER(?) LIMIT 1");
    $stmt->execute([$nombre]);
    $result = $stmt->fetch();
    
    if ($result) {
        return $result['id'];
    }
    
    // Crear
    $stmt = $pdo->prepare("INSERT INTO catalogo_puestos (nombre) VALUES (?)");
    $stmt->execute([$nombre]);
    return $pdo->lastInsertId();
}

/**
 * Buscar o crear titulación
 */
function buscarCrearTitulacion($pdo, $nombre) {
    if (empty($nombre)) return null;
    
    $nombre = limpiarTexto($nombre);
    if (!$nombre) return null;
    
    // Buscar
    $stmt = $pdo->prepare("SELECT id FROM catalogo_titulaciones WHERE UPPER(nombre) = UPPER(?) LIMIT 1");
    $stmt->execute([$nombre]);
    $result = $stmt->fetch();
    
    if ($result) {
        return $result['id'];
    }
    
    // Crear
    $stmt = $pdo->prepare("INSERT INTO catalogo_titulaciones (nombre) VALUES (?)");
    $stmt->execute([$nombre]);
    return $pdo->lastInsertId();
}

/**
 * Buscar o crear empresa
 */
function buscarCrearEmpresa($pdo, $datos, &$stats) {
    $cif = limpiarTexto($datos['cif']);
    
    if (empty($cif)) {
        return null;
    }
    
    // Buscar empresa existente
    $stmt = $pdo->prepare("SELECT id FROM empresas WHERE cif = ? LIMIT 1");
    $stmt->execute([$cif]);
    $result = $stmt->fetch();
    
    if ($result) {
        return $result['id'];
    }
    
    // Crear nueva empresa
    $stmt = $pdo->prepare("
        INSERT INTO empresas (
            cif, denominacion, representante_legal, dni_representante,
            nombre_asesoria, telefono_asesoria, email_asesoria, comentario_asesoria,
            contacto_administrativo, telefono_administrativo, email_administrativo, comentario_administrativo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $cif,
        limpiarTexto($datos['denominacion']),
        limpiarTexto($datos['representante_legal']),
        limpiarTexto($datos['dni_representante']),
        limpiarTexto($datos['nombre_asesoria']),
        limpiarTexto($datos['telefono_asesoria']),
        limpiarTexto($datos['email_asesoria']),
        limpiarTexto($datos['comentario_asesoria']),
        limpiarTexto($datos['contacto_administrativo']),
        limpiarTexto($datos['telefono_administrativo']),
        limpiarTexto($datos['email_administrativo']),
        limpiarTexto($datos['comentario'])
    ]);
    
    $stats['empresas_creadas']++;
    return $pdo->lastInsertId();
}

/**
 * Buscar o crear alumno
 */
function buscarCrearAlumno($pdo, $datos, &$stats) {
    $dni = limpiarTexto($datos['dni_alumno']);
    
    if (empty($dni)) {
        return null;
    }
    
    // Buscar alumno existente
    $stmt = $pdo->prepare("SELECT id FROM alumnos WHERE dni = ? LIMIT 1");
    $stmt->execute([$dni]);
    $result = $stmt->fetch();
    
    if ($result) {
        // Actualizar datos del alumno si es necesario
        $stmt = $pdo->prepare("
            UPDATE alumnos SET
                nombre = ?,
                telefono_1 = ?,
                email = ?,
                id_puesto = ?,
                id_titulacion = ?
            WHERE id = ?
        ");
        $stmt->execute([
            limpiarTexto($datos['nombre_alumno']),
            limpiarTexto($datos['telefono']),
            limpiarTexto($datos['email']),
            $datos['id_puesto'],
            $datos['id_titulacion'],
            $result['id']
        ]);
        
        return $result['id'];
    }
    
    // Crear nuevo alumno
    $stmt = $pdo->prepare("
        INSERT INTO alumnos (
            nombre, dni, telefono_1, email, id_puesto, id_titulacion
        ) VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        limpiarTexto($datos['nombre_alumno']),
        $dni,
        limpiarTexto($datos['telefono']),
        limpiarTexto($datos['email']),
        $datos['id_puesto'],
        $datos['id_titulacion']
    ]);
    
    $stats['alumnos_creados']++;
    return $pdo->lastInsertId();
}

/**
 * Buscar curso en catálogo por nombre
 */
function buscarCursoCatalogo($pdo, $nombreCurso) {
    if (empty($nombreCurso)) return null;
    
    $stmt = $pdo->prepare("
        SELECT id FROM catalogo_cursos 
        WHERE UPPER(nombre) = UPPER(?)
        LIMIT 1
    ");
    $stmt->execute([limpiarTexto($nombreCurso)]);
    $result = $stmt->fetch();
    
    return $result ? $result['id'] : null;
}

/**
 * Crear curso
 */
function crearCurso($pdo, $datos, &$stats) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO cursos (
                id_teleoperadora, id_empresa, id_alumno,
                id_fundae, codigo_curso, id_curso_catalogo, nombre_curso, horas_curso,
                fecha_inicio, fecha_fin,
                notificacion_inicio, notificacion_fin,
                credito_formacion, cofinanciacion,
                id_regalo, fecha_envio_tarjeta, fecha_envio_regalo,
                envio_claves, fecha_envio_claves, claves_no_oficial_fecha,
                estado, id_usuario_creador
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pendiente', 1
            )
        ");
        
        $stmt->execute([
            $datos['id_teleoperadora'],
            $datos['id_empresa'],
            $datos['id_alumno'],
            limpiarTexto($datos['id_fundae']),
            limpiarTexto($datos['codigo_curso']),
            $datos['id_curso_catalogo'],
            limpiarTexto($datos['nombre_curso']),
            $datos['horas_curso'],
            $datos['fecha_inicio'],
            $datos['fecha_fin'],
            $datos['notificacion_inicio'] ? 1 : 0,
            $datos['notificacion_fin'] ? 1 : 0,
            $datos['credito_formacion'],
            $datos['cofinanciacion'],
            $datos['id_regalo'],
            $datos['fecha_envio_tarjeta'],
            $datos['fecha_envio_regalo'],
            $datos['envio_claves'] ? 1 : 0,
            $datos['fecha_envio_claves'],
            $datos['claves_no_oficial_fecha']
        ]);
        
        $stats['cursos_creados']++;
        return $pdo->lastInsertId();
        
    } catch (PDOException $e) {
        throw new Exception("Error al crear curso: " . $e->getMessage());
    }
}

// =====================================================
// PROCESO DE IMPORTACIÓN
// =====================================================

try {
    // Verificar que existe el archivo
    if (!file_exists($csv_file)) {
        echo "ERROR: No se encuentra el archivo CSV\n";
        echo "Buscando en: $csv_file\n\n";
        echo "SOLUCIONES:\n";
        echo "1. Coloca el archivo 'cursosonline.csv' en la misma carpeta que este script\n";
        echo "2. O ejecuta: php " . basename(__FILE__) . " /ruta/completa/al/archivo.csv\n";
        echo "3. O edita la variable \$csv_file en este script (línea 25)\n";
        exit(1);
    }
    
    echo "╔════════════════════════════════════════════════════════════╗\n";
    echo "║     IMPORTADOR DE CURSOS FUNDAE - VERSIÓN STANDALONE      ║\n";
    echo "╚════════════════════════════════════════════════════════════╝\n\n";
    echo "📁 Archivo CSV: $csv_file\n";
    echo "🗄️  Base de datos: {$db_config['database']}\n";
    echo "🚀 Iniciando importación...\n\n";
    
    // Abrir archivo CSV
    $handle = fopen($csv_file, 'r');
    if ($handle === false) {
        throw new Exception("No se pudo abrir el archivo CSV");
    }
    
    // Saltar la primera línea (encabezados)
    $headers = fgetcsv($handle, 0, $delimiter);
    
    $linea = 1;
    
    // Procesar cada línea
    while (($data = fgetcsv($handle, 0, $delimiter)) !== false) {
        $linea++;
        $stats['procesados']++;
        
        // Verificar que la línea no esté vacía
        if (empty($data[0]) && empty($data[1]) && empty($data[7])) {
            continue; // Línea vacía
        }
        
        try {
            $pdo->beginTransaction();
            
            // Extraer datos del CSV
            $csvData = [
                'teleoperadora' => $data[0] ?? '',
                'regalo' => $data[1] ?? '',
                'fecha_envio_tarjeta' => $data[2] ?? '',
                'fecha_envio_regalo' => $data[3] ?? '',
                'id_fundae' => $data[4] ?? '',
                'codigo_curso' => $data[5] ?? '',
                'numero_curso' => $data[6] ?? '',
                'cif' => $data[7] ?? '',
                'denominacion' => $data[8] ?? '',
                'fecha_inicio' => $data[9] ?? '',
                'fecha_fin' => $data[10] ?? '',
                'horas' => $data[11] ?? '',
                'notif_inicio' => $data[12] ?? '',
                'notif_fin' => $data[13] ?? '',
                'credito' => $data[14] ?? '',
                'cofinanciacion' => $data[15] ?? '',
                'nombre_curso' => $data[16] ?? '',
                'representante_legal' => $data[17] ?? '',
                'dni_representante' => $data[18] ?? '',
                'nombre_alumno' => $data[19] ?? '',
                'dni_alumno' => $data[20] ?? '',
                'telefono' => $data[21] ?? '',
                'email' => $data[22] ?? '',
                'puesto' => $data[23] ?? '',
                'titulacion' => $data[24] ?? '',
                'nombre_asesoria' => $data[25] ?? '',
                'telefono_asesoria' => $data[26] ?? '',
                'email_asesoria' => $data[27] ?? '',
                'comentario_asesoria' => $data[28] ?? '',
                'envio_claves' => $data[29] ?? '',
                'fecha_envio_claves' => $data[30] ?? '',
                'claves_no_oficial' => $data[32] ?? '',
                'contacto_administrativo' => $data[33] ?? '',
                'telefono_administrativo' => $data[34] ?? '',
                'email_administrativo' => $data[35] ?? '',
                'comentario' => $data[36] ?? ''
            ];
            
            // Buscar/crear relaciones
            $id_teleoperadora = buscarTeleoperadora($pdo, $csvData['teleoperadora']);
            $id_regalo = buscarCrearRegalo($pdo, $csvData['regalo']);
            $id_puesto = buscarCrearPuesto($pdo, $csvData['puesto']);
            $id_titulacion = buscarCrearTitulacion($pdo, $csvData['titulacion']);
            
            // Crear empresa
            $id_empresa = buscarCrearEmpresa($pdo, [
                'cif' => $csvData['cif'],
                'denominacion' => $csvData['denominacion'],
                'representante_legal' => $csvData['representante_legal'],
                'dni_representante' => $csvData['dni_representante'],
                'nombre_asesoria' => $csvData['nombre_asesoria'],
                'telefono_asesoria' => $csvData['telefono_asesoria'],
                'email_asesoria' => $csvData['email_asesoria'],
                'comentario_asesoria' => $csvData['comentario_asesoria'],
                'contacto_administrativo' => $csvData['contacto_administrativo'],
                'telefono_administrativo' => $csvData['telefono_administrativo'],
                'email_administrativo' => $csvData['email_administrativo'],
                'comentario' => $csvData['comentario']
            ], $stats);
            
            if (!$id_empresa) {
                throw new Exception("No se pudo crear la empresa (CIF vacío o inválido)");
            }
            
            // Crear alumno
            $id_alumno = buscarCrearAlumno($pdo, [
                'nombre_alumno' => $csvData['nombre_alumno'],
                'dni_alumno' => $csvData['dni_alumno'],
                'telefono' => $csvData['telefono'],
                'email' => $csvData['email'],
                'id_puesto' => $id_puesto,
                'id_titulacion' => $id_titulacion
            ], $stats);
            
            if (!$id_alumno) {
                throw new Exception("No se pudo crear el alumno (DNI vacío o inválido)");
            }
            
            // Buscar curso en catálogo
            $id_curso_catalogo = buscarCursoCatalogo($pdo, $csvData['nombre_curso']);
            
            // Crear curso
            crearCurso($pdo, [
                'id_teleoperadora' => $id_teleoperadora,
                'id_empresa' => $id_empresa,
                'id_alumno' => $id_alumno,
                'id_fundae' => $csvData['id_fundae'],
                'codigo_curso' => $csvData['codigo_curso'],
                'id_curso_catalogo' => $id_curso_catalogo,
                'nombre_curso' => $csvData['nombre_curso'],
                'horas_curso' => !empty($csvData['horas']) ? intval($csvData['horas']) : null,
                'fecha_inicio' => convertirFecha($csvData['fecha_inicio']),
                'fecha_fin' => convertirFecha($csvData['fecha_fin']),
                'notificacion_inicio' => !empty($csvData['notif_inicio']),
                'notificacion_fin' => !empty($csvData['notif_fin']),
                'credito_formacion' => !empty($csvData['credito']) ? floatval($csvData['credito']) : 0,
                'cofinanciacion' => !empty($csvData['cofinanciacion']) ? floatval($csvData['cofinanciacion']) : 0,
                'id_regalo' => $id_regalo,
                'fecha_envio_tarjeta' => convertirFecha($csvData['fecha_envio_tarjeta']),
                'fecha_envio_regalo' => convertirFecha($csvData['fecha_envio_regalo']),
                'envio_claves' => !empty($csvData['envio_claves']),
                'fecha_envio_claves' => convertirFecha($csvData['fecha_envio_claves']),
                'claves_no_oficial_fecha' => convertirFecha($csvData['claves_no_oficial'])
            ], $stats);
            
            $pdo->commit();
            $stats['importados']++;
            
            if ($stats['procesados'] % 10 == 0) {
                echo "📊 Procesados: {$stats['procesados']} registros...\n";
            }
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $stats['errores']++;
            $errores[] = "Línea $linea: " . $e->getMessage();
            echo "❌ ERROR en línea $linea: " . $e->getMessage() . "\n";
        }
    }
    
    fclose($handle);
    
    // Mostrar resumen
    echo "\n";
    echo "╔════════════════════════════════════════════════════════════╗\n";
    echo "║              RESUMEN DE IMPORTACIÓN                        ║\n";
    echo "╚════════════════════════════════════════════════════════════╝\n\n";
    echo "📋 Registros procesados:  {$stats['procesados']}\n";
    echo "✅ Registros importados:  {$stats['importados']}\n";
    echo "🏢 Empresas creadas:      {$stats['empresas_creadas']}\n";
    echo "👤 Alumnos creados:       {$stats['alumnos_creados']}\n";
    echo "📚 Cursos creados:        {$stats['cursos_creados']}\n";
    echo "❌ Errores:               {$stats['errores']}\n";
    
    if (!empty($errores)) {
        echo "\n";
        echo "╔════════════════════════════════════════════════════════════╗\n";
        echo "║              ERRORES DETALLADOS                            ║\n";
        echo "╚════════════════════════════════════════════════════════════╝\n\n";
        foreach ($errores as $error) {
            echo "• $error\n";
        }
    }
    
    echo "\n✨ ¡Importación completada!\n\n";
    
} catch (Exception $e) {
    echo "\n❌ ERROR FATAL: " . $e->getMessage() . "\n";
    exit(1);
}
