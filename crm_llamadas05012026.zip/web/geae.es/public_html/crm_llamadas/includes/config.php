<?php
/**
 * ARCHIVO DE CONFIGURACIÓN - CRM LLAMADAS
 * Ubicación: /includes/config.php
 * Base de datos: geae_crm_llamadas
 * 
 * Crea AMBAS conexiones: MySQLi ($conn) y PDO ($pdo)
 */

// ============================================================================
// MANEJADOR GLOBAL DE ERRORES
// ============================================================================

// Cargar error handler si existe
if (file_exists(__DIR__ . '/error_handler.php')) {
    require_once __DIR__ . '/error_handler.php';
}

// Iniciar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================================================
// CONFIGURACIÓN DE BASE DE DATOS
// ============================================================================

$db_host = 'localhost';
$db_user = 'geae_crm_llamadas';
$db_pass = '&4222SFCrb1975';
$db_name = 'geae_crm_llamadas';

// ============================================================================
// CONEXIÓN MySQLi (para archivos que usan $conn)
// ============================================================================

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Verificar conexión MySQLi
if ($conn->connect_error) {
    die("Error de conexión MySQLi: " . $conn->connect_error);
}

// Establecer charset UTF-8
$conn->set_charset("utf8mb4");

// ============================================================================
// CONEXIÓN PDO (para archivos que usan $pdo)
// ============================================================================

try {
    $dsn = "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
    
} catch (PDOException $e) {
    die("Error de conexión PDO: " . $e->getMessage());
}

// ============================================================================
// CONFIGURACIÓN DE ZONA HORARIA
// ============================================================================

date_default_timezone_set('Europe/Madrid');

// ============================================================================
// CONFIGURACIÓN DE LA APLICACIÓN
// ============================================================================

// URL base de la aplicación
define('BASE_URL', 'https://www.geae.es/crm_llamadas/');

// Rutas del sistema
define('ROOT_PATH', dirname(__DIR__) . '/');
define('UPLOADS_PATH', ROOT_PATH . 'uploads/');

// Configuración de subida de archivos
define('MAX_FILE_SIZE', 50 * 1024 * 1024); // 50 MB
define('ALLOWED_EXTENSIONS', ['xlsx', 'xls', 'csv', 'pdf', 'doc', 'docx']);

// ============================================================================
// FUNCIONES AUXILIARES
// ============================================================================

/**
 * Función para escapar datos de forma segura (MySQLi)
 */
function escapeData($data) {
    global $conn;
    return $conn->real_escape_string(trim($data));
}

/**
 * Función para verificar si el usuario está logueado
 */
function estaLogueado() {
    return isset($_SESSION['id_usuario']) && !empty($_SESSION['id_usuario']);
}

/**
 * Función para redirigir
 */
function redirect($url) {
    if (headers_sent()) {
        echo "<script>window.location.href='{$url}';</script>";
    } else {
        header("Location: " . $url);
    }
    exit;
}

/**
 * Función para obtener usuario actual
 */
function obtenerUsuarioActual() {
    if (!estaLogueado()) {
        return null;
    }
    
    return [
        'id' => $_SESSION['id_usuario'] ?? 0,
        'nombre' => $_SESSION['nombre'] ?? '',
        'apellidos' => $_SESSION['apellidos'] ?? '',
        'email' => $_SESSION['email'] ?? '',
        'rol' => $_SESSION['rol'] ?? ''
    ];
}

/**
 * Función para verificar rol
 */
function verificarRol($roles_permitidos) {
    if (!is_array($roles_permitidos)) {
        $roles_permitidos = [$roles_permitidos];
    }
    
    if (!estaLogueado()) {
        redirect(BASE_URL . 'auth/login.php');
    }
    
    if (!in_array($_SESSION['rol'], $roles_permitidos)) {
        http_response_code(403);
        die('Acceso denegado. No tienes permisos para acceder a esta página.');
    }
}

/**
 * Función para formatear fecha
 */
function formatearFecha($fecha, $formato = 'd/m/Y H:i') {
    if (empty($fecha)) return '-';
    return date($formato, strtotime($fecha));
}

/**
 * Función para formatear número con decimales
 */
function formatearNumero($numero, $decimales = 2) {
    return number_format($numero, $decimales, ',', '.');
}

// ============================================================================
// VERIFICACIÓN DE CONEXIONES (para debug - comentar en producción)
// ============================================================================

/*
// Descomentar para verificar:
echo "<!-- MySQLi: " . ($conn->ping() ? 'OK' : 'ERROR') . " -->\n";
echo "<!-- PDO: " . ($pdo ? 'OK' : 'ERROR') . " -->\n";
*/

?>
