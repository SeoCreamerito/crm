<?php
/**
 * Sistema de Autenticación - CRM Llamadas
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function hasRole($roles) {
    if (!isLoggedIn()) return false;
    if (!is_array($roles)) $roles = [$roles];
    return in_array($_SESSION['rol'] ?? '', $roles);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /crm_llamadas/auth/login.php');
        exit;
    }
}

function requireRole($roles) {
    requireLogin();
    if (!hasRole($roles)) {
        $rol = $_SESSION['rol'] ?? '';
        if ($rol === 'admin') header('Location: /crm_llamadas/admin/dashboard.php');
        elseif ($rol === 'agent') header('Location: /crm_llamadas/agent/panel.php');
        else header('Location: /crm_llamadas/auth/login.php');
        exit;
    }
}

function getCurrentUserId() { return $_SESSION['user_id'] ?? null; }
function getCurrentUserName() { return $_SESSION['nombre'] ?? 'Usuario'; }
function getCurrentUserRole() { return $_SESSION['rol'] ?? ''; }
?>
