<?php
/**
 * Cargador manual SEGURO de PhpSpreadsheet
 */

$psBase = __DIR__ . '/../vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet';

// Lista de archivos esenciales
$archivos = [
    $psBase . '/Spreadsheet.php',
    $psBase . '/IOFactory.php',
    $psBase . '/Reader/IReader.php',
    $psBase . '/Reader/DefaultReadFilter.php',
    $psBase . '/Reader/Xlsx.php',
    $psBase . '/Cell/Coordinate.php',
    $psBase . '/Cell/DataType.php',
    $psBase . '/Worksheet/Worksheet.php',
    $psBase . '/Shared/Date.php'
];

// Verificar que todos existan
foreach ($archivos as $archivo) {
    if (!file_exists($archivo)) {
        // En producción, podrías mostrar un mensaje amigable
        error_log("PhpSpreadsheet: archivo no encontrado - $archivo");
        die("Error interno: biblioteca de Excel incompleta.");
    }
    require_once $archivo;
}

// Verificar que las clases estén disponibles
if (!class_exists('PhpOffice\\PhpSpreadsheet\\Spreadsheet') || 
    !class_exists('PhpOffice\\PhpSpreadsheet\\IOFactory')) {
    die("Error: PhpSpreadsheet no se inicializó correctamente.");
}

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;