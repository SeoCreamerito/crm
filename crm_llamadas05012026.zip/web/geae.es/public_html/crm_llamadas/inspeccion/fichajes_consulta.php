<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
requireLogin();
requireRole('inspeccion');

// Obtener todos los usuarios que fichan
$usuarios = $conexion->query("
    SELECT id, CONCAT(nombre, ' ', apellidos) AS nombre_completo, rol 
    FROM usuarios 
    WHERE rol IN ('agent', 'inspeccion') AND activo = 1 
    ORDER BY nombre_completo
");

// Filtros
$id_usuario = $_GET['usuario'] ?? null;
$fecha_desde = $_GET['desde'] ?? date('Y-m-d', strtotime('-7 days'));
$fecha_hasta = $_GET['hasta'] ?? date('Y-m-d');

// Consulta de jornadas
$condicion = "s.fecha_entrada BETWEEN ? AND ?";
$params = [$fecha_desde, $fecha_hasta];
$tipos = "ss";

if ($id_usuario) {
    $condicion .= " AND s.id_usuario = ?";
    $params[] = $id_usuario;
    $tipos .= "i";
}

$stmt = $conexion->prepare("
    SELECT s.*, 
           CONCAT(u.nombre, ' ', u.apellidos) AS usuario_completo,
           u.dni,
           u.num_ss,
           u.puesto,
           u.rol,
           TIME_FORMAT(SEC_TO_TIME(TIMESTAMPDIFF(SECOND, s.fecha_entrada, COALESCE(s.fecha_salida, NOW()))), '%Hh %im') AS duracion,
           (SELECT COUNT(*) FROM pausas p WHERE p.id_sesion = s.id) AS total_pausas,
           s.cerrado_por_admin
    FROM sesiones_actividad s
    JOIN usuarios u ON s.id_usuario = u.id
    WHERE $condicion
    ORDER BY s.fecha_entrada DESC
");
$stmt->bind_param($tipos, ...$params);
$stmt->execute();
$jornadas = $stmt->get_result();

// Horas extra (solo lectura)
$he_todos = $conexion->query("
    SELECT he.*, 
           CONCAT(u.nombre, ' ', u.apellidos) AS usuario,
           u.dni,
           CASE he.estado
               WHEN 'aprobada' THEN '✅ Aprobada'
               WHEN 'rechazada' THEN '❌ Rechazada'
               ELSE '⏳ Pendiente'
           END AS estado_label
    FROM horas_extra he
    JOIN usuarios u ON he.id_usuario = u.id
    ORDER BY he.fecha DESC
    LIMIT 50
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inspección de Fichajes - CRM Llamadas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/crm_llamadas/assets/css/main.css">
    <style>
        .jornada-incompleta { background-color: #fff3cd; }
        .jornada-completa { background-color: #f8f9fa; }
        .pausa-item { font-size: 0.9em; color: #6c757d; }
        .readonly-badge { background-color: #6c757d; }
    </style>
</head>
<body>

<div class="container-fluid mt-3">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>👁️‍🗨️ Inspección de Fichajes (Solo Lectura)</h2>
        <a href="../auth/logout.php" class="btn btn-outline-secondary">Salir</a>
    </div>

    <!-- Filtros -->
    <div class="card p-3 mb-4">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label>Usuario</label>
                <select name="usuario" class="form-select">
                    <option value="">Todos los usuarios</option>
                    <?php while ($u = $usuarios->fetch_assoc()): ?>
                        <option value="<?= $u['id'] ?>" <?= ($id_usuario == $u['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($u['nombre_completo']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label>Desde</label>
                <input type="date" name="desde" class="form-control" value="<?= htmlspecialchars($fecha_desde) ?>">
            </div>
            <div class="col-md-2">
                <label>Hasta</label>
                <input type="date" name="hasta" class="form-control" value="<?= htmlspecialchars($fecha_hasta) ?>">
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">Filtrar</button>
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <span class="badge readonly-badge">Acceso de solo lectura</span>
            </div>
        </form>
    </div>

    <!-- Horas Extra -->
    <div class="card mb-4">
        <div class="card-header bg-secondary text-white">
            📋 Horas Extra (todas)
        </div>
        <div class="card-body">
            <?php if ($he_todos->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead><tr><th>Usuario</th><th>DNI</th><th>Fecha</th><th>Horas</th><th>Tipo</th><th>Estado</th><th>Motivo</th></tr></thead>
                        <tbody>
                            <?php while ($he = $he_todos->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($he['usuario']) ?></td>
                                <td><?= htmlspecialchars($he['dni']) ?></td>
                                <td><?= $he['fecha'] ?></td>
                                <td><?= $he['horas'] ?></td>
                                <td><?= $he['tipo'] ?></td>
                                <td><?= $he['estado_label'] ?></td>
                                <td><?= htmlspecialchars($he['motivo']) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">No hay registros de horas extra.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Jornadas -->
    <h4>Jornadas registradas</h4>
    <?php if ($jornadas->num_rows > 0): ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Usuario</th>
                        <th>DNI</th>
                        <th>Nº SS</th>
                        <th>Puesto</th>
                        <th>Entrada</th>
                        <th>Salida</th>
                        <th>Duración</th>
                        <th>Pausas</th>
                        <th>Observaciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($j = $jornadas->fetch_assoc()):
                        $completa = $j['fecha_salida'] !== null;
                        $clase = $completa ? 'jornada-completa' : 'jornada-incompleta';
                    ?>
                    <tr class="<?= $clase ?>">
                        <td><?= htmlspecialchars($j['usuario_completo']) ?></td>
                        <td><?= htmlspecialchars($j['dni']) ?></td>
                        <td><?= htmlspecialchars($j['num_ss'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($j['puesto']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($j['fecha_entrada'])) ?></td>
                        <td>
                            <?php if ($completa): ?>
                                <?= date('d/m/Y H:i', strtotime($j['fecha_salida'])) ?>
                                <?php if ($j['cerrado_por_admin']): ?>
                                    <span class="badge bg-info">Cerrado por admin</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-danger">⚠️ Sin cerrar</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $j['duracion'] ?></td>
                        <td>
                            <?php if ($j['total_pausas'] > 0): ?>
                                <details>
                                    <summary><?= $j['total_pausas'] ?> pausa(s)</summary>
                                    <?php
                                    $pausas = $conexion->query("SELECT * FROM pausas WHERE id_sesion = {$j['id']} ORDER BY hora_inicio");
                                    while ($p = $pausas->fetch_assoc()):
                                        $duracion = $p['duracion_minutos'] ?? '0';
                                    ?>
                                        <div class="pausa-item">
                                            <?= date('H:i', strtotime($p['hora_inicio'])) ?> - 
                                            <?= $p['hora_fin'] ? date('H:i', strtotime($p['hora_fin'])) : 'en curso' ?> 
                                            (<?= $duracion ?> min) [<?= $p['tipo'] ?>]
                                        </div>
                                    <?php endwhile; ?>
                                </details>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!$completa): ?>
                                <span class="text-warning">Jornada incompleta</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info">No se encontraron jornadas con los filtros aplicados.</div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>