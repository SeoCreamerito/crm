<?php
ini_set('memory_limit', '256M');
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos']);

$id_curso = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id_curso) {
    header('Location: listado.php');
    exit;
}

// Obtener datos del curso
$sql = "SELECT c.*, 
        e.denominacion as empresa_nombre,
        e.cif as empresa_cif,
        a.nombre as alumno_nombre_completo,
        a.dni as alumno_dni,
        a.email as alumno_email
        FROM cursos c
        LEFT JOIN empresas e ON c.id_empresa = e.id
        LEFT JOIN alumnos a ON c.id_alumno = a.id
        WHERE c.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_curso);
$stmt->execute();
$curso = $stmt->get_result()->fetch_assoc();

if (!$curso) {
    header('Location: listado.php?error=not_found');
    exit;
}

$page_title = "Detalle del Curso #" . $curso['id'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-book me-2"></i>Curso #<?php echo $curso['id']; ?></h1>
        <a href="listado.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Volver
        </a>
    </div>

    <!-- Información del Curso -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Información del Curso</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Nombre:</strong> <?php echo htmlspecialchars($curso['nombre_curso']); ?></p>
                    <p><strong>Horas:</strong> <?php echo $curso['horas_curso']; ?>h</p>
                    <p><strong>Estado:</strong> <?php echo $curso['estado']; ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Alumno:</strong> <?php echo htmlspecialchars($curso['alumno_nombre_completo']); ?></p>
                    <p><strong>DNI:</strong> <?php echo htmlspecialchars($curso['alumno_dni']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($curso['alumno_email']); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Moodle -->
    <div class="card mb-4">
        <div class="card-header <?php 
            echo $curso['moodle_estado'] == 'matriculado' ? 'bg-success' : 'bg-secondary';
        ?> text-white">
            <h5 class="mb-0">
                <i class="fas fa-cloud me-2"></i>Integración con Moodle
                <span class="badge bg-light text-dark float-end">
                    <?php echo strtoupper($curso['moodle_estado']); ?>
                </span>
            </h5>
        </div>
        <div class="card-body">
            <?php if ($curso['moodle_estado'] == 'pendiente'): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-clock me-2"></i>
                    Este curso aún no ha sido dado de alta en Moodle.
                </div>
                <a href="moodle_alta_individual.php?id=<?php echo $curso['id']; ?>" 
                   class="btn btn-success">
                    <i class="fas fa-cloud-upload-alt me-2"></i>
                    Dar de Alta en Moodle
                </a>
            <?php elseif ($curso['moodle_estado'] == 'matriculado'): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    Alumno matriculado correctamente en Moodle.
                </div>
                <?php if ($curso['moodle_course_id']): ?>
                <p><strong>Curso ID:</strong> <?php echo $curso['moodle_course_id']; ?></p>
                <a href="https://www.geae.es/plataforma/course/view.php?id=<?php echo $curso['moodle_course_id']; ?>" 
                   target="_blank" class="btn btn-primary">
                    <i class="fas fa-external-link-alt me-2"></i>
                    Abrir en Moodle
                </a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>