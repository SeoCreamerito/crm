<?php
/**
 * AJAX - Obtener estadísticas por teleoperadora
 */

require_once __DIR__ . '/../../includes/config_cursos.php';
require_once __DIR__ . '/../../includes/functions_cursos.php';

header('Content-Type: application/json');

verificarRolCursos(['admin']);

$sql = "
    SELECT 
        u.nombre,
        u.apellidos,
        COUNT(c.id) as total_cursos,
        SUM(c.credito_formacion) as credito_total
    FROM usuarios u
    LEFT JOIN cursos c ON u.id = c.id_teleoperadora
    WHERE u.rol = 'agent' AND u.activo = 1
    GROUP BY u.id, u.nombre, u.apellidos
    ORDER BY total_cursos DESC
    LIMIT 10
";

$result = $conn->query($sql);

$nombres = [];
$cursos = [];
$creditos = [];

while ($row = $result->fetch_assoc()) {
    $nombres[] = $row['nombre'] . ' ' . ($row['apellidos'] ?? '');
    $cursos[] = (int)$row['total_cursos'];
    $creditos[] = (float)$row['credito_total'];
}

echo json_encode([
    'nombres' => $nombres,
    'cursos' => $cursos,
    'creditos' => $creditos
]);
