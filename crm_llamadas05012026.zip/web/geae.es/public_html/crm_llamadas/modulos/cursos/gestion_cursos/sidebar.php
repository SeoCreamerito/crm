<?php
/**
 * Sidebar - Navegación del Módulo de Cursos
 * VERSIÓN CON INTEGRACIÓN MOODLE
 */
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<nav id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h3>
            <i class="fas fa-graduation-cap me-2"></i>
            GEAE Cursos
        </h3>
        <p class="mb-0 text-small">Sistema de Gestión FUNDAE</p>
    </div>

    <ul class="list-unstyled components">
        <li>
            <a href="index.php" class="<?php echo $current_page === 'index' ? 'active' : ''; ?>">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
        </li>
        
        <li>
            <a href="listado.php" class="<?php echo $current_page === 'listado' ? 'active' : ''; ?>">
                <i class="fas fa-list"></i>
                Listado de Cursos
            </a>
        </li>
        
        <li>
            <a href="crear.php" class="<?php echo $current_page === 'crear' ? 'active' : ''; ?>">
                <i class="fas fa-plus-circle"></i>
                Crear Curso
            </a>
        </li>
        
        <li>
            <a href="empresas.php" class="<?php echo $current_page === 'empresas' ? 'active' : ''; ?>">
                <i class="fas fa-building"></i>
                Empresas
            </a>
        </li>
        
        <li>
            <a href="alumnos.php" class="<?php echo $current_page === 'alumnos' ? 'active' : ''; ?>">
                <i class="fas fa-user-graduate"></i>
                Alumnos
            </a>
        </li>
        
        <!-- INTEGRACIÓN MOODLE -->
        <li style="border-top: 2px solid rgba(255,255,255,0.15); margin-top: 15px; padding-top: 15px;">
            <a href="moodle_gestion.php" class="<?php echo $current_page === 'moodle_gestion' ? 'active' : ''; ?>">
                <i class="fas fa-cloud"></i>
                <span>Integración Moodle</span>
                <?php
                // Mostrar badge con cursos pendientes
                try {
                    $sql_pendientes = "SELECT COUNT(*) as total FROM cursos 
                                      WHERE moodle_estado IN ('pendiente', 'error') 
                                      OR moodle_estado IS NULL";
                    $result_pendientes = $conn->query($sql_pendientes);
                    if ($result_pendientes) {
                        $pendientes = $result_pendientes->fetch_assoc()['total'];
                        if ($pendientes > 0) {
                            echo '<span class="badge bg-warning rounded-pill float-end">' . $pendientes . '</span>';
                        }
                    }
                } catch (Exception $e) {
                    // Silenciar error si la tabla no existe aún
                }
                ?>
            </a>
        </li>
        
        <?php if ($_SESSION['rol'] === 'admin'): ?>
        <li style="border-top: 2px solid rgba(255,255,255,0.15); margin-top: 15px; padding-top: 15px;">
            <a href="catalogos.php" class="<?php echo $current_page === 'catalogos' ? 'active' : ''; ?>">
                <i class="fas fa-cogs"></i>
                Catálogos
            </a>
        </li>
        
        <li>
            <a href="reportes.php" class="<?php echo $current_page === 'reportes' ? 'active' : ''; ?>">
                <i class="fas fa-chart-bar"></i>
                Reportes
            </a>
        </li>
        
        <li>
            <a href="importar.php" class="<?php echo $current_page === 'importar' ? 'active' : ''; ?>">
                <i class="fas fa-file-upload"></i>
                Importar CSV
            </a>
        </li>
        
        <li>
            <a href="moodle_configuracion.php" class="<?php echo $current_page === 'moodle_configuracion' ? 'active' : ''; ?>">
                <i class="fas fa-wrench"></i>
                Config. Moodle
            </a>
        </li>
        <?php endif; ?>
        
        <li style="border-top: 2px solid rgba(255,255,255,0.2); margin-top: 20px; padding-top: 20px;">
            <a href="<?php echo CRM_INDEX_URL; ?>">
                <i class="fas fa-arrow-left"></i>
                Volver al CRM
            </a>
        </li>
    </ul>
</nav>
