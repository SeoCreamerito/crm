<?php
/**
 * AJAX: Reenviar Credenciales Moodle
 * Reenvía las credenciales de acceso por email
 */

require_once __DIR__ . '/../../includes/config_cursos.php';
require_once __DIR__ . '/../../includes/functions_cursos.php';

header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Sesión no válida']);
    exit;
}

// Leer datos JSON
$input = json_decode(file_get_contents('php://input'), true);
$id_curso = isset($input['id_curso']) ? (int)$input['id_curso'] : 0;

if (!$id_curso) {
    echo json_encode(['success' => false, 'message' => 'ID de curso no válido']);
    exit;
}

try {
    // Obtener datos del curso y credenciales
    $sql = "SELECT 
                c.id,
                c.nombre_curso,
                c.id_empresa,
                c.id_alumno,
                a.nombre as alumno_nombre,
                a.apellidos as alumno_apellidos,
                a.email as alumno_email,
                e.razon_social as empresa_nombre,
                mal.username_moodle,
                mal.email as email_moodle,
                mal.moodle_user_id
            FROM cursos c
            INNER JOIN alumnos a ON c.id_alumno = a.id
            INNER JOIN empresas e ON c.id_empresa = e.id
            LEFT JOIN moodle_altas_log mal ON mal.id_curso = c.id
            WHERE c.id = ?
            ORDER BY mal.id DESC
            LIMIT 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id_curso);
    $stmt->execute();
    $datos = $stmt->get_result()->fetch_assoc();
    
    if (!$datos || !$datos['username_moodle']) {
        echo json_encode([
            'success' => false,
            'message' => 'No se encontraron credenciales para reenviar'
        ]);
        exit;
    }
    
    // Obtener plantilla de email
    $sql_plantilla = "SELECT * FROM moodle_plantillas_email 
                     WHERE tipo = 'reenvio_credenciales' AND activa = 1 
                     LIMIT 1";
    $plantilla = $conn->query($sql_plantilla)->fetch_assoc();
    
    if (!$plantilla) {
        // Plantilla por defecto
        $asunto = "Recordatorio - Credenciales de acceso a Moodle GEAE";
        $mensaje = "
        <html>
        <head><style>
            body { font-family: Arial, sans-serif; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #0066cc; color: white; padding: 20px; text-align: center; }
            .content { background: #f5f5f5; padding: 20px; }
            .credentials { background: white; padding: 15px; margin: 15px 0; border-left: 4px solid #0066cc; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style></head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>GEAE Formación - Credenciales Moodle</h2>
                </div>
                <div class='content'>
                    <p>Estimado/a <strong>{$datos['alumno_nombre']} {$datos['alumno_apellidos']}</strong>,</p>
                    <p>Le reenviamos las credenciales de acceso a la plataforma Moodle para su curso:</p>
                    <p><strong>{$datos['nombre_curso']}</strong></p>
                    
                    <div class='credentials'>
                        <p><strong>🌐 URL:</strong> https://www.geae.es/plataforma</p>
                        <p><strong>👤 Usuario:</strong> {$datos['username_moodle']}</p>
                        <p><strong>📧 Email:</strong> {$datos['email_moodle']}</p>
                        <p><em>Si olvidó su contraseña, use la opción 'Recuperar contraseña' en la plataforma.</em></p>
                    </div>
                    
                    <p>Para cualquier consulta, no dude en contactarnos.</p>
                </div>
                <div class='footer'>
                    <p>Este es un email automático. Por favor, no responda a este mensaje.</p>
                    <p>GEAE Formación - {$datos['empresa_nombre']}</p>
                </div>
            </div>
        </body>
        </html>
        ";
    } else {
        // Usar plantilla
        $variables = [
            '{nombre}' => $datos['alumno_nombre'],
            '{apellidos}' => $datos['alumno_apellidos'],
            '{curso}' => $datos['nombre_curso'],
            '{username}' => $datos['username_moodle'],
            '{email}' => $datos['email_moodle'],
            '{url_moodle}' => 'https://www.geae.es/plataforma',
            '{empresa}' => $datos['empresa_nombre']
        ];
        
        $asunto = str_replace(array_keys($variables), array_values($variables), $plantilla['asunto']);
        $mensaje = str_replace(array_keys($variables), array_values($variables), $plantilla['contenido_html']);
    }
    
    // Enviar email
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=utf-8\r\n";
    $headers .= "From: GEAE Formación <formacion@geae.es>\r\n";
    $headers .= "Reply-To: formacion@geae.es\r\n";
    
    $email_enviado = mail($datos['alumno_email'], $asunto, $mensaje, $headers);
    
    if ($email_enviado) {
        // Registrar reenvío
        $sql_log = "INSERT INTO moodle_reenvios_email 
                   (id_curso, id_alumno, email_destino, tipo_email, enviado_por, fecha_envio)
                   VALUES (?, ?, ?, 'reenvio_credenciales', ?, NOW())";
        $stmt_log = $conn->prepare($sql_log);
        $stmt_log->bind_param('iisi', 
            $id_curso, 
            $datos['id_alumno'], 
            $datos['alumno_email'], 
            $_SESSION['user_id']
        );
        $stmt_log->execute();
        
        echo json_encode([
            'success' => true,
            'message' => 'Credenciales reenviadas correctamente a ' . $datos['alumno_email']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error al enviar el email. Por favor, inténtelo de nuevo.'
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error al reenviar credenciales: ' . $e->getMessage()
    ]);
}
