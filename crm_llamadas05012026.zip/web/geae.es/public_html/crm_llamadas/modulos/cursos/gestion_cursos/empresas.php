<?php
/**
 * Gestión de Empresas - Módulo FUNDAE
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos']);

$mensaje = '';
$tipo_mensaje = '';

// Crear/Editar empresa
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!empty($_POST['id'])) {
            // Actualizar
            $sql = "UPDATE empresas SET 
                    denominacion = ?, cif = ?, representante_legal = ?, dni_representante = ?,
                    contacto_administrativo = ?, telefono_administrativo = ?, email_administrativo = ?,
                    nombre_asesoria = ?, telefono_asesoria = ?, email_asesoria = ?,
                    actualizado_en = NOW()
                    WHERE id = ?";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ssssssssssi',
                $_POST['denominacion'], $_POST['cif'], $_POST['representante_legal'], $_POST['dni_representante'],
                $_POST['contacto_administrativo'], $_POST['telefono_administrativo'], $_POST['email_administrativo'],
                $_POST['nombre_asesoria'], $_POST['telefono_asesoria'], $_POST['email_asesoria'],
                $_POST['id']
            );
            $stmt->execute();
            $mensaje = "Empresa actualizada correctamente";
            $tipo_mensaje = "success";
        } else {
            // Crear
            $sql = "INSERT INTO empresas (
                    denominacion, cif, representante_legal, dni_representante,
                    contacto_administrativo, telefono_administrativo, email_administrativo,
                    nombre_asesoria, telefono_asesoria, email_asesoria,
                    activo, creado_en
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ssssssssss',
                $_POST['denominacion'], $_POST['cif'], $_POST['representante_legal'], $_POST['dni_representante'],
                $_POST['contacto_administrativo'], $_POST['telefono_administrativo'], $_POST['email_administrativo'],
                $_POST['nombre_asesoria'], $_POST['telefono_asesoria'], $_POST['email_asesoria']
            );
            $stmt->execute();
            $mensaje = "Empresa creada correctamente";
            $tipo_mensaje = "success";
        }
    } catch (Exception $e) {
        $mensaje = "Error: " . $e->getMessage();
        $tipo_mensaje = "danger";
    }
}

// Eliminar empresa (desactivar)
if (isset($_GET['eliminar'])) {
    $sql = "UPDATE empresas SET activo = 0 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $_GET['eliminar']);
    $stmt->execute();
    $mensaje = "Empresa desactivada correctamente";
    $tipo_mensaje = "success";
}

// Buscar empresas
$busqueda = $_GET['busqueda'] ?? '';
$sql = "SELECT e.*, COUNT(c.id) as total_cursos 
        FROM empresas e 
        LEFT JOIN cursos c ON e.id = c.id_empresa
        WHERE e.activo = 1";

if ($busqueda) {
    $sql .= " AND (e.denominacion LIKE ? OR e.cif LIKE ?)";
}

$sql .= " GROUP BY e.id ORDER BY e.denominacion ASC";

$stmt = $conn->prepare($sql);
if ($busqueda) {
    $search = "%$busqueda%";
    $stmt->bind_param('ss', $search, $search);
}
$stmt->execute();
$empresas = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Empresas - FUNDAE</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/cursos.css">
</head>
<body>

<div class="wrapper">
    <?php include 'sidebar.php'; ?>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-building me-2"></i>Gestión de Empresas
                </span>
                
                <div class="ms-auto">
                    <button class="btn btn-gradient-success btn-custom" data-bs-toggle="modal" data-bs-target="#modalEmpresa">
                        <i class="fas fa-plus-circle me-1"></i>Nueva Empresa
                    </button>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <?php if ($mensaje): ?>
            <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show">
                <?php echo htmlspecialchars($mensaje); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <!-- Búsqueda -->
            <div class="filter-card mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-10">
                        <input type="text" name="busqueda" class="form-control" 
                               placeholder="Buscar por nombre o CIF..." 
                               value="<?php echo htmlspecialchars($busqueda); ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-gradient-primary btn-custom w-100">
                            <i class="fas fa-search me-1"></i>Buscar
                        </button>
                    </div>
                </form>
            </div>

            <!-- Tabla de Empresas -->
            <div class="card table-custom">
                <div class="card-header bg-white border-0 pt-3">
                    <h5 class="mb-0">
                        <i class="fas fa-list-ul me-2"></i>
                        Empresas (<?php echo count($empresas); ?> registros)
                    </h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>CIF</th>
                                    <th>Denominación</th>
                                    <th>Representante Legal</th>
                                    <th>Contacto Admin</th>
                                    <th>Cursos</th>
                                    <th class="text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($empresas)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-5">
                                        <i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i>
                                        <p class="text-muted">No se encontraron empresas</p>
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach ($empresas as $empresa): ?>
                                <tr>
                                    <td><?php echo $empresa['id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($empresa['cif']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($empresa['denominacion']); ?></td>
                                    <td><?php echo htmlspecialchars($empresa['representante_legal'] ?? '-'); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($empresa['contacto_administrativo'] ?? '-'); ?><br>
                                        <small class="text-muted"><?php echo htmlspecialchars($empresa['telefono_administrativo'] ?? ''); ?></small>
                                    </td>
                                    <td>
                                        <?php if ($empresa['total_cursos'] > 0): ?>
                                        <a href="listado.php?empresa=<?php echo urlencode($empresa['denominacion']); ?>" class="badge bg-primary">
                                            <?php echo $empresa['total_cursos']; ?> cursos
                                        </a>
                                        <?php else: ?>
                                        <span class="text-muted">0 cursos</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <button onclick='editarEmpresa(<?php echo json_encode($empresa); ?>)' 
                                                    class="btn btn-sm btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php if ($empresa['total_cursos'] == 0): ?>
                                            <a href="?eliminar=<?php echo $empresa['id']; ?>" 
                                               onclick="return confirm('¿Eliminar esta empresa?')"
                                               class="btn btn-sm btn-danger" title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Modal Empresa -->
<div class="modal fade" id="modalEmpresa" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">
                        <i class="fas fa-building me-2"></i>
                        <span id="modalTitleText">Nueva Empresa</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="empresa_id">
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">CIF <span class="text-danger">*</span></label>
                            <input type="text" name="cif" id="cif" class="form-control" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Denominación Social <span class="text-danger">*</span></label>
                            <input type="text" name="denominacion" id="denominacion" class="form-control" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Representante Legal</label>
                            <input type="text" name="representante_legal" id="representante_legal" class="form-control">
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">DNI Representante</label>
                            <input type="text" name="dni_representante" id="dni_representante" class="form-control">
                        </div>
                        
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">Datos Administrativos</h6>
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label">Contacto</label>
                            <input type="text" name="contacto_administrativo" id="contacto_administrativo" class="form-control">
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label">Teléfono</label>
                            <input type="text" name="telefono_administrativo" id="telefono_administrativo" class="form-control">
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label">Email</label>
                            <input type="email" name="email_administrativo" id="email_administrativo" class="form-control">
                        </div>
                        
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">Datos de Asesoría</h6>
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label">Nombre Asesoría</label>
                            <input type="text" name="nombre_asesoria" id="nombre_asesoria" class="form-control">
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label">Teléfono</label>
                            <input type="text" name="telefono_asesoria" id="telefono_asesoria" class="form-control">
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label">Email</label>
                            <input type="email" name="email_asesoria" id="email_asesoria" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-gradient-success">
                        <i class="fas fa-save me-1"></i>Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
});

function editarEmpresa(empresa) {
    document.getElementById('modalTitleText').textContent = 'Editar Empresa';
    document.getElementById('empresa_id').value = empresa.id;
    document.getElementById('cif').value = empresa.cif;
    document.getElementById('denominacion').value = empresa.denominacion;
    document.getElementById('representante_legal').value = empresa.representante_legal || '';
    document.getElementById('dni_representante').value = empresa.dni_representante || '';
    document.getElementById('contacto_administrativo').value = empresa.contacto_administrativo || '';
    document.getElementById('telefono_administrativo').value = empresa.telefono_administrativo || '';
    document.getElementById('email_administrativo').value = empresa.email_administrativo || '';
    document.getElementById('nombre_asesoria').value = empresa.nombre_asesoria || '';
    document.getElementById('telefono_asesoria').value = empresa.telefono_asesoria || '';
    document.getElementById('email_asesoria').value = empresa.email_asesoria || '';
    
    new bootstrap.Modal(document.getElementById('modalEmpresa')).show();
}

// Limpiar modal al cerrarlo
document.getElementById('modalEmpresa').addEventListener('hidden.bs.modal', function() {
    document.getElementById('modalTitleText').textContent = 'Nueva Empresa';
    document.querySelector('#modalEmpresa form').reset();
    document.getElementById('empresa_id').value = '';
});
</script>

</body>
</html>
