<?php
/**
 * DIAGNÓSTICO AVANZADO - CONEXIÓN BASE DE DATOS
 * Ejecuta este archivo para identificar el problema de conexión
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Diagnóstico de Conexión - Módulo Cursos</h1>";
echo "<hr>";

// Test 1: Verificar config.php del CRM
echo "<h2>1. Verificar config.php del CRM</h2>";
$config_path = __DIR__ . '/../../../includes/config.php';
echo "Buscando: <code>$config_path</code><br>";

if (file_exists($config_path)) {
    echo "<span style='color:green'>✓ Archivo encontrado</span><br>";
    
    // Leer el contenido para analizar
    $content = file_get_contents($config_path);
    
    echo "<h3>Información detectada en config.php:</h3>";
    
    // Buscar credenciales (sin mostrar contraseñas)
    if (preg_match('/\$db_host\s*=\s*["\']([^"\']+)["\']/', $content, $matches)) {
        echo "Host: <code>{$matches[1]}</code><br>";
    }
    if (preg_match('/\$db_user\s*=\s*["\']([^"\']+)["\']/', $content, $matches)) {
        echo "Usuario: <code>{$matches[1]}</code><br>";
    }
    if (preg_match('/\$db_name\s*=\s*["\']([^"\']+)["\']/', $content, $matches)) {
        echo "Base de datos: <code>{$matches[1]}</code><br>";
    }
    
    // Intentar incluirlo
    echo "<br><strong>Intentando cargar config.php...</strong><br>";
    try {
        require_once $config_path;
        echo "<span style='color:green'>✓ Config.php cargado</span><br>";
    } catch (Exception $e) {
        echo "<span style='color:red'>✗ Error: " . $e->getMessage() . "</span><br>";
    }
    
} else {
    echo "<span style='color:red'>✗ Archivo NO encontrado</span><br>";
    die("No se puede continuar sin config.php");
}

echo "<hr>";

// Test 2: Verificar conexión actual
echo "<h2>2. Verificar Conexión a Base de Datos</h2>";

if (isset($conn) && $conn instanceof mysqli) {
    echo "<span style='color:green'>✓ Variable \$conn existe y es mysqli</span><br>";
    
    // Verificar estado de conexión
    if ($conn->ping()) {
        echo "<span style='color:green'>✓ Conexión activa</span><br>";
        echo "Servidor: " . $conn->host_info . "<br>";
        echo "Versión MySQL: " . $conn->server_version . "<br>";
        
        // Verificar usuario actual
        $result = $conn->query("SELECT USER(), DATABASE()");
        if ($result) {
            $row = $result->fetch_row();
            echo "Usuario conectado: <code>{$row[0]}</code><br>";
            echo "Base de datos actual: <code>{$row[1]}</code><br>";
        }
        
    } else {
        echo "<span style='color:red'>✗ Conexión no está activa</span><br>";
        echo "Error: " . $conn->error . "<br>";
    }
    
} else {
    echo "<span style='color:red'>✗ Variable \$conn NO está definida o no es mysqli</span><br>";
    
    // Intentar crear conexión manualmente
    echo "<br><h3>Intentando conectar manualmente...</h3>";
    
    // Valores por defecto (AJUSTAR según tu configuración)
    $test_configs = [
        ['localhost', 'geae_crm', '', 'geae_crm_llamadas'],
        ['localhost', 'geae_crm_llamadas', '', 'geae_crm_llamadas'],
        ['localhost', 'root', '', 'geae_crm_llamadas'],
    ];
    
    foreach ($test_configs as $i => $config) {
        list($host, $user, $pass, $db) = $config;
        echo "<br>Probando config " . ($i + 1) . ": <code>$user@$host/$db</code>... ";
        
        $test_conn = @new mysqli($host, $user, $pass, $db);
        
        if ($test_conn->connect_error) {
            echo "<span style='color:red'>✗ Error: " . $test_conn->connect_error . "</span>";
        } else {
            echo "<span style='color:green'>✓ CONEXIÓN EXITOSA</span><br>";
            echo "<div style='background:#d4edda; padding:10px; margin:10px 0; border-left:4px solid #28a745;'>";
            echo "<strong>¡Credenciales correctas encontradas!</strong><br>";
            echo "Host: <code>$host</code><br>";
            echo "Usuario: <code>$user</code><br>";
            echo "Base de datos: <code>$db</code><br>";
            echo "</div>";
            $test_conn->close();
            break;
        }
    }
}

echo "<hr>";

// Test 3: Verificar tablas
echo "<h2>3. Verificar Tablas del Módulo</h2>";

if (isset($conn) && $conn->ping()) {
    $tablas = ['cursos', 'empresas', 'alumnos', 'usuarios'];
    
    foreach ($tablas as $tabla) {
        $result = @$conn->query("SHOW TABLES LIKE '$tabla'");
        if ($result && $result->num_rows > 0) {
            // Contar registros
            $count_result = $conn->query("SELECT COUNT(*) as total FROM $tabla");
            $total = $count_result->fetch_assoc()['total'];
            echo "<span style='color:green'>✓</span> Tabla <code>$tabla</code>: $total registros<br>";
        } else {
            echo "<span style='color:red'>✗</span> Tabla <code>$tabla</code> NO existe<br>";
        }
    }
    
    // Verificar columnas de mes_accion
    echo "<br><h3>Verificar columnas nuevas:</h3>";
    $result = @$conn->query("SHOW COLUMNS FROM cursos LIKE 'mes_accion'");
    if ($result && $result->num_rows > 0) {
        echo "<span style='color:green'>✓</span> Campo <code>mes_accion</code> existe<br>";
    } else {
        echo "<span style='color:orange'>⚠</span> Campo <code>mes_accion</code> NO existe (ejecutar agregar_mes_accion.sql)<br>";
    }
    
} else {
    echo "<span style='color:orange'>⚠ No se puede verificar (sin conexión)</span><br>";
}

echo "<hr>";

// Test 4: Verificar permisos del usuario
echo "<h2>4. Verificar Permisos del Usuario</h2>";

if (isset($conn) && $conn->ping()) {
    $result = $conn->query("SHOW GRANTS");
    if ($result) {
        echo "<strong>Permisos actuales:</strong><br>";
        echo "<pre style='background:#f0f0f0; padding:10px;'>";
        while ($row = $result->fetch_row()) {
            echo htmlspecialchars($row[0]) . "\n";
        }
        echo "</pre>";
    }
} else {
    echo "<span style='color:orange'>⚠ No se puede verificar (sin conexión)</span><br>";
}

echo "<hr>";

// Test 5: Probar función getCursoById
echo "<h2>5. Probar Función getCursoById</h2>";

if (isset($conn) && $conn->ping()) {
    
    // Obtener un curso de prueba
    $result = $conn->query("SELECT id FROM cursos LIMIT 1");
    if ($result && $result->num_rows > 0) {
        $id_test = $result->fetch_assoc()['id'];
        echo "Probando con curso ID: <code>$id_test</code><br>";
        
        // Incluir funciones
        require_once __DIR__ . '/../includes/functions_cursos.php';
        
        try {
            $curso = getCursoById($conn, $id_test);
            if ($curso) {
                echo "<span style='color:green'>✓ Función getCursoById funciona correctamente</span><br>";
                echo "Curso: " . htmlspecialchars($curso['nombre_curso']) . "<br>";
            } else {
                echo "<span style='color:red'>✗ La función retornó NULL</span><br>";
            }
        } catch (Exception $e) {
            echo "<span style='color:red'>✗ Error: " . $e->getMessage() . "</span><br>";
        }
    } else {
        echo "<span style='color:orange'>⚠ No hay cursos en la BD para probar</span><br>";
    }
    
} else {
    echo "<span style='color:orange'>⚠ No se puede probar (sin conexión)</span><br>";
}

echo "<hr>";

// Resumen
echo "<h2>RESUMEN Y SOLUCIÓN</h2>";

echo "<div style='background:#fff3cd; padding:15px; border-left:4px solid #ffc107;'>";
echo "<h3>Si ves errores arriba:</h3>";
echo "<ol>";
echo "<li>Anota las <strong>credenciales correctas</strong> que funcionaron</li>";
echo "<li>Verifica que el archivo <code>config.php</code> del CRM tenga esas credenciales</li>";
echo "<li>Si el campo <code>mes_accion</code> no existe, ejecuta <code>agregar_mes_accion.sql</code></li>";
echo "<li>Si las tablas no existen, revisa la instalación del módulo</li>";
echo "</ol>";
echo "</div>";

echo "<div style='background:#cce5ff; padding:15px; border-left:4px solid #007bff; margin-top:15px;'>";
echo "<h3>Próximo paso:</h3>";
echo "<p>Comparte la salida de este diagnóstico para ayudarte a solucionar el problema específico.</p>";
echo "</div>";
?>
