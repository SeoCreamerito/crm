<?php
/**
 * Editar Curso - Módulo FUNDAE
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos']);

$id_curso = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id_curso) {
    header('Location: listado.php?error=no_id');
    exit;
}

// Obtener datos del curso
$curso = getCursoById($conn, $id_curso);

if (!$curso) {
    header('Location: listado.php?error=not_found');
    exit;
}

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->begin_transaction();
        
        // Actualizar curso
        $sql = "
            UPDATE cursos SET
                id_teleoperadora = ?,
                id_fundae = ?,
                codigo_curso = ?,
                numero_curso_anual = ?,
                nombre_curso = ?,
                horas_curso = ?,
                fecha_inicio = ?,
                fecha_fin = ?,
                notificacion_inicio = ?,
                notificacion_fin = ?,
                fecha_notif_inicio = ?,
                fecha_notif_fin = ?,
                credito_formacion = ?,
                cofinanciacion = ?,
                id_regalo = ?,
                fecha_envio_tarjeta = ?,
                fecha_envio_regalo = ?,
                envio_claves = ?,
                fecha_envio_claves = ?,
                claves_no_oficial_fecha = ?,
                comentario = ?,
                estado = ?,
                actualizado_en = NOW()
            WHERE id = ?
        ";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            'isisssissssddiisssisssi',
            $_POST['id_teleoperadora'],
            $_POST['id_fundae'],
            $_POST['codigo_curso'],
            $_POST['numero_curso_anual'],
            $_POST['nombre_curso'],
            $_POST['horas_curso'],
            $_POST['fecha_inicio'],
            $_POST['fecha_fin'],
            $_POST['notificacion_inicio'],
            $_POST['notificacion_fin'],
            $_POST['fecha_notif_inicio'],
            $_POST['fecha_notif_fin'],
            $_POST['credito_formacion'],
            $_POST['cofinanciacion'],
            $_POST['id_regalo'],
            $_POST['fecha_envio_tarjeta'],
            $_POST['fecha_envio_regalo'],
            $_POST['envio_claves'],
            $_POST['fecha_envio_claves'],
            $_POST['claves_no_oficial_fecha'],
            $_POST['comentario'],
            $_POST['estado'],
            $id_curso
        );
        
        $stmt->execute();
        
        // Registrar en historial
        $cambios = [];
        if ($curso['estado'] != $_POST['estado']) {
            $cambios[] = "Estado: {$curso['estado']} → {$_POST['estado']}";
        }
        if ($curso['credito_formacion'] != $_POST['credito_formacion']) {
            $cambios[] = "Crédito: {$curso['credito_formacion']} → {$_POST['credito_formacion']}";
        }
        
        $observaciones = !empty($cambios) ? implode(', ', $cambios) : 'Datos actualizados';
        registrarHistorial($conn, $id_curso, $_SESSION['user_id'], 'Modificación', $observaciones);
        
        $conn->commit();
        
        header('Location: ver.php?id=' . $id_curso . '&success=updated');
        exit;
        
    } catch (Exception $e) {
        $conn->rollback();
        $error = $e->getMessage();
    }
}

// Obtener datos para formulario
$teleoperadoras = getTeleoperadoras($conn);
$regalos = getRegalos($conn);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Curso - FUNDAE</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/cursos.css">
</head>
<body>

<div class="wrapper">
    <?php include 'sidebar.php'; ?>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-edit me-2"></i>Editar Curso #<?php echo $curso['id']; ?>
                </span>
                
                <div class="ms-auto">
                    <a href="ver.php?id=<?php echo $curso['id']; ?>" class="btn btn-outline-secondary btn-sm btn-custom">
                        <i class="fas fa-arrow-left me-1"></i>Cancelar
                    </a>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <!-- Info del curso -->
            <div class="alert alert-info mb-4">
                <strong><i class="fas fa-info-circle me-2"></i>Editando curso:</strong> 
                <?php echo htmlspecialchars($curso['nombre_curso']); ?> - 
                <?php echo htmlspecialchars($curso['empresa']); ?> - 
                <?php echo htmlspecialchars($curso['alumno']); ?>
            </div>

            <form method="POST">
                
                <!-- Sección: Información del Curso -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-book me-2"></i>Información del Curso</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-12">
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Nota:</strong> La empresa y el alumno no se pueden cambiar desde aquí. 
                                    Para modificarlos, crea un nuevo curso.
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Nombre del Curso <span class="text-danger">*</span></label>
                                <input type="text" name="nombre_curso" class="form-control" required
                                       value="<?php echo htmlspecialchars($curso['nombre_curso']); ?>">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Código del Curso</label>
                                <input type="text" name="codigo_curso" class="form-control"
                                       value="<?php echo htmlspecialchars($curso['codigo_curso'] ?? ''); ?>">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Horas</label>
                                <input type="number" name="horas_curso" class="form-control" min="1"
                                       value="<?php echo $curso['horas_curso']; ?>">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Número Curso Anual</label>
                                <input type="number" name="numero_curso_anual" class="form-control"
                                       value="<?php echo $curso['numero_curso_anual'] ?? ''; ?>">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Fecha de Inicio <span class="text-danger">*</span></label>
                                <input type="date" name="fecha_inicio" class="form-control" required
                                       value="<?php echo $curso['fecha_inicio']; ?>">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Fecha de Fin</label>
                                <input type="date" name="fecha_fin" class="form-control"
                                       value="<?php echo $curso['fecha_fin'] ?? ''; ?>">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Estado</label>
                                <select name="estado" class="form-select">
                                    <option value="Pendiente" <?php echo $curso['estado'] == 'Pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                                    <option value="En Curso" <?php echo $curso['estado'] == 'En Curso' ? 'selected' : ''; ?>>En Curso</option>
                                    <option value="Finalizado" <?php echo $curso['estado'] == 'Finalizado' ? 'selected' : ''; ?>>Finalizado</option>
                                    <option value="Cancelado" <?php echo $curso['estado'] == 'Cancelado' ? 'selected' : ''; ?>>Cancelado</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección: FUNDAE -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-euro-sign me-2"></i>Información FUNDAE</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">ID FUNDAE</label>
                                <input type="text" name="id_fundae" class="form-control"
                                       value="<?php echo htmlspecialchars($curso['id_fundae'] ?? ''); ?>">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Crédito de Formación (€)</label>
                                <input type="number" name="credito_formacion" class="form-control" step="0.01" min="0"
                                       value="<?php echo $curso['credito_formacion']; ?>">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Cofinanciación (€)</label>
                                <input type="number" name="cofinanciacion" class="form-control" step="0.01" min="0"
                                       value="<?php echo $curso['cofinanciacion']; ?>">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Notificación Inicio</label>
                                <input type="date" name="fecha_notif_inicio" class="form-control"
                                       value="<?php echo $curso['fecha_notif_inicio'] ?? ''; ?>">
                                <div class="form-check mt-2">
                                    <input type="checkbox" name="notificacion_inicio" value="1" class="form-check-input"
                                           <?php echo $curso['notificacion_inicio'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label">Notificación enviada</label>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Notificación Fin</label>
                                <input type="date" name="fecha_notif_fin" class="form-control"
                                       value="<?php echo $curso['fecha_notif_fin'] ?? ''; ?>">
                                <div class="form-check mt-2">
                                    <input type="checkbox" name="notificacion_fin" value="1" class="form-check-input"
                                           <?php echo $curso['notificacion_fin'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label">Notificación enviada</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección: Comercial -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-gift me-2"></i>Información Comercial</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Teleoperadora</label>
                                <select name="id_teleoperadora" class="form-select">
                                    <option value="">Seleccionar...</option>
                                    <?php foreach ($teleoperadoras as $t): ?>
                                    <option value="<?php echo $t['id']; ?>" 
                                            <?php echo $curso['id_teleoperadora'] == $t['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($t['nombre'] . ' ' . ($t['apellidos'] ?? '')); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Regalo</label>
                                <select name="id_regalo" class="form-select">
                                    <option value="">Sin regalo</option>
                                    <?php foreach ($regalos as $r): ?>
                                    <option value="<?php echo $r['id']; ?>"
                                            <?php echo $curso['id_regalo'] == $r['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($r['nombre']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Envío Tarjeta</label>
                                <input type="date" name="fecha_envio_tarjeta" class="form-control"
                                       value="<?php echo $curso['fecha_envio_tarjeta'] ?? ''; ?>">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Envío Regalo</label>
                                <input type="date" name="fecha_envio_regalo" class="form-control"
                                       value="<?php echo $curso['fecha_envio_regalo'] ?? ''; ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección: Moodle -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-key me-2"></i>Acceso Moodle</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Fecha Envío Claves</label>
                                <input type="date" name="fecha_envio_claves" class="form-control"
                                       value="<?php echo $curso['fecha_envio_claves'] ?? ''; ?>">
                                <div class="form-check mt-2">
                                    <input type="checkbox" name="envio_claves" value="1" class="form-check-input"
                                           <?php echo $curso['envio_claves'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label">Claves enviadas</label>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Claves No Oficial</label>
                                <input type="date" name="claves_no_oficial_fecha" class="form-control"
                                       value="<?php echo $curso['claves_no_oficial_fecha'] ?? ''; ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección: Comentarios -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-comment me-2"></i>Observaciones</h5>
                    </div>
                    <div class="card-body">
                        <textarea name="comentario" class="form-control" rows="4" 
                                  placeholder="Comentarios adicionales sobre el curso..."><?php echo htmlspecialchars($curso['comentario'] ?? ''); ?></textarea>
                    </div>
                </div>

                <!-- Botones -->
                <div class="text-end">
                    <a href="ver.php?id=<?php echo $curso['id']; ?>" class="btn btn-secondary btn-custom">
                        <i class="fas fa-times me-1"></i>Cancelar
                    </a>
                    <button type="submit" class="btn btn-gradient-success btn-custom">
                        <i class="fas fa-save me-1"></i>Guardar Cambios
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
});
</script>

</body>
</html>
