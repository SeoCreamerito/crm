<?php
/**
 * Configuración de Moodle - Módulo FUNDAE
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin']);

$mensaje = '';
$tipo_mensaje = '';

// Procesar guardado de configuración
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_config'])) {
    try {
        // Crear o actualizar configuración en base de datos
        // Asumiendo que existe una tabla de configuración o se guarda en un archivo
        
        $configuracion = [
            'moodle_url' => trim($_POST['moodle_url'] ?? ''),
            'moodle_token' => trim($_POST['moodle_token'] ?? ''),
            'moodle_ws_path' => trim($_POST['moodle_ws_path'] ?? '/webservice/rest/server.php'),
            'moodle_categoria_default' => (int)($_POST['moodle_categoria_default'] ?? 0),
            'moodle_rol_estudiante' => (int)($_POST['moodle_rol_estudiante'] ?? 5),
            'moodle_formato_curso' => trim($_POST['moodle_formato_curso'] ?? 'topics'),
            'moodle_auto_sincronizar' => isset($_POST['moodle_auto_sincronizar']) ? 1 : 0,
            'moodle_enviar_email' => isset($_POST['moodle_enviar_email']) ? 1 : 0,
            'moodle_password_temporal' => isset($_POST['moodle_password_temporal']) ? 1 : 0,
            'moodle_longitud_password' => (int)($_POST['moodle_longitud_password'] ?? 12),
            'moodle_timeout' => (int)($_POST['moodle_timeout'] ?? 30),
            'moodle_verificar_ssl' => isset($_POST['moodle_verificar_ssl']) ? 1 : 0,
        ];
        
        // Guardar en tabla de configuración (si existe) o en archivo
        // Por ahora, guardamos en una tabla de configuración
        $sql = "INSERT INTO configuracion_moodle (
                    moodle_url, moodle_token, moodle_ws_path, moodle_categoria_default,
                    moodle_rol_estudiante, moodle_formato_curso, moodle_auto_sincronizar,
                    moodle_enviar_email, moodle_password_temporal, moodle_longitud_password,
                    moodle_timeout, moodle_verificar_ssl, actualizado_en, actualizado_por
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
                ON DUPLICATE KEY UPDATE
                    moodle_url = VALUES(moodle_url),
                    moodle_token = VALUES(moodle_token),
                    moodle_ws_path = VALUES(moodle_ws_path),
                    moodle_categoria_default = VALUES(moodle_categoria_default),
                    moodle_rol_estudiante = VALUES(moodle_rol_estudiante),
                    moodle_formato_curso = VALUES(moodle_formato_curso),
                    moodle_auto_sincronizar = VALUES(moodle_auto_sincronizar),
                    moodle_enviar_email = VALUES(moodle_enviar_email),
                    moodle_password_temporal = VALUES(moodle_password_temporal),
                    moodle_longitud_password = VALUES(moodle_longitud_password),
                    moodle_timeout = VALUES(moodle_timeout),
                    moodle_verificar_ssl = VALUES(moodle_verificar_ssl),
                    actualizado_en = NOW(),
                    actualizado_por = VALUES(actualizado_por)";
        
        $stmt = $conn->prepare($sql);
        $id_usuario = $_SESSION['user_id'];
        
        $stmt->bind_param('sssiisiiiiiii',
            $configuracion['moodle_url'],
            $configuracion['moodle_token'],
            $configuracion['moodle_ws_path'],
            $configuracion['moodle_categoria_default'],
            $configuracion['moodle_rol_estudiante'],
            $configuracion['moodle_formato_curso'],
            $configuracion['moodle_auto_sincronizar'],
            $configuracion['moodle_enviar_email'],
            $configuracion['moodle_password_temporal'],
            $configuracion['moodle_longitud_password'],
            $configuracion['moodle_timeout'],
            $configuracion['moodle_verificar_ssl'],
            $id_usuario
        );
        
        if ($stmt->execute()) {
            $mensaje = "Configuración guardada correctamente";
            $tipo_mensaje = "success";
        } else {
            throw new Exception("Error al guardar: " . $stmt->error);
        }
    } catch (Exception $e) {
        // Si la tabla no existe, intentar crear configuración alternativa
        // o guardar en archivo de configuración
        $mensaje = "Error: " . $e->getMessage() . ". Se intentará guardar en archivo de configuración.";
        $tipo_mensaje = "warning";
        
        // Guardar en archivo de configuración como alternativa
        $config_file = __DIR__ . '/../includes/moodle_config.php';
        $config_content = "<?php\n";
        $config_content .= "// Configuración de Moodle - Generado automáticamente\n";
        $config_content .= "define('MOODLE_URL', '" . addslashes($configuracion['moodle_url']) . "');\n";
        $config_content .= "define('MOODLE_TOKEN', '" . addslashes($configuracion['moodle_token']) . "');\n";
        $config_content .= "define('MOODLE_WS_PATH', '" . addslashes($configuracion['moodle_ws_path']) . "');\n";
        $config_content .= "define('MOODLE_CATEGORIA_DEFAULT', " . $configuracion['moodle_categoria_default'] . ");\n";
        $config_content .= "define('MOODLE_ROL_ESTUDIANTE', " . $configuracion['moodle_rol_estudiante'] . ");\n";
        $config_content .= "define('MOODLE_FORMATO_CURSO', '" . addslashes($configuracion['moodle_formato_curso']) . "');\n";
        $config_content .= "define('MOODLE_AUTO_SINCRONIZAR', " . ($configuracion['moodle_auto_sincronizar'] ? 'true' : 'false') . ");\n";
        $config_content .= "define('MOODLE_ENVIAR_EMAIL', " . ($configuracion['moodle_enviar_email'] ? 'true' : 'false') . ");\n";
        $config_content .= "define('MOODLE_PASSWORD_TEMPORAL', " . ($configuracion['moodle_password_temporal'] ? 'true' : 'false') . ");\n";
        $config_content .= "define('MOODLE_LONGITUD_PASSWORD', " . $configuracion['moodle_longitud_password'] . ");\n";
        $config_content .= "define('MOODLE_TIMEOUT', " . $configuracion['moodle_timeout'] . ");\n";
        $config_content .= "define('MOODLE_VERIFICAR_SSL', " . ($configuracion['moodle_verificar_ssl'] ? 'true' : 'false') . ");\n";
        
        if (file_put_contents($config_file, $config_content)) {
            $mensaje = "Configuración guardada en archivo correctamente";
            $tipo_mensaje = "success";
        }
    }
}

// Probar conexión
$test_result = null;
if (isset($_POST['test_connection'])) {
    $moodle_url = trim($_POST['moodle_url'] ?? '');
    $moodle_token = trim($_POST['moodle_token'] ?? '');
    $moodle_ws_path = trim($_POST['moodle_ws_path'] ?? '/webservice/rest/server.php');
    
    if ($moodle_url && $moodle_token) {
        $test_url = rtrim($moodle_url, '/') . $moodle_ws_path . '?wstoken=' . $moodle_token . '&wsfunction=core_webservice_get_site_info&moodlewsrestformat=json';
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $test_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);
        
        if ($http_code == 200 && $response) {
            $data = json_decode($response, true);
            if (isset($data['sitename'])) {
                $test_result = [
                    'success' => true,
                    'message' => 'Conexión exitosa',
                    'sitename' => $data['sitename'],
                    'version' => $data['version'] ?? 'N/A',
                    'url' => $data['url'] ?? $moodle_url
                ];
            } else {
                $test_result = [
                    'success' => false,
                    'message' => 'Error en la respuesta: ' . $response
                ];
            }
        } else {
            $test_result = [
                'success' => false,
                'message' => 'Error HTTP ' . $http_code . ($curl_error ? ': ' . $curl_error : '')
            ];
        }
    } else {
        $test_result = [
            'success' => false,
            'message' => 'URL y Token son requeridos para probar la conexión'
        ];
    }
}

// Cargar configuración existente
$config = [
    'moodle_url' => '',
    'moodle_token' => '',
    'moodle_ws_path' => '/webservice/rest/server.php',
    'moodle_categoria_default' => 0,
    'moodle_rol_estudiante' => 5,
    'moodle_formato_curso' => 'topics',
    'moodle_auto_sincronizar' => 0,
    'moodle_enviar_email' => 1,
    'moodle_password_temporal' => 1,
    'moodle_longitud_password' => 12,
    'moodle_timeout' => 30,
    'moodle_verificar_ssl' => 0,
];

// Intentar cargar desde base de datos
try {
    $sql = "SELECT * FROM configuracion_moodle LIMIT 1";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $config = array_merge($config, $result->fetch_assoc());
    }
} catch (Exception $e) {
    // Si no existe la tabla, intentar cargar desde archivo
    $config_file = __DIR__ . '/../includes/moodle_config.php';
    if (file_exists($config_file)) {
        require_once $config_file;
        $config['moodle_url'] = defined('MOODLE_URL') ? MOODLE_URL : '';
        $config['moodle_token'] = defined('MOODLE_TOKEN') ? MOODLE_TOKEN : '';
        $config['moodle_ws_path'] = defined('MOODLE_WS_PATH') ? MOODLE_WS_PATH : '/webservice/rest/server.php';
        $config['moodle_categoria_default'] = defined('MOODLE_CATEGORIA_DEFAULT') ? MOODLE_CATEGORIA_DEFAULT : 0;
        $config['moodle_rol_estudiante'] = defined('MOODLE_ROL_ESTUDIANTE') ? MOODLE_ROL_ESTUDIANTE : 5;
        $config['moodle_formato_curso'] = defined('MOODLE_FORMATO_CURSO') ? MOODLE_FORMATO_CURSO : 'topics';
        $config['moodle_auto_sincronizar'] = defined('MOODLE_AUTO_SINCRONIZAR') ? (MOODLE_AUTO_SINCRONIZAR ? 1 : 0) : 0;
        $config['moodle_enviar_email'] = defined('MOODLE_ENVIAR_EMAIL') ? (MOODLE_ENVIAR_EMAIL ? 1 : 0) : 1;
        $config['moodle_password_temporal'] = defined('MOODLE_PASSWORD_TEMPORAL') ? (MOODLE_PASSWORD_TEMPORAL ? 1 : 0) : 1;
        $config['moodle_longitud_password'] = defined('MOODLE_LONGITUD_PASSWORD') ? MOODLE_LONGITUD_PASSWORD : 12;
        $config['moodle_timeout'] = defined('MOODLE_TIMEOUT') ? MOODLE_TIMEOUT : 30;
        $config['moodle_verificar_ssl'] = defined('MOODLE_VERIFICAR_SSL') ? (MOODLE_VERIFICAR_SSL ? 1 : 0) : 0;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración Moodle - FUNDAE</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/cursos.css">
</head>
<body>

<div class="wrapper">
    <?php include 'sidebar.php'; ?>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-cog me-2"></i>Configuración de Moodle
                </span>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <?php if ($mensaje): ?>
            <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show">
                <?php echo htmlspecialchars($mensaje); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <?php if ($test_result): ?>
            <div class="alert alert-<?php echo $test_result['success'] ? 'success' : 'danger'; ?> alert-dismissible fade show">
                <h5><i class="fas fa-<?php echo $test_result['success'] ? 'check-circle' : 'exclamation-triangle'; ?> me-2"></i>
                    <?php echo $test_result['success'] ? 'Conexión Exitosa' : 'Error de Conexión'; ?>
                </h5>
                <p class="mb-0"><?php echo htmlspecialchars($test_result['message']); ?></p>
                <?php if ($test_result['success'] && isset($test_result['sitename'])): ?>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <strong>Nombre del sitio:</strong> <?php echo htmlspecialchars($test_result['sitename']); ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Versión:</strong> <?php echo htmlspecialchars($test_result['version']); ?>
                    </div>
                </div>
                <?php endif; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <form method="POST" id="formConfig">
                <!-- Configuración de Conexión -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white border-0 pt-3">
                        <h5 class="mb-0">
                            <i class="fas fa-network-wired me-2"></i>Configuración de Conexión
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label">URL Base de Moodle <span class="text-danger">*</span></label>
                                <input type="url" name="moodle_url" class="form-control" 
                                       value="<?php echo htmlspecialchars($config['moodle_url']); ?>" 
                                       placeholder="https://moodle.ejemplo.com" required>
                                <small class="text-muted">URL completa de tu instalación de Moodle (sin barra final)</small>
                            </div>
                            
                            <div class="col-md-4">
                                <label class="form-label">Ruta Web Service</label>
                                <input type="text" name="moodle_ws_path" class="form-control" 
                                       value="<?php echo htmlspecialchars($config['moodle_ws_path']); ?>" 
                                       placeholder="/webservice/rest/server.php">
                                <small class="text-muted">Ruta del endpoint de Web Services</small>
                            </div>
                            
                            <div class="col-md-12">
                                <label class="form-label">Token de Web Service <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input type="password" name="moodle_token" id="moodle_token" class="form-control" 
                                           value="<?php echo htmlspecialchars($config['moodle_token']); ?>" 
                                           placeholder="Token generado en Moodle" required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
                                        <i class="fas fa-eye" id="toggleIcon"></i>
                                    </button>
                                </div>
                                <small class="text-muted">
                                    Token generado en: <strong>Administración > Plugins > Servicios web > Gestionar tokens</strong>
                                </small>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Timeout (segundos)</label>
                                <input type="number" name="moodle_timeout" class="form-control" 
                                       value="<?php echo $config['moodle_timeout']; ?>" min="5" max="300">
                                <small class="text-muted">Tiempo máximo de espera para las peticiones</small>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-check mt-4">
                                    <input class="form-check-input" type="checkbox" name="moodle_verificar_ssl" 
                                           id="moodle_verificar_ssl" value="1" 
                                           <?php echo $config['moodle_verificar_ssl'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="moodle_verificar_ssl">
                                        Verificar certificado SSL
                                    </label>
                                </div>
                            </div>
                            
                            <div class="col-12">
                                <button type="submit" name="test_connection" class="btn btn-info btn-custom">
                                    <i class="fas fa-plug me-1"></i>Probar Conexión
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Configuración de Cursos -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white border-0 pt-3">
                        <h5 class="mb-0">
                            <i class="fas fa-book me-2"></i>Configuración de Cursos
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Categoría por Defecto</label>
                                <input type="number" name="moodle_categoria_default" class="form-control" 
                                       value="<?php echo $config['moodle_categoria_default']; ?>" min="0">
                                <small class="text-muted">ID de la categoría donde se crearán los cursos por defecto</small>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Rol de Estudiante</label>
                                <input type="number" name="moodle_rol_estudiante" class="form-control" 
                                       value="<?php echo $config['moodle_rol_estudiante']; ?>" min="1">
                                <small class="text-muted">ID del rol de estudiante (normalmente 5)</small>
                            </div>
                            
                            <div class="col-md-12">
                                <label class="form-label">Formato de Curso</label>
                                <select name="moodle_formato_curso" class="form-select">
                                    <option value="topics" <?php echo $config['moodle_formato_curso'] === 'topics' ? 'selected' : ''; ?>>Temas</option>
                                    <option value="weeks" <?php echo $config['moodle_formato_curso'] === 'weeks' ? 'selected' : ''; ?>>Semanas</option>
                                    <option value="social" <?php echo $config['moodle_formato_curso'] === 'social' ? 'selected' : ''; ?>>Social</option>
                                    <option value="singleactivity" <?php echo $config['moodle_formato_curso'] === 'singleactivity' ? 'selected' : ''; ?>>Actividad única</option>
                                </select>
                                <small class="text-muted">Formato que se usará al crear nuevos cursos</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Configuración de Usuarios -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white border-0 pt-3">
                        <h5 class="mb-0">
                            <i class="fas fa-users me-2"></i>Configuración de Usuarios
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Longitud de Contraseña Temporal</label>
                                <input type="number" name="moodle_longitud_password" class="form-control" 
                                       value="<?php echo $config['moodle_longitud_password']; ?>" min="8" max="32">
                                <small class="text-muted">Longitud de las contraseñas generadas automáticamente</small>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-check mt-4">
                                    <input class="form-check-input" type="checkbox" name="moodle_password_temporal" 
                                           id="moodle_password_temporal" value="1" 
                                           <?php echo $config['moodle_password_temporal'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="moodle_password_temporal">
                                        Generar contraseña temporal automáticamente
                                    </label>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="moodle_enviar_email" 
                                           id="moodle_enviar_email" value="1" 
                                           <?php echo $config['moodle_enviar_email'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="moodle_enviar_email">
                                        Enviar email con credenciales al crear usuario
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Configuración Avanzada -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white border-0 pt-3">
                        <h5 class="mb-0">
                            <i class="fas fa-sliders-h me-2"></i>Configuración Avanzada
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-12">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="moodle_auto_sincronizar" 
                                           id="moodle_auto_sincronizar" value="1" 
                                           <?php echo $config['moodle_auto_sincronizar'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="moodle_auto_sincronizar">
                                        Sincronización automática con Moodle
                                    </label>
                                    <small class="text-muted d-block">Sincronizar automáticamente el catálogo de cursos con Moodle</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Botones de Acción -->
                <div class="card table-custom">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <a href="index.php" class="btn btn-secondary btn-custom">
                                <i class="fas fa-arrow-left me-1"></i>Cancelar
                            </a>
                            <div>
                                <button type="submit" name="guardar_config" class="btn btn-gradient-success btn-custom">
                                    <i class="fas fa-save me-1"></i>Guardar Configuración
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

            <!-- Información de Ayuda -->
            <div class="card table-custom mt-4">
                <div class="card-header bg-white border-0 pt-3">
                    <h5 class="mb-0">
                        <i class="fas fa-question-circle me-2"></i>Ayuda
                    </h5>
                </div>
                <div class="card-body">
                    <div class="accordion" id="accordionAyuda">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse1">
                                    <i class="fas fa-key me-2"></i>¿Cómo obtener el Token de Web Service?
                                </button>
                            </h2>
                            <div id="collapse1" class="accordion-collapse collapse show" data-bs-parent="#accordionAyuda">
                                <div class="accordion-body">
                                    <ol>
                                        <li>Accede a tu instalación de Moodle como administrador</li>
                                        <li>Ve a <strong>Administración del sitio > Plugins > Servicios web > Gestionar tokens</strong></li>
                                        <li>Haz clic en "Crear token"</li>
                                        <li>Selecciona un usuario (recomendado: crear un usuario específico para la API)</li>
                                        <li>Selecciona el servicio "Servicios web REST"</li>
                                        <li>Haz clic en "Guardar cambios"</li>
                                        <li>Copia el token generado y pégalo en el campo "Token de Web Service"</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse2">
                                    <i class="fas fa-cog me-2"></i>Habilitar Web Services en Moodle
                                </button>
                            </h2>
                            <div id="collapse2" class="accordion-collapse collapse" data-bs-parent="#accordionAyuda">
                                <div class="accordion-body">
                                    <ol>
                                        <li>Ve a <strong>Administración del sitio > Avanzado > Características</strong></li>
                                        <li>Habilita "Habilitar servicios web"</li>
                                        <li>Ve a <strong>Administración del sitio > Plugins > Servicios web > Servicios externos</strong></li>
                                        <li>Habilita "Servicios web REST"</li>
                                        <li>Ve a <strong>Administración del sitio > Plugins > Servicios web > Gestionar protocolos</strong></li>
                                        <li>Habilita "REST protocol"</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse3">
                                    <i class="fas fa-shield-alt me-2"></i>Permisos del Usuario API
                                </button>
                            </h2>
                            <div id="collapse3" class="accordion-collapse collapse" data-bs-parent="#accordionAyuda">
                                <div class="accordion-body">
                                    <p>El usuario utilizado para la API debe tener los siguientes permisos:</p>
                                    <ul>
                                        <li>Crear usuarios</li>
                                        <li>Matricular usuarios en cursos</li>
                                        <li>Crear cursos</li>
                                        <li>Gestionar categorías de cursos</li>
                                    </ul>
                                    <p class="text-muted">Se recomienda crear un usuario específico con rol de "Manager" o personalizado con estos permisos.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
});

function togglePassword() {
    const input = document.getElementById('moodle_token');
    const icon = document.getElementById('toggleIcon');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Validar formulario antes de enviar
document.getElementById('formConfig').addEventListener('submit', function(e) {
    const url = document.querySelector('input[name="moodle_url"]').value;
    const token = document.querySelector('input[name="moodle_token"]').value;
    
    if (!url || !token) {
        e.preventDefault();
        alert('Por favor, completa la URL y el Token de Moodle');
        return false;
    }
    
    // Si es guardar configuración, confirmar
    if (e.submitter && e.submitter.name === 'guardar_config') {
        if (!confirm('¿Estás seguro de guardar esta configuración?')) {
            e.preventDefault();
            return false;
        }
    }
});
</script>

</body>
</html>

