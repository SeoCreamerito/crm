<?php
/**
 * Reportes - Módulo FUNDAE
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos']);

$id_usuario = $_SESSION['user_id'];
$rol = $_SESSION['rol'];

// Filtros de fecha
$fecha_desde = $_GET['fecha_desde'] ?? date('Y-m-01'); // Primer día del mes actual
$fecha_hasta = $_GET['fecha_hasta'] ?? date('Y-m-t'); // Último día del mes actual
$id_teleoperadora = $_GET['id_teleoperadora'] ?? null;

// Si es agent, solo sus cursos
if ($rol === 'agent') {
    $id_teleoperadora = $id_usuario;
}

// Obtener teleoperadoras para filtro
$teleoperadoras = getTeleoperadoras($conn);

// Reporte 1: Resumen General
$sql_resumen = "
    SELECT 
        COUNT(*) as total_cursos,
        SUM(CASE WHEN estado = 'Pendiente' THEN 1 ELSE 0 END) as pendientes,
        SUM(CASE WHEN estado = 'En Curso' THEN 1 ELSE 0 END) as en_curso,
        SUM(CASE WHEN estado = 'Finalizado' THEN 1 ELSE 0 END) as finalizados,
        SUM(CASE WHEN estado = 'Cancelado' THEN 1 ELSE 0 END) as cancelados,
        SUM(credito_formacion) as credito_total,
        SUM(cofinanciacion) as cofinanciacion_total,
        AVG(credito_formacion) as credito_promedio
    FROM cursos
    WHERE fecha_inicio BETWEEN ? AND ?
";
$params_resumen = [$fecha_desde, $fecha_hasta];
$types_resumen = 'ss';

if ($id_teleoperadora) {
    $sql_resumen .= " AND id_teleoperadora = ?";
    $params_resumen[] = $id_teleoperadora;
    $types_resumen .= 'i';
}

$stmt_resumen = $conn->prepare($sql_resumen);
if (!empty($params_resumen)) {
    $stmt_resumen->bind_param($types_resumen, ...$params_resumen);
}
$stmt_resumen->execute();
$resumen = $stmt_resumen->get_result()->fetch_assoc();

// Reporte 2: Cursos por Teleoperadora
$sql_teleop = "
    SELECT 
        u.nombre,
        u.apellidos,
        COUNT(c.id) as total_cursos,
        SUM(c.credito_formacion) as credito_total,
        SUM(CASE WHEN c.estado = 'Finalizado' THEN 1 ELSE 0 END) as finalizados
    FROM usuarios u
    LEFT JOIN cursos c ON u.id = c.id_teleoperadora 
        AND c.fecha_inicio BETWEEN ? AND ?
    WHERE u.rol IN ('agent', 'admin') AND u.activo = 1
    GROUP BY u.id, u.nombre, u.apellidos
    HAVING total_cursos > 0
    ORDER BY total_cursos DESC
";
$stmt_teleop = $conn->prepare($sql_teleop);
$stmt_teleop->bind_param('ss', $fecha_desde, $fecha_hasta);
$stmt_teleop->execute();
$reporte_teleop = $stmt_teleop->get_result()->fetch_all(MYSQLI_ASSOC);

// Reporte 3: Cursos por Empresa
$sql_empresas = "
    SELECT 
        e.denominacion,
        e.cif,
        COUNT(c.id) as total_cursos,
        SUM(c.credito_formacion) as credito_total,
        COUNT(DISTINCT c.id_alumno) as alumnos_unicos
    FROM empresas e
    INNER JOIN cursos c ON e.id = c.id_empresa
    WHERE c.fecha_inicio BETWEEN ? AND ?
";
$params_empresas = [$fecha_desde, $fecha_hasta];
$types_empresas = 'ss';

if ($id_teleoperadora) {
    $sql_empresas .= " AND c.id_teleoperadora = ?";
    $params_empresas[] = $id_teleoperadora;
    $types_empresas .= 'i';
}

$sql_empresas .= " GROUP BY e.id, e.denominacion, e.cif ORDER BY total_cursos DESC LIMIT 20";

$stmt_empresas = $conn->prepare($sql_empresas);
if (!empty($params_empresas)) {
    $stmt_empresas->bind_param($types_empresas, ...$params_empresas);
}
$stmt_empresas->execute();
$reporte_empresas = $stmt_empresas->get_result()->fetch_all(MYSQLI_ASSOC);

// Reporte 4: Cursos por Mes de Acción
$sql_meses = "
    SELECT 
        mes_accion,
        periodo_accion,
        COUNT(*) as total_cursos,
        SUM(credito_formacion) as credito_total,
        SUM(CASE WHEN estado = 'Finalizado' THEN 1 ELSE 0 END) as finalizados,
        SUM(CASE WHEN estado = 'En Curso' THEN 1 ELSE 0 END) as en_curso
    FROM cursos
    WHERE fecha_inicio BETWEEN ? AND ?
";
$params_meses = [$fecha_desde, $fecha_hasta];
$types_meses = 'ss';

if ($id_teleoperadora) {
    $sql_meses .= " AND id_teleoperadora = ?";
    $params_meses[] = $id_teleoperadora;
    $types_meses .= 'i';
}

$sql_meses .= " AND mes_accion IS NOT NULL GROUP BY mes_accion, periodo_accion ORDER BY mes_accion DESC";

$stmt_meses = $conn->prepare($sql_meses);
if (!empty($params_meses)) {
    $stmt_meses->bind_param($types_meses, ...$params_meses);
}
$stmt_meses->execute();
$reporte_meses = $stmt_meses->get_result()->fetch_all(MYSQLI_ASSOC);

// Reporte 5: Estado de Moodle
$sql_moodle = "
    SELECT 
        moodle_estado,
        COUNT(*) as total
    FROM cursos
    WHERE fecha_inicio BETWEEN ? AND ?
";
$params_moodle = [$fecha_desde, $fecha_hasta];
$types_moodle = 'ss';

if ($id_teleoperadora) {
    $sql_moodle .= " AND id_teleoperadora = ?";
    $params_moodle[] = $id_teleoperadora;
    $types_moodle .= 'i';
}

$sql_moodle .= " GROUP BY moodle_estado";

$stmt_moodle = $conn->prepare($sql_moodle);
if (!empty($params_moodle)) {
    $stmt_moodle->bind_param($types_moodle, ...$params_moodle);
}
$stmt_moodle->execute();
$reporte_moodle = $stmt_moodle->get_result()->fetch_all(MYSQLI_ASSOC);

// Reporte 6: Cursos por Catálogo
$sql_catalogo = "
    SELECT 
        cc.nombre as curso_nombre,
        cc.codigo,
        COUNT(c.id) as total_cursos,
        SUM(c.credito_formacion) as credito_total
    FROM catalogo_cursos cc
    INNER JOIN cursos c ON cc.id = c.id_catalogo_curso
    WHERE c.fecha_inicio BETWEEN ? AND ?
";
$params_catalogo = [$fecha_desde, $fecha_hasta];
$types_catalogo = 'ss';

if ($id_teleoperadora) {
    $sql_catalogo .= " AND c.id_teleoperadora = ?";
    $params_catalogo[] = $id_teleoperadora;
    $types_catalogo .= 'i';
}

$sql_catalogo .= " GROUP BY cc.id, cc.nombre, cc.codigo ORDER BY total_cursos DESC LIMIT 20";

$stmt_catalogo = $conn->prepare($sql_catalogo);
if (!empty($params_catalogo)) {
    $stmt_catalogo->bind_param($types_catalogo, ...$params_catalogo);
}
$stmt_catalogo->execute();
$reporte_catalogo = $stmt_catalogo->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes - FUNDAE</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/cursos.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>

<div class="wrapper">
    <?php include 'sidebar.php'; ?>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-chart-bar me-2"></i>Reportes y Análisis
                </span>
                
                <div class="ms-auto">
                    <button onclick="window.print()" class="btn btn-secondary btn-sm btn-custom me-2">
                        <i class="fas fa-print me-1"></i>Imprimir
                    </button>
                    <button onclick="exportarReporte()" class="btn btn-success btn-sm btn-custom">
                        <i class="fas fa-file-excel me-1"></i>Exportar Excel
                    </button>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <!-- Filtros -->
            <div class="filter-card mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Fecha Desde</label>
                        <input type="date" name="fecha_desde" class="form-control" 
                               value="<?php echo htmlspecialchars($fecha_desde); ?>" required>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">Fecha Hasta</label>
                        <input type="date" name="fecha_hasta" class="form-control" 
                               value="<?php echo htmlspecialchars($fecha_hasta); ?>" required>
                    </div>
                    
                    <?php if ($rol !== 'agent'): ?>
                    <div class="col-md-3">
                        <label class="form-label">Teleoperadora</label>
                        <select name="id_teleoperadora" class="form-select">
                            <option value="">Todas</option>
                            <?php foreach ($teleoperadoras as $t): ?>
                            <option value="<?php echo $t['id']; ?>" 
                                    <?php echo ($id_teleoperadora == $t['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($t['nombre'] . ' ' . ($t['apellidos'] ?? '')); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-gradient-primary btn-custom w-100">
                            <i class="fas fa-filter me-1"></i>Filtrar
                        </button>
                    </div>
                </form>
            </div>

            <!-- Resumen General -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Resumen General</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <div class="stat-card card primary">
                                        <div class="card-body text-center">
                                            <div class="stat-number"><?php echo number_format($resumen['total_cursos']); ?></div>
                                            <div class="stat-label">Total Cursos</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="stat-card card success">
                                        <div class="card-body text-center">
                                            <div class="stat-number"><?php echo formatMoneda($resumen['credito_total']); ?></div>
                                            <div class="stat-label">Crédito Total</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="stat-card card info">
                                        <div class="card-body text-center">
                                            <div class="stat-number"><?php echo formatMoneda($resumen['credito_promedio']); ?></div>
                                            <div class="stat-label">Crédito Promedio</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="stat-card card warning">
                                        <div class="card-body text-center">
                                            <div class="stat-number"><?php echo number_format($resumen['finalizados']); ?></div>
                                            <div class="stat-label">Finalizados</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Gráfico de Estados -->
                            <div class="row mt-4">
                                <div class="col-md-6">
                                    <canvas id="chartEstados" height="200"></canvas>
                                </div>
                                <div class="col-md-6">
                                    <canvas id="chartMoodle" height="200"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Reporte por Teleoperadora -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-users me-2"></i>Rendimiento por Teleoperadora</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Teleoperadora</th>
                                            <th class="text-center">Total Cursos</th>
                                            <th class="text-center">Finalizados</th>
                                            <th class="text-end">Crédito Total</th>
                                            <th class="text-end">% Éxito</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($reporte_teleop)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted py-4">
                                                No hay datos para el período seleccionado
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                        <?php foreach ($reporte_teleop as $teleop): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($teleop['nombre'] . ' ' . ($teleop['apellidos'] ?? '')); ?></strong>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-primary"><?php echo $teleop['total_cursos']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-success"><?php echo $teleop['finalizados']; ?></span>
                                            </td>
                                            <td class="text-end">
                                                <strong><?php echo formatMoneda($teleop['credito_total']); ?></strong>
                                            </td>
                                            <td class="text-end">
                                                <?php 
                                                $porcentaje = $teleop['total_cursos'] > 0 
                                                    ? round(($teleop['finalizados'] / $teleop['total_cursos']) * 100, 1) 
                                                    : 0;
                                                $color = $porcentaje >= 80 ? 'success' : ($porcentaje >= 50 ? 'warning' : 'danger');
                                                ?>
                                                <span class="badge bg-<?php echo $color; ?>"><?php echo $porcentaje; ?>%</span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Reporte por Empresa -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-building me-2"></i>Top Empresas</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm table-hover">
                                    <thead>
                                        <tr>
                                            <th>Empresa</th>
                                            <th class="text-center">Cursos</th>
                                            <th class="text-end">Crédito</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($reporte_empresas)): ?>
                                        <tr>
                                            <td colspan="3" class="text-center text-muted py-3">
                                                No hay datos
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                        <?php foreach (array_slice($reporte_empresas, 0, 10) as $empresa): ?>
                                        <tr>
                                            <td>
                                                <small><?php echo htmlspecialchars($empresa['denominacion']); ?></small>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-primary"><?php echo $empresa['total_cursos']; ?></span>
                                            </td>
                                            <td class="text-end">
                                                <small><?php echo formatMoneda($empresa['credito_total']); ?></small>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Reporte por Catálogo -->
                <div class="col-md-6">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-book me-2"></i>Top Cursos</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm table-hover">
                                    <thead>
                                        <tr>
                                            <th>Curso</th>
                                            <th class="text-center">Total</th>
                                            <th class="text-end">Crédito</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($reporte_catalogo)): ?>
                                        <tr>
                                            <td colspan="3" class="text-center text-muted py-3">
                                                No hay datos
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                        <?php foreach (array_slice($reporte_catalogo, 0, 10) as $curso): ?>
                                        <tr>
                                            <td>
                                                <small><?php echo htmlspecialchars($curso['curso_nombre']); ?></small>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-info"><?php echo $curso['total_cursos']; ?></span>
                                            </td>
                                            <td class="text-end">
                                                <small><?php echo formatMoneda($curso['credito_total']); ?></small>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Reporte por Mes de Acción -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-calendar-alt me-2"></i>Cursos por Mes de Acción</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Mes de Acción</th>
                                            <th class="text-center">Total Cursos</th>
                                            <th class="text-center">En Curso</th>
                                            <th class="text-center">Finalizados</th>
                                            <th class="text-end">Crédito Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($reporte_meses)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted py-4">
                                                No hay datos para el período seleccionado
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                        <?php foreach ($reporte_meses as $mes): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($mes['periodo_accion']); ?></strong>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-primary"><?php echo $mes['total_cursos']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <?php if ($mes['en_curso'] > 0): ?>
                                                <span class="badge bg-info"><?php echo $mes['en_curso']; ?></span>
                                                <?php else: ?>
                                                <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if ($mes['finalizados'] > 0): ?>
                                                <span class="badge bg-success"><?php echo $mes['finalizados']; ?></span>
                                                <?php else: ?>
                                                <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-end">
                                                <strong><?php echo formatMoneda($mes['credito_total']); ?></strong>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
});

// Gráfico de Estados
const ctxEstados = document.getElementById('chartEstados').getContext('2d');
const chartEstados = new Chart(ctxEstados, {
    type: 'doughnut',
    data: {
        labels: ['Pendientes', 'En Curso', 'Finalizados', 'Cancelados'],
        datasets: [{
            data: [
                <?php echo $resumen['pendientes']; ?>,
                <?php echo $resumen['en_curso']; ?>,
                <?php echo $resumen['finalizados']; ?>,
                <?php echo $resumen['cancelados']; ?>
            ],
            backgroundColor: [
                '#ffc107',
                '#0d6efd',
                '#198754',
                '#dc3545'
            ],
            borderWidth: 2,
            borderColor: '#fff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom'
            },
            title: {
                display: true,
                text: 'Distribución por Estado'
            }
        }
    }
});

// Gráfico de Moodle
const ctxMoodle = document.getElementById('chartMoodle').getContext('2d');
const chartMoodle = new Chart(ctxMoodle, {
    type: 'bar',
    data: {
        labels: [
            <?php 
            $labels = [];
            $data = [];
            foreach ($reporte_moodle as $m) {
                $estado = $m['moodle_estado'] ?? 'pendiente';
                $labels[] = "'" . ucfirst($estado) . "'";
                $data[] = $m['total'];
            }
            echo implode(',', $labels);
            ?>
        ],
        datasets: [{
            label: 'Cursos',
            data: [<?php echo implode(',', array_column($reporte_moodle, 'total')); ?>],
            backgroundColor: [
                '#0d6efd',
                '#198754',
                '#ffc107',
                '#dc3545'
            ],
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: false
            },
            title: {
                display: true,
                text: 'Estado en Moodle'
            }
        },
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

function exportarReporte() {
    const params = new URLSearchParams(window.location.search);
    window.location.href = 'exportar_reporte.php?' + params.toString();
}
</script>

</body>
</html>

