<?php
/**
 * Dashboard - Módulo de Cursos FUNDAE
 */

// Activar errores para debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    require_once __DIR__ . '/../includes/config_cursos.php';
    require_once __DIR__ . '/../includes/functions_cursos.php';

    verificarRolCursos(['admin', 'gestion_cursos']);
} catch (Exception $e) {
    die("ERROR al cargar el módulo: " . $e->getMessage() . "<br><br>" .
        "Archivo: " . $e->getFile() . "<br>" .
        "Línea: " . $e->getLine());
}

$id_usuario = $_SESSION['user_id'];
$rol = $_SESSION['rol'];
$nombre_usuario = getNombreUsuarioActual();

// Si es teleoperadora (agent), solo ver sus cursos
$filtro_teleoperadora = ($rol === 'agent') ? $id_usuario : null;

// Obtener estadísticas
$stats = getEstadisticasDashboard($conn, $filtro_teleoperadora);
$teleoperadoras = getTeleoperadoras($conn);

// Título de la página
$page_title = "Dashboard - Cursos FUNDAE";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <!-- CSS Personalizado -->
    <link rel="stylesheet" href="../assets/css/cursos.css">
</head>
<body>

<div class="wrapper">
    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Page Content -->
    <div id="content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-chart-line me-2"></i>Dashboard de Cursos FUNDAE
                </span>
                
                <div class="ms-auto d-flex align-items-center">
                    <span class="me-3">
                        <i class="fas fa-user-circle me-1"></i>
                        <?php echo htmlspecialchars($nombre_usuario); ?>
                    </span>
                    <a href="<?php echo CRM_LOGOUT_URL; ?>" class="btn btn-outline-danger btn-sm">
                        <i class="fas fa-sign-out-alt me-1"></i>Salir
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <div class="container-fluid p-4">
            
            <!-- Estadísticas Principales -->
            <div class="row mb-4">
                <div class="col-xl-3 col-md-6 mb-3">
                    <div class="stat-card card primary">
                        <div class="card-body">
                            <div class="stat-icon">
                                <i class="fas fa-book"></i>
                            </div>
                            <div class="stat-number"><?php echo number_format($stats['total_cursos']); ?></div>
                            <div class="stat-label">Total Cursos</div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-3">
                    <div class="stat-card card success">
                        <div class="card-body">
                            <div class="stat-icon">
                                <i class="fas fa-euro-sign"></i>
                            </div>
                            <div class="stat-number"><?php echo number_format($stats['credito_total'], 0); ?>€</div>
                            <div class="stat-label">Crédito FUNDAE Total</div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-3">
                    <div class="stat-card card warning">
                        <div class="card-body">
                            <div class="stat-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['en_curso']; ?></div>
                            <div class="stat-label">En Curso</div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6 mb-3">
                    <div class="stat-card card info">
                        <div class="card-body">
                            <div class="stat-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['finalizados']; ?></div>
                            <div class="stat-label">Finalizados</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Gráficos y Alertas -->
            <div class="row mb-4">
                <!-- Gráfico de Estados -->
                <div class="col-lg-8 mb-4">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Distribución de Cursos por Estado</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="chartEstados" height="80"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- Alertas y Pendientes -->
                <div class="col-lg-4 mb-4">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-bell me-2"></i>Tareas Pendientes</h5>
                        </div>
                        <div class="card-body">
                            <div class="list-group list-group-flush">
                                <?php if ($stats['claves_pendientes'] > 0): ?>
                                <a href="listado.php?filter=claves_pendientes" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                    <span>
                                        <i class="fas fa-key text-warning me-2"></i>
                                        Claves por enviar
                                    </span>
                                    <span class="badge bg-warning rounded-pill"><?php echo $stats['claves_pendientes']; ?></span>
                                </a>
                                <?php endif; ?>
                                
                                <?php if ($stats['regalos_pendientes'] > 0): ?>
                                <a href="listado.php?filter=regalos_pendientes" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                    <span>
                                        <i class="fas fa-gift text-info me-2"></i>
                                        Regalos pendientes
                                    </span>
                                    <span class="badge bg-info rounded-pill"><?php echo $stats['regalos_pendientes']; ?></span>
                                </a>
                                <?php endif; ?>
                                
                                <?php if ($stats['notificaciones_pendientes'] > 0): ?>
                                <a href="listado.php?filter=notificaciones_pendientes" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                    <span>
                                        <i class="fas fa-exclamation-triangle text-danger me-2"></i>
                                        Notificaciones FUNDAE
                                    </span>
                                    <span class="badge bg-danger rounded-pill"><?php echo $stats['notificaciones_pendientes']; ?></span>
                                </a>
                                <?php endif; ?>
                                
                                <?php if ($stats['pendientes'] > 0): ?>
                                <a href="listado.php?estado=Pendiente" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                    <span>
                                        <i class="fas fa-hourglass-half text-secondary me-2"></i>
                                        Cursos pendientes inicio
                                    </span>
                                    <span class="badge bg-secondary rounded-pill"><?php echo $stats['pendientes']; ?></span>
                                </a>
                                <?php endif; ?>
                                
                                <?php if ($stats['claves_pendientes'] == 0 && $stats['regalos_pendientes'] == 0 && $stats['notificaciones_pendientes'] == 0): ?>
                                <div class="alert alert-success mb-0">
                                    <i class="fas fa-check-circle me-2"></i>
                                    ¡No hay tareas pendientes!
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($rol === 'admin'): ?>
            <!-- Estadísticas por Teleoperadora (solo admin) -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-users me-2"></i>Rendimiento por Teleoperadora</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="chartTeleoperadoras" height="60"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Resumen por Mes de Acción -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-calendar-alt me-2"></i>Cursos por Mes de Acción Formativa</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Mes de Acción</th>
                                            <th class="text-center">Total Cursos</th>
                                            <th class="text-end">Crédito FUNDAE</th>
                                            <th class="text-center">Pendientes</th>
                                            <th class="text-center">En Curso</th>
                                            <th class="text-center">Finalizados</th>
                                            <th class="text-center">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // Obtener resumen por mes
                                        $sql_meses = "
                                            SELECT 
                                                mes_accion,
                                                periodo_accion,
                                                COUNT(*) as total_cursos,
                                                SUM(credito_formacion) as credito_total,
                                                SUM(CASE WHEN estado = 'Pendiente' THEN 1 ELSE 0 END) as pendientes,
                                                SUM(CASE WHEN estado = 'En Curso' THEN 1 ELSE 0 END) as en_curso,
                                                SUM(CASE WHEN estado = 'Finalizado' THEN 1 ELSE 0 END) as finalizados
                                            FROM cursos
                                            WHERE mes_accion IS NOT NULL
                                            GROUP BY mes_accion, periodo_accion
                                            ORDER BY mes_accion DESC
                                            LIMIT 12
                                        ";
                                        $result_meses = $conn->query($sql_meses);
                                        
                                        if ($result_meses && $result_meses->num_rows > 0):
                                            while ($mes = $result_meses->fetch_assoc()):
                                        ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($mes['periodo_accion']); ?></strong>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-primary"><?php echo $mes['total_cursos']; ?></span>
                                            </td>
                                            <td class="text-end">
                                                <strong><?php echo formatMoneda($mes['credito_total']); ?></strong>
                                            </td>
                                            <td class="text-center">
                                                <?php if ($mes['pendientes'] > 0): ?>
                                                <span class="badge bg-warning"><?php echo $mes['pendientes']; ?></span>
                                                <?php else: ?>
                                                <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if ($mes['en_curso'] > 0): ?>
                                                <span class="badge bg-info"><?php echo $mes['en_curso']; ?></span>
                                                <?php else: ?>
                                                <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if ($mes['finalizados'] > 0): ?>
                                                <span class="badge bg-success"><?php echo $mes['finalizados']; ?></span>
                                                <?php else: ?>
                                                <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <a href="listado.php?mes_accion=<?php echo urlencode($mes['mes_accion']); ?>" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye me-1"></i>Ver cursos
                                                </a>
                                            </td>
                                        </tr>
                                        <?php 
                                            endwhile;
                                        else:
                                        ?>
                                        <tr>
                                            <td colspan="7" class="text-center text-muted py-4">
                                                No hay datos de meses de acción formativa
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Accesos Rápidos -->
            <div class="row">
                <div class="col-12">
                    <div class="card table-custom">
                        <div class="card-header bg-white border-0 pt-3 pb-0">
                            <h5 class="mb-0"><i class="fas fa-rocket me-2"></i>Accesos Rápidos</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <a href="listado.php" class="btn btn-custom btn-gradient-primary w-100 py-3">
                                        <i class="fas fa-list fa-2x mb-2 d-block"></i>
                                        Ver Todos los Cursos
                                    </a>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <a href="crear.php" class="btn btn-custom btn-gradient-success w-100 py-3">
                                        <i class="fas fa-plus-circle fa-2x mb-2 d-block"></i>
                                        Crear Nuevo Curso
                                    </a>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <a href="empresas.php" class="btn btn-custom btn-outline-primary w-100 py-3">
                                        <i class="fas fa-building fa-2x mb-2 d-block"></i>
                                        Gestionar Empresas
                                    </a>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <a href="alumnos.php" class="btn btn-custom btn-outline-info w-100 py-3">
                                        <i class="fas fa-user-graduate fa-2x mb-2 d-block"></i>
                                        Gestionar Alumnos
                                    </a>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <a href="reportes.php" class="btn btn-custom btn-outline-secondary w-100 py-3">
                                        <i class="fas fa-chart-bar fa-2x mb-2 d-block"></i>
                                        Ver Reportes
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Toggle Sidebar
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
});

// Gráfico de Estados
const ctxEstados = document.getElementById('chartEstados').getContext('2d');
const chartEstados = new Chart(ctxEstados, {
    type: 'doughnut',
    data: {
        labels: ['Pendientes', 'En Curso', 'Finalizados', 'Cancelados'],
        datasets: [{
            data: [
                <?php echo $stats['pendientes']; ?>,
                <?php echo $stats['en_curso']; ?>,
                <?php echo $stats['finalizados']; ?>,
                <?php echo $stats['cancelados']; ?>
            ],
            backgroundColor: [
                '#ffc107',
                '#0d6efd',
                '#198754',
                '#dc3545'
            ],
            borderWidth: 2,
            borderColor: '#fff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 20,
                    font: {
                        size: 12
                    }
                }
            }
        }
    }
});

<?php if ($rol === 'admin'): ?>
// Obtener datos de teleoperadoras via AJAX
fetch('ajax/get_stats_teleoperadoras.php')
    .then(response => response.json())
    .then(data => {
        const ctxTeleop = document.getElementById('chartTeleoperadoras').getContext('2d');
        const chartTeleop = new Chart(ctxTeleop, {
            type: 'bar',
            data: {
                labels: data.nombres,
                datasets: [{
                    label: 'Cursos Vendidos',
                    data: data.cursos,
                    backgroundColor: 'rgba(102, 126, 234, 0.8)',
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 2
                }, {
                    label: 'Crédito FUNDAE (€)',
                    data: data.creditos,
                    backgroundColor: 'rgba(118, 75, 162, 0.8)',
                    borderColor: 'rgba(118, 75, 162, 1)',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        position: 'top'
                    }
                }
            }
        });
    });
<?php endif; ?>
</script>

</body>
</html>
