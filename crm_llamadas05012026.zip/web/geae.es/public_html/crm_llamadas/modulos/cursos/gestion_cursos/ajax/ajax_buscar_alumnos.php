<?php
/**
 * AJAX: Buscar Alumnos
 * Para Select2 con búsqueda en tiempo real
 */

require_once __DIR__ . '/../../includes/config_cursos.php';
require_once __DIR__ . '/../../includes/functions_cursos.php';

// Verificar sesión
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Obtener parámetros
$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

$results = [];
$total_count = 0;

if (strlen($search) >= 2) {
    // Preparar búsqueda (DNI, nombre o email)
    $search_param = '%' . $search . '%';
    
    // Contar total (incluir activo = 1, NULL o 0)
    $sql_count = "SELECT COUNT(*) as total 
                  FROM alumnos 
                  WHERE (activo = 1 OR activo IS NULL)
                  AND (dni LIKE ? OR nombre LIKE ? OR email LIKE ?)";
    
    $stmt_count = $conn->prepare($sql_count);
    $stmt_count->bind_param('sss', $search_param, $search_param, $search_param);
    $stmt_count->execute();
    $result_count = $stmt_count->get_result()->fetch_assoc();
    $total_count = $result_count['total'];
    
    // Obtener resultados paginados
    $sql = "SELECT id, nombre, dni, email, telefono_1, fecha_nacimiento, activo
            FROM alumnos 
            WHERE (activo = 1 OR activo IS NULL)
            AND (dni LIKE ? OR nombre LIKE ? OR email LIKE ?)
            ORDER BY 
                CASE 
                    WHEN dni LIKE ? THEN 1
                    WHEN nombre LIKE ? THEN 2
                    WHEN email LIKE ? THEN 3
                    ELSE 4
                END,
                nombre ASC
            LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($sql);
    $search_start = $search . '%';
    $stmt->bind_param('ssssssii', $search_param, $search_param, $search_param, 
                      $search_start, $search_start, $search_start, 
                      $per_page, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        // Formatear texto del resultado
        $text = $row['nombre'] . ' - ' . $row['dni'];
        if ($row['email']) {
            $text .= ' (' . $row['email'] . ')';
        }
        
        $results[] = [
            'id' => $row['id'],
            'text' => $text,
            'nombre' => $row['nombre'],
            'dni' => $row['dni'],
            'email' => $row['email'] ?? '',
            'telefono' => $row['telefono_1'] ?? '',
            'fecha_nacimiento' => $row['fecha_nacimiento'] ?? ''
        ];
    }
}

// Preparar respuesta para Select2
$response = [
    'results' => $results,
    'pagination' => [
        'more' => ($offset + $per_page) < $total_count
    ]
];

header('Content-Type: application/json');
echo json_encode($response);
?>
