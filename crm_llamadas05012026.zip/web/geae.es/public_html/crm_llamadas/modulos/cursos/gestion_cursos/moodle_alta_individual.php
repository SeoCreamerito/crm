<?php
/**
 * ALTA INDIVIDUAL EN MOODLE
 * Formulario para dar de alta un curso en Moodle
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos']);

// Cargar MoodleAPI
require_once __DIR__ . '/../../../includes/MoodleAPI.php';

$id_curso = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id_curso) {
    header('Location: listado.php');
    exit;
}

// Obtener datos del curso
$sql = "SELECT c.*, 
        e.denominacion as empresa_nombre,
        e.cif as empresa_cif,
        a.nombre as alumno_nombre_completo,
        a.dni as alumno_dni,
        a.email as alumno_email,
        a.telefono_1 as alumno_telefono,
        cc.nombre as catalogo_nombre,
        cc.id_moodle as catalogo_id_moodle
        FROM cursos c
        LEFT JOIN empresas e ON c.id_empresa = e.id
        LEFT JOIN alumnos a ON c.id_alumno = a.id
        LEFT JOIN catalogo_cursos cc ON c.id_catalogo_curso = cc.id
        WHERE c.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_curso);
$stmt->execute();
$curso = $stmt->get_result()->fetch_assoc();

if (!$curso) {
    header('Location: listado.php?error=not_found');
    exit;
}

// Dividir nombre completo en firstname y lastname
$partes_nombre = array_values(array_filter(explode(' ', trim($curso['alumno_nombre_completo']))));
$firstname = $partes_nombre[0] ?? '---';
$lastname = implode(' ', array_slice($partes_nombre, 1)) ?: '---';

// Generar username automático
$username_sugerido = strtolower(str_replace(['@', '.', ' ', '/'], '', explode('@', $curso['alumno_email'])[0]));
$username_sugerido = substr($username_sugerido, 0, 20);

// Generar contraseña temporal
$password_temporal = 'Geae' . rand(1000, 9999) . '!';

// Obtener cursos disponibles en Moodle API
$cursos_moodle_api = [];
$error_api = '';

try {
    // Usar variables del config.php (no son constantes)
    global $db_host, $db_name, $db_user, $db_pass;
    
    $pdo = new PDO(
        "mysql:host=" . $db_host . ";dbname=" . $db_name . ";charset=utf8mb4",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    $moodle = new MoodleAPI($pdo);
    
    // Usar getCursos() que ya existe en MoodleAPI
    $cursos_moodle_api = $moodle->getCursos();
    
} catch (Exception $e) {
    $error_api = $e->getMessage();
}

// Procesar formulario
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Verificar si es solo guardar ID de curso o crear usuario completo
    $accion = $_POST['accion'] ?? 'crear_usuario';
    
    // ACCIÓN: Solo guardar ID de curso Moodle
    if ($accion === 'guardar_id_curso') {
        try {
            $id_course_moodle = (int)$_POST['id_course_moodle'];
            
            if ($id_course_moodle <= 0) {
                throw new Exception("Debe seleccionar un curso válido");
            }
            
            // Actualizar solo el ID del curso en la BD
            $sql_update = "UPDATE cursos 
                          SET moodle_course_id = ?
                          WHERE id = ?";
            $stmt_update = $conn->prepare($sql_update);
            $stmt_update->bind_param('ii', $id_course_moodle, $id_curso);
            $stmt_update->execute();
            
            $success = "ID del curso Moodle guardado correctamente (ID: $id_course_moodle)";
            
            // Recargar datos del curso
            $stmt = $conn->prepare("SELECT c.*, 
                    e.denominacion as empresa_nombre,
                    e.cif as empresa_cif,
                    a.nombre as alumno_nombre_completo,
                    a.dni as alumno_dni,
                    a.email as alumno_email,
                    a.telefono_1 as alumno_telefono,
                    cc.nombre as catalogo_nombre,
                    cc.id_moodle as catalogo_id_moodle
                    FROM cursos c
                    LEFT JOIN empresas e ON c.id_empresa = e.id
                    LEFT JOIN alumnos a ON c.id_alumno = a.id
                    LEFT JOIN catalogo_cursos cc ON c.id_catalogo_curso = cc.id
                    WHERE c.id = ?");
            $stmt->bind_param('i', $id_curso);
            $stmt->execute();
            $curso = $stmt->get_result()->fetch_assoc();
            
        } catch (Exception $e) {
            $error = "Error al guardar ID de curso: " . $e->getMessage();
        }
    }
    // ACCIÓN: Crear usuario y matricular
    else {
        try {
            // Usar variables del config.php (no son constantes)
            global $db_host, $db_name, $db_user, $db_pass;
            
            $pdo = new PDO(
                "mysql:host=" . $db_host . ";dbname=" . $db_name . ";charset=utf8mb4",
                $db_user,
                $db_pass,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            
            $moodle = new MoodleAPI($pdo);
            
            $username = $_POST['username'];
            $password = $_POST['password'];
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $email = $_POST['email'];
            $id_course_moodle = (int)$_POST['id_course_moodle'];
            
            // Crear usuario en Moodle
            $result = $moodle->crearUsuario(
                $username,
                $password,
                $firstname,
                $lastname,
                $email
            );
        
        if ($result['success']) {
            $moodle_user_id = $result['userid'];
            
            // Matricular en curso
            $matricula = $moodle->matricularUsuario($moodle_user_id, $id_course_moodle);
            
            if ($matricula['success']) {
                // Actualizar BD
                $sql_update = "UPDATE cursos 
                              SET moodle_user_id = ?,
                                  moodle_matricula_fecha = NOW(),
                                  moodle_estado = 'matriculado',
                                  moodle_error = NULL
                              WHERE id = ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param('ii', $moodle_user_id, $id_curso);
                $stmt_update->execute();
                
                // Registrar en log
                $sql_log = "INSERT INTO moodle_altas_log 
                           (id_curso, id_alumno, username_moodle, email, moodle_user_id, 
                            moodle_course_id, password_enviado, email_enviado, 
                            fecha_hora_local, respuesta_moodle)
                           VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW(), ?)";
                $stmt_log = $conn->prepare($sql_log);
                $pass_enc = 1;
                $respuesta = json_encode($result);
                $stmt_log->bind_param('iissiiis', 
                    $id_curso, 
                    $curso['id_alumno'],
                    $username,
                    $email,
                    $moodle_user_id,
                    $id_course_moodle,
                    $pass_enc,
                    $respuesta
                );
                $stmt_log->execute();
                
                // Enviar email con credenciales
                enviarEmailCredenciales($curso, $username, $password, $firstname, $lastname);
                
                $success = "¡Alta completada! Usuario creado y matriculado en Moodle.";
                
                // Redireccionar después de 2 segundos
                header("refresh:2;url=ver.php?id=$id_curso");
                exit;
                
            } else {
                throw new Exception("Error al matricular: " . $matricula['message']);
            }
        } else {
            throw new Exception("Error al crear usuario: " . $result['message']);
        }
        
        } catch (Exception $e) {
            $error = $e->getMessage();
            
            // Registrar error en BD
            $sql_error = "UPDATE cursos 
                         SET moodle_estado = 'error',
                             moodle_error = ?
                         WHERE id = ?";
            $stmt_error = $conn->prepare($sql_error);
            $error_msg = substr($e->getMessage(), 0, 500);
            $stmt_error->bind_param('si', $error_msg, $id_curso);
            $stmt_error->execute();
        }
    }
}

// Función para enviar email
function enviarEmailCredenciales($curso, $username, $password, $firstname, $lastname) {
    global $conn;
    
    // Obtener plantilla
    $sql_plantilla = "SELECT * FROM moodle_plantillas_email WHERE tipo = 'credenciales_alta' AND activa = 1 LIMIT 1";
    $plantilla = $conn->query($sql_plantilla)->fetch_assoc();
    
    if (!$plantilla) {
        return false;
    }
    
    // Reemplazar variables
    $variables = [
        '{nombre}' => $firstname,
        '{apellidos}' => $lastname,
        '{curso}' => $curso['nombre_curso'],
        '{username}' => $username,
        '{password}' => $password,
        '{url_moodle}' => 'https://www.geae.es/plataforma',
        '{empresa}' => $curso['empresa_nombre']
    ];
    
    $asunto = str_replace(array_keys($variables), array_values($variables), $plantilla['asunto']);
    $mensaje = str_replace(array_keys($variables), array_values($variables), $plantilla['contenido_html']);
    
    // Enviar email
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=utf-8\r\n";
    $headers .= "From: GEAE Formación <formacion@geae.es>\r\n";
    
    return mail($curso['alumno_email'], $asunto, $mensaje, $headers);
}

$page_title = "Alta Individual en Moodle - Curso #" . $curso['id'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/cursos.css">
</head>
<body>

<div class="wrapper">
    <?php include 'sidebar.php'; ?>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-cloud-upload-alt me-2"></i>Alta en Moodle
                </span>
                
                <div class="ms-auto">
                    <a href="ver.php?id=<?php echo $curso['id']; ?>" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i>Volver
                    </a>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i>
                <strong>¡Éxito!</strong> <?php echo $success; ?>
                <p class="mb-0 mt-2 small">Redirigiendo al detalle del curso...</p>
            </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Error:</strong> <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <?php if ($error_api): ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-circle me-2"></i>
                <strong>Advertencia:</strong> No se pudieron cargar cursos desde Moodle API.
                <details class="mt-2">
                    <summary>Ver detalles del error</summary>
                    <code><?php echo htmlspecialchars($error_api); ?></code>
                </details>
                <p class="mb-0 mt-2"><small>Puede seleccionar desde el catálogo o introducir ID manualmente.</small></p>
            </div>
            <?php endif; ?>
            
            <!-- Información del Curso -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-info-circle me-2"></i>Información del Curso
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="mb-1"><strong>Curso:</strong> <?php echo htmlspecialchars($curso['nombre_curso']); ?></p>
                            <p class="mb-1"><strong>Horas:</strong> <?php echo $curso['horas_curso']; ?>h</p>
                            <?php if ($curso['catalogo_nombre']): ?>
                            <p class="mb-1">
                                <strong>Catálogo:</strong> <?php echo htmlspecialchars($curso['catalogo_nombre']); ?>
                                <?php if ($curso['catalogo_id_moodle']): ?>
                                <span class="badge bg-success ms-2">
                                    <i class="fas fa-link me-1"></i>ID Moodle: <?php echo $curso['catalogo_id_moodle']; ?>
                                </span>
                                <?php endif; ?>
                            </p>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-1"><strong>Alumno:</strong> <?php echo htmlspecialchars($curso['alumno_nombre_completo']); ?></p>
                            <p class="mb-1"><strong>DNI:</strong> <?php echo htmlspecialchars($curso['alumno_dni']); ?></p>
                            <p class="mb-1"><strong>Email:</strong> <?php echo htmlspecialchars($curso['alumno_email']); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Formulario de Alta -->
            <form method="POST" id="formAltaMoodle">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-user-plus me-2"></i>Datos para Alta en Moodle
                                </h5>
                            </div>
                            <div class="card-body">
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Nombre *</label>
                                        <input type="text" name="firstname" class="form-control" 
                                               value="<?php echo htmlspecialchars($firstname); ?>" 
                                               required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Apellidos *</label>
                                        <input type="text" name="lastname" class="form-control" 
                                               value="<?php echo htmlspecialchars($lastname); ?>" 
                                               required>
                                    </div>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">
                                            Usuario Moodle *
                                            <i class="fas fa-info-circle text-muted" 
                                               data-bs-toggle="tooltip" 
                                               title="Generado automáticamente desde el email"></i>
                                        </label>
                                        <input type="text" name="username" class="form-control" 
                                               value="<?php echo $username_sugerido; ?>" 
                                               required 
                                               pattern="[a-z0-9]+" 
                                               maxlength="20">
                                        <small class="text-muted">Solo minúsculas y números, máx. 20 caracteres</small>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Email *</label>
                                        <input type="email" name="email" class="form-control" 
                                               value="<?php echo htmlspecialchars($curso['alumno_email']); ?>" 
                                               required>
                                    </div>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">
                                            Contraseña Temporal *
                                            <button type="button" class="btn btn-sm btn-outline-primary" 
                                                    onclick="generarPassword()">
                                                <i class="fas fa-refresh"></i> Generar
                                            </button>
                                        </label>
                                        <div class="input-group">
                                            <input type="text" name="password" id="password" class="form-control" 
                                                   value="<?php echo $password_temporal; ?>" 
                                                   required 
                                                   minlength="8">
                                            <button type="button" class="btn btn-outline-secondary" 
                                                    onclick="togglePassword()">
                                                <i class="fas fa-eye" id="toggleIcon"></i>
                                            </button>
                                        </div>
                                        <small class="text-muted">Mínimo 8 caracteres. Se enviará por email.</small>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">
                                            Curso Moodle *
                                            <i class="fas fa-info-circle text-muted" 
                                               data-bs-toggle="tooltip" 
                                               title="Selecciona el curso donde se matriculará el alumno"></i>
                                        </label>
                                        <select name="id_course_moodle" id="selectCursoMoodle" class="form-select" required>
                                            <option value="">Seleccionar curso...</option>
                                            
                                            <?php 
                                            // Prioridad 1: Si hay moodle_course_id guardado, usar ese
                                            $id_preseleccionado = !empty($curso['moodle_course_id']) ? $curso['moodle_course_id'] : $curso['catalogo_id_moodle'];
                                            
                                            // Si hay ID guardado, mostrarlo primero
                                            if ($id_preseleccionado): 
                                                // Buscar el nombre del curso
                                                $nombre_curso_seleccionado = '';
                                                
                                                // Buscar en cursos API
                                                foreach ($cursos_moodle_api as $cm) {
                                                    if ($cm['id'] == $id_preseleccionado) {
                                                        $nombre_curso_seleccionado = $cm['shortname'] . ' - ' . $cm['fullname'];
                                                        break;
                                                    }
                                                }
                                                
                                                // Si no se encontró, buscar en catálogo
                                                if (empty($nombre_curso_seleccionado) && !empty($curso['catalogo_nombre']) && $curso['catalogo_id_moodle'] == $id_preseleccionado) {
                                                    $nombre_curso_seleccionado = $curso['catalogo_nombre'];
                                                }
                                                
                                                // Si aún no se encontró, mostrar solo el ID
                                                if (empty($nombre_curso_seleccionado)) {
                                                    $nombre_curso_seleccionado = "Curso guardado";
                                                }
                                            ?>
                                            <option value="<?php echo $id_preseleccionado; ?>" selected>
                                                ✅ <?php echo htmlspecialchars($nombre_curso_seleccionado); ?> (ID: <?php echo $id_preseleccionado; ?>)
                                            </option>
                                            <?php endif; ?>
                                            
                                            <?php if (!empty($cursos_moodle_api)): ?>
                                            <optgroup label="📚 Cursos desde Moodle API">
                                                <?php foreach ($cursos_moodle_api as $cm): ?>
                                                <?php if ($cm['id'] != $id_preseleccionado): ?>
                                                <option value="<?php echo $cm['id']; ?>">
                                                    <?php echo htmlspecialchars($cm['shortname'] . ' - ' . $cm['fullname']); ?> (ID: <?php echo $cm['id']; ?>)
                                                </option>
                                                <?php endif; ?>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            <?php endif; ?>
                                            
                                            <?php
                                            // Obtener cursos del catálogo
                                            $sql_cursos = "SELECT id, codigo, nombre, id_moodle 
                                                          FROM catalogo_cursos 
                                                          WHERE id_moodle IS NOT NULL AND activo = 1
                                                          ORDER BY nombre";
                                            $result_cursos = $conn->query($sql_cursos);
                                            if ($result_cursos && $result_cursos->num_rows > 0):
                                            ?>
                                            <optgroup label="💾 Cursos desde Catálogo">
                                                <?php while ($cm = $result_cursos->fetch_assoc()): ?>
                                                <?php if ($cm['id_moodle'] != $id_preseleccionado): ?>
                                                <option value="<?php echo $cm['id_moodle']; ?>">
                                                    <?php echo htmlspecialchars($cm['nombre']); ?> (ID: <?php echo $cm['id_moodle']; ?>)
                                                </option>
                                                <?php endif; ?>
                                                <?php endwhile; ?>
                                            </optgroup>
                                            <?php endif; ?>
                                            
                                            <option value="manual">✏️ Introducir ID manualmente...</option>
                                        </select>
                                        
                                        <!-- Input manual (oculto por defecto) -->
                                        <div id="divIdManual" style="display: none;" class="mt-2">
                                            <label class="form-label small">ID del curso en Moodle:</label>
                                            <input type="number" id="inputIdManual" class="form-control" 
                                                   placeholder="Ej: 123" min="1">
                                            <small class="text-muted">Introduce el ID numérico del curso en Moodle</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-check mb-3">
                                    <input type="checkbox" class="form-check-input" id="enviarEmail" checked>
                                    <label class="form-check-label" for="enviarEmail">
                                        <i class="fas fa-envelope me-1"></i>
                                        Enviar credenciales por email al alumno
                                    </label>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card mb-3">
                            <div class="card-header bg-info text-white">
                                <h6 class="mb-0"><i class="fas fa-lightbulb me-2"></i>Información</h6>
                            </div>
                            <div class="card-body">
                                <h6 class="text-primary mb-2">
                                    <i class="fas fa-save me-1"></i>Solo Guardar ID:
                                </h6>
                                <p class="small mb-3">
                                    • Guarda el ID del curso Moodle<br>
                                    • NO crea el usuario aún<br>
                                    • Útil para preparar el curso
                                </p>
                                
                                <hr>
                                
                                <h6 class="text-success mb-2">
                                    <i class="fas fa-cloud-upload-alt me-1"></i>Crear y Matricular:
                                </h6>
                                <p class="small mb-2">
                                    <i class="fas fa-check text-success me-1"></i>
                                    Crea el usuario en Moodle
                                </p>
                                <p class="small mb-2">
                                    <i class="fas fa-check text-success me-1"></i>
                                    Matricula automáticamente
                                </p>
                                <p class="small mb-2">
                                    <i class="fas fa-check text-success me-1"></i>
                                    Envía credenciales por email
                                </p>
                                <p class="small mb-0">
                                    <i class="fas fa-check text-success me-1"></i>
                                    Registra en el historial
                                </p>
                                
                                <?php if (count($cursos_moodle_api) > 0): ?>
                                <hr>
                                <p class="small text-success mb-0">
                                    <i class="fas fa-sync me-1"></i>
                                    Conectado con Moodle<br>
                                    <small><?php echo count($cursos_moodle_api); ?> cursos disponibles</small>
                                </p>
                                <?php elseif ($error_api): ?>
                                <hr>
                                <p class="small text-warning mb-0">
                                    <i class="fas fa-exclamation-triangle me-1"></i>
                                    No conectado con Moodle<br>
                                    <small>Usa ID manual o catálogo</small>
                                </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <!-- Mostrar ID de curso guardado si existe -->
                            <?php if (!empty($curso['moodle_course_id'])): ?>
                            <div class="alert alert-info mb-3">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>Curso Moodle guardado:</strong> ID <?php echo $curso['moodle_course_id']; ?>
                            </div>
                            <?php endif; ?>
                            
                            <!-- Botón: Solo guardar ID del curso -->
                            <button type="submit" name="accion" value="guardar_id_curso" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>
                                Guardar ID del Curso
                            </button>
                            
                            <div class="text-center my-2">
                                <small class="text-muted">- o -</small>
                            </div>
                            
                            <!-- Botón: Crear usuario y matricular -->
                            <button type="submit" name="accion" value="crear_usuario" class="btn btn-success btn-lg">
                                <i class="fas fa-cloud-upload-alt me-2"></i>
                                Crear y Matricular
                            </button>
                            
                            <a href="ver.php?id=<?php echo $curso['id']; ?>" class="btn btn-secondary">
                                <i class="fas fa-times me-2"></i>Cancelar
                            </a>
                        </div>
                    </div>
                </div>
            </form>
            
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Toggle sidebar
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.getElementById('sidebar').classList.toggle('active');
});

// Tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
});

// Manejo de selección de curso
document.getElementById('selectCursoMoodle').addEventListener('change', function() {
    const divManual = document.getElementById('divIdManual');
    const inputManual = document.getElementById('inputIdManual');
    
    if (this.value === 'manual') {
        divManual.style.display = 'block';
        inputManual.required = true;
        inputManual.focus();
    } else {
        divManual.style.display = 'none';
        inputManual.required = false;
        inputManual.value = '';
    }
});

function generarPassword() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%';
    let password = 'Geae';
    for (let i = 0; i < 8; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    document.getElementById('password').value = password;
}

function togglePassword() {
    const input = document.getElementById('password');
    const icon = document.getElementById('toggleIcon');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Confirmación antes de enviar
document.getElementById('formAltaMoodle').addEventListener('submit', function(e) {
    const selectCurso = document.getElementById('selectCursoMoodle');
    const inputManual = document.getElementById('inputIdManual');
    const accion = e.submitter ? e.submitter.value : 'crear_usuario';
    
    // Si se seleccionó manual, usar el valor del input
    if (selectCurso.value === 'manual') {
        if (!inputManual.value || inputManual.value <= 0) {
            e.preventDefault();
            alert('Por favor, introduce un ID de curso válido');
            inputManual.focus();
            return false;
        }
        // Crear un input hidden con el valor manual
        const hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.name = 'id_course_moodle';
        hiddenInput.value = inputManual.value;
        this.appendChild(hiddenInput);
        selectCurso.removeAttribute('name');
    }
    
    // Confirmación según la acción
    if (accion === 'guardar_id_curso') {
        if (!confirm('¿Guardar ID del curso en Moodle?\n\nSe guardará el ID del curso seleccionado para este alumno.')) {
            e.preventDefault();
            return false;
        }
    } else {
        if (!confirm('¿Confirmar alta en Moodle?\n\nSe creará el usuario y se enviará el email con las credenciales.')) {
            e.preventDefault();
            return false;
        }
    }
});
</script>

</body>
</html>
