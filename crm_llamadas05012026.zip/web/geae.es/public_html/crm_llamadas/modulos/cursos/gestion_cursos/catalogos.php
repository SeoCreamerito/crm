<?php
/**
 * Gestión de Catálogos - Módulo FUNDAE
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin']);

$mensaje = '';
$tipo_mensaje = '';

// Obtener catálogo activo
$catalogo_activo = $_GET['catalogo'] ?? 'cursos';

// Mapeo de catálogos
$catalogos = [
    'cursos' => [
        'nombre' => 'Catálogo de Cursos',
        'tabla' => 'catalogo_cursos',
        'icono' => 'book',
        'descripcion' => 'Gestiona los cursos disponibles en el catálogo'
    ],
    'puestos' => [
        'nombre' => 'Puestos de Trabajo',
        'tabla' => 'catalogo_puestos',
        'icono' => 'briefcase',
        'descripcion' => 'Gestiona los puestos laborales'
    ],
    'titulaciones' => [
        'nombre' => 'Titulaciones',
        'tabla' => 'catalogo_titulaciones',
        'icono' => 'graduation-cap',
        'descripcion' => 'Gestiona las titulaciones académicas'
    ],
    'regalos' => [
        'nombre' => 'Regalos',
        'tabla' => 'catalogo_regalos',
        'icono' => 'gift',
        'descripcion' => 'Gestiona los regalos comerciales'
    ]
];

// Validar catálogo
if (!isset($catalogos[$catalogo_activo])) {
    $catalogo_activo = 'cursos';
}

$catalogo = $catalogos[$catalogo_activo];

// Procesar formularios
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        
        if ($catalogo_activo === 'cursos') {
            // Gestión de cursos
            if ($id) {
                // Actualizar
                $sql = "UPDATE catalogo_cursos SET 
                        codigo = ?, nombre = ?, horas = ?, modalidad = ?, descripcion = ?,
                        id_moodle = ?, categoria_moodle = ?, url_moodle = ?,
                        estado_moodle = ?, activo = ?
                        WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $id_moodle = !empty($_POST['id_moodle']) ? (int)$_POST['id_moodle'] : null;
                $horas = !empty($_POST['horas']) ? (int)$_POST['horas'] : 0;
                $estado_moodle = $_POST['estado_moodle'] ?? 'pendiente';
                $activo = isset($_POST['activo']) ? 1 : 0;
                
                $stmt->bind_param('ssissssssii',
                    $_POST['codigo'], $_POST['nombre'], $horas, $_POST['modalidad'], $_POST['descripcion'],
                    $id_moodle, $_POST['categoria_moodle'], $_POST['url_moodle'],
                    $estado_moodle, $activo, $id
                );
            } else {
                // Crear
                $sql = "INSERT INTO catalogo_cursos 
                        (codigo, nombre, horas, modalidad, descripcion, id_moodle, categoria_moodle, url_moodle, estado_moodle, activo, creado_en)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                $stmt = $conn->prepare($sql);
                $id_moodle = !empty($_POST['id_moodle']) ? (int)$_POST['id_moodle'] : null;
                $horas = !empty($_POST['horas']) ? (int)$_POST['horas'] : 0;
                $estado_moodle = $_POST['estado_moodle'] ?? 'pendiente';
                $activo = isset($_POST['activo']) ? 1 : 0;
                
                $stmt->bind_param('ssissssssi',
                    $_POST['codigo'], $_POST['nombre'], $horas, $_POST['modalidad'], $_POST['descripcion'],
                    $id_moodle, $_POST['categoria_moodle'], $_POST['url_moodle'],
                    $estado_moodle, $activo
                );
            }
        } elseif ($catalogo_activo === 'puestos') {
            // Gestión de puestos
            if ($id) {
                $sql = "UPDATE catalogo_puestos SET nombre = ?, descripcion = ?, orden = ?, activo = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $orden = !empty($_POST['orden']) ? (int)$_POST['orden'] : 0;
                $activo = isset($_POST['activo']) ? 1 : 0;
                $stmt->bind_param('ssiii', $_POST['nombre'], $_POST['descripcion'], $orden, $activo, $id);
            } else {
                $sql = "INSERT INTO catalogo_puestos (nombre, descripcion, orden, activo, creado_en) VALUES (?, ?, ?, ?, NOW())";
                $stmt = $conn->prepare($sql);
                $orden = !empty($_POST['orden']) ? (int)$_POST['orden'] : 0;
                $activo = isset($_POST['activo']) ? 1 : 0;
                $stmt->bind_param('ssii', $_POST['nombre'], $_POST['descripcion'], $orden, $activo);
            }
        } elseif ($catalogo_activo === 'titulaciones') {
            // Gestión de titulaciones
            if ($id) {
                $sql = "UPDATE catalogo_titulaciones SET nombre = ?, descripcion = ?, nivel = ?, orden = ?, activo = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $nivel = !empty($_POST['nivel']) ? (int)$_POST['nivel'] : 0;
                $orden = !empty($_POST['orden']) ? (int)$_POST['orden'] : 0;
                $activo = isset($_POST['activo']) ? 1 : 0;
                $stmt->bind_param('ssiiii', $_POST['nombre'], $_POST['descripcion'], $nivel, $orden, $activo, $id);
            } else {
                $sql = "INSERT INTO catalogo_titulaciones (nombre, descripcion, nivel, orden, activo, creado_en) VALUES (?, ?, ?, ?, ?, NOW())";
                $stmt = $conn->prepare($sql);
                $nivel = !empty($_POST['nivel']) ? (int)$_POST['nivel'] : 0;
                $orden = !empty($_POST['orden']) ? (int)$_POST['orden'] : 0;
                $activo = isset($_POST['activo']) ? 1 : 0;
                $stmt->bind_param('ssiii', $_POST['nombre'], $_POST['descripcion'], $nivel, $orden, $activo);
            }
        } elseif ($catalogo_activo === 'regalos') {
            // Gestión de regalos
            if ($id) {
                $sql = "UPDATE catalogo_regalos SET nombre = ?, descripcion = ?, valor_aproximado = ?, activo = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $valor = !empty($_POST['valor_aproximado']) ? floatval($_POST['valor_aproximado']) : 0;
                $activo = isset($_POST['activo']) ? 1 : 0;
                $stmt->bind_param('ssdii', $_POST['nombre'], $_POST['descripcion'], $valor, $activo, $id);
            } else {
                $sql = "INSERT INTO catalogo_regalos (nombre, descripcion, valor_aproximado, activo, creado_en) VALUES (?, ?, ?, ?, NOW())";
                $stmt = $conn->prepare($sql);
                $valor = !empty($_POST['valor_aproximado']) ? floatval($_POST['valor_aproximado']) : 0;
                $activo = isset($_POST['activo']) ? 1 : 0;
                $stmt->bind_param('ssdi', $_POST['nombre'], $_POST['descripcion'], $valor, $activo);
            }
        }
        
        $stmt->execute();
        $mensaje = $id ? "Item actualizado correctamente" : "Item creado correctamente";
        $tipo_mensaje = "success";
    } catch (Exception $e) {
        $mensaje = "Error: " . $e->getMessage();
        $tipo_mensaje = "danger";
    }
}

// Eliminar item (desactivar)
if (isset($_GET['eliminar'])) {
    $id = (int)$_GET['eliminar'];
    $sql = "UPDATE {$catalogo['tabla']} SET activo = 0 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $mensaje = "Item desactivado correctamente";
    $tipo_mensaje = "success";
}

// Obtener items del catálogo
$sql = "SELECT * FROM {$catalogo['tabla']}";
if ($catalogo_activo === 'cursos') {
    $sql .= " ORDER BY nombre ASC";
} elseif ($catalogo_activo === 'puestos' || $catalogo_activo === 'titulaciones') {
    $sql .= " ORDER BY orden ASC, nombre ASC";
} else {
    $sql .= " ORDER BY nombre ASC";
}
$result = $conn->query($sql);
$items = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
}

// Estadísticas
$stats = [
    'total' => count($items),
    'activos' => count(array_filter($items, fn($i) => ($i['activo'] ?? 1) == 1)),
    'inactivos' => count(array_filter($items, fn($i) => ($i['activo'] ?? 1) == 0))
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Catálogos - FUNDAE</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/cursos.css">
</head>
<body>

<div class="wrapper">
    <?php include 'sidebar.php'; ?>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-cogs me-2"></i>Gestión de Catálogos
                </span>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <?php if ($mensaje): ?>
            <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show">
                <?php echo htmlspecialchars($mensaje); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <!-- Navegación de catálogos -->
            <div class="card table-custom mb-4">
                <div class="card-body">
                    <ul class="nav nav-tabs">
                        <?php foreach ($catalogos as $key => $cat): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $key === $catalogo_activo ? 'active' : ''; ?>" 
                               href="?catalogo=<?php echo $key; ?>">
                                <i class="fas fa-<?php echo $cat['icono']; ?> me-1"></i>
                                <?php echo $cat['nombre']; ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- Estadísticas -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="stat-card card primary">
                        <div class="card-body">
                            <div class="stat-icon">
                                <i class="fas fa-list"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['total']; ?></div>
                            <div class="stat-label">Total</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card card success">
                        <div class="card-body">
                            <div class="stat-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['activos']; ?></div>
                            <div class="stat-label">Activos</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card card warning">
                        <div class="card-body">
                            <div class="stat-icon">
                                <i class="fas fa-times-circle"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['inactivos']; ?></div>
                            <div class="stat-label">Inactivos</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabla de items -->
            <div class="card table-custom">
                <div class="card-header bg-white border-0 pt-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-0">
                                <i class="fas fa-<?php echo $catalogo['icono']; ?> me-2"></i>
                                <?php echo $catalogo['nombre']; ?>
                            </h5>
                            <small class="text-muted"><?php echo $catalogo['descripcion']; ?></small>
                        </div>
                        <button class="btn btn-gradient-success btn-custom" data-bs-toggle="modal" data-bs-target="#modalItem">
                            <i class="fas fa-plus-circle me-1"></i>Nuevo
                        </button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <?php if ($catalogo_activo === 'cursos'): ?>
                                    <th>ID</th>
                                    <th>Código</th>
                                    <th>Nombre</th>
                                    <th>Horas</th>
                                    <th>Modalidad</th>
                                    <th>Moodle</th>
                                    <th>Estado</th>
                                    <th class="text-center">Acciones</th>
                                    <?php elseif ($catalogo_activo === 'puestos' || $catalogo_activo === 'titulaciones'): ?>
                                    <th>ID</th>
                                    <th>Orden</th>
                                    <th>Nombre</th>
                                    <th>Descripción</th>
                                    <?php if ($catalogo_activo === 'titulaciones'): ?>
                                    <th>Nivel</th>
                                    <?php endif; ?>
                                    <th>Estado</th>
                                    <th class="text-center">Acciones</th>
                                    <?php elseif ($catalogo_activo === 'regalos'): ?>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Descripción</th>
                                    <th>Valor</th>
                                    <th>Estado</th>
                                    <th class="text-center">Acciones</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($items)): ?>
                                <tr>
                                    <td colspan="10" class="text-center py-5">
                                        <i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i>
                                        <p class="text-muted">No hay items en este catálogo</p>
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach ($items as $item): ?>
                                <tr>
                                    <?php if ($catalogo_activo === 'cursos'): ?>
                                    <td><?php echo $item['id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($item['codigo']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($item['nombre']); ?></td>
                                    <td><?php echo $item['horas']; ?>h</td>
                                    <td><?php echo htmlspecialchars($item['modalidad'] ?? '-'); ?></td>
                                    <td>
                                        <?php if ($item['id_moodle']): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check me-1"></i>ID: <?php echo $item['id_moodle']; ?>
                                        </span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Sin Moodle</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($item['activo']): ?>
                                        <span class="badge bg-success">Activo</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Inactivo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <button onclick='editarItem(<?php echo json_encode($item); ?>)' 
                                                    class="btn btn-sm btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <a href="?catalogo=<?php echo $catalogo_activo; ?>&eliminar=<?php echo $item['id']; ?>" 
                                               onclick="return confirm('¿Desactivar este item?')"
                                               class="btn btn-sm btn-danger" title="Desactivar">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                    <?php elseif ($catalogo_activo === 'puestos'): ?>
                                    <td><?php echo $item['id']; ?></td>
                                    <td><span class="badge bg-info"><?php echo $item['orden']; ?></span></td>
                                    <td><strong><?php echo htmlspecialchars($item['nombre']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($item['descripcion'] ?? '-'); ?></td>
                                    <td>
                                        <?php if ($item['activo']): ?>
                                        <span class="badge bg-success">Activo</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Inactivo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <button onclick='editarItem(<?php echo json_encode($item); ?>)' 
                                                    class="btn btn-sm btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <a href="?catalogo=<?php echo $catalogo_activo; ?>&eliminar=<?php echo $item['id']; ?>" 
                                               onclick="return confirm('¿Desactivar este item?')"
                                               class="btn btn-sm btn-danger" title="Desactivar">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                    <?php elseif ($catalogo_activo === 'titulaciones'): ?>
                                    <td><?php echo $item['id']; ?></td>
                                    <td><span class="badge bg-info"><?php echo $item['orden']; ?></span></td>
                                    <td><strong><?php echo htmlspecialchars($item['nombre']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($item['descripcion'] ?? '-'); ?></td>
                                    <td><span class="badge bg-primary">Nivel <?php echo $item['nivel']; ?></span></td>
                                    <td>
                                        <?php if ($item['activo']): ?>
                                        <span class="badge bg-success">Activo</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Inactivo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <button onclick='editarItem(<?php echo json_encode($item); ?>)' 
                                                    class="btn btn-sm btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <a href="?catalogo=<?php echo $catalogo_activo; ?>&eliminar=<?php echo $item['id']; ?>" 
                                               onclick="return confirm('¿Desactivar este item?')"
                                               class="btn btn-sm btn-danger" title="Desactivar">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                    <?php elseif ($catalogo_activo === 'regalos'): ?>
                                    <td><?php echo $item['id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($item['nombre']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($item['descripcion'] ?? '-'); ?></td>
                                    <td><?php echo formatMoneda($item['valor_aproximado'] ?? 0); ?></td>
                                    <td>
                                        <?php if ($item['activo']): ?>
                                        <span class="badge bg-success">Activo</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Inactivo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <button onclick='editarItem(<?php echo json_encode($item); ?>)' 
                                                    class="btn btn-sm btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <a href="?catalogo=<?php echo $catalogo_activo; ?>&eliminar=<?php echo $item['id']; ?>" 
                                               onclick="return confirm('¿Desactivar este item?')"
                                               class="btn btn-sm btn-danger" title="Desactivar">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Modal Item -->
<div class="modal fade" id="modalItem" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">
                        <i class="fas fa-<?php echo $catalogo['icono']; ?> me-2"></i>
                        <span id="modalTitleText">Nuevo Item</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="item_id">
                    
                    <?php if ($catalogo_activo === 'cursos'): ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Código <span class="text-danger">*</span></label>
                            <input type="text" name="codigo" id="codigo" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nombre <span class="text-danger">*</span></label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Horas <span class="text-danger">*</span></label>
                            <input type="number" name="horas" id="horas" class="form-control" required min="0">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Modalidad</label>
                            <input type="text" name="modalidad" id="modalidad" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Estado Moodle</label>
                            <select name="estado_moodle" id="estado_moodle" class="form-select">
                                <option value="pendiente">Pendiente</option>
                                <option value="activo">Activo</option>
                                <option value="desactivado">Desactivado</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">ID Moodle</label>
                            <input type="number" name="id_moodle" id="id_moodle" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Categoría Moodle</label>
                            <input type="text" name="categoria_moodle" id="categoria_moodle" class="form-control">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">URL Moodle</label>
                            <input type="url" name="url_moodle" id="url_moodle" class="form-control">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Descripción</label>
                            <textarea name="descripcion" id="descripcion" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="activo" id="activo" value="1" checked>
                                <label class="form-check-label" for="activo">
                                    Activo
                                </label>
                            </div>
                        </div>
                    </div>
                    <?php elseif ($catalogo_activo === 'puestos'): ?>
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label">Nombre <span class="text-danger">*</span></label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Descripción</label>
                            <textarea name="descripcion" id="descripcion" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Orden</label>
                            <input type="number" name="orden" id="orden" class="form-control" min="0" value="0">
                        </div>
                        <div class="col-md-6">
                            <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" name="activo" id="activo" value="1" checked>
                                <label class="form-check-label" for="activo">
                                    Activo
                                </label>
                            </div>
                        </div>
                    </div>
                    <?php elseif ($catalogo_activo === 'titulaciones'): ?>
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label">Nombre <span class="text-danger">*</span></label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Descripción</label>
                            <textarea name="descripcion" id="descripcion" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nivel</label>
                            <input type="number" name="nivel" id="nivel" class="form-control" min="0" value="0">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Orden</label>
                            <input type="number" name="orden" id="orden" class="form-control" min="0" value="0">
                        </div>
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="activo" id="activo" value="1" checked>
                                <label class="form-check-label" for="activo">
                                    Activo
                                </label>
                            </div>
                        </div>
                    </div>
                    <?php elseif ($catalogo_activo === 'regalos'): ?>
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label">Nombre <span class="text-danger">*</span></label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Descripción</label>
                            <textarea name="descripcion" id="descripcion" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Valor Aproximado (€)</label>
                            <input type="number" name="valor_aproximado" id="valor_aproximado" class="form-control" step="0.01" min="0" value="0">
                        </div>
                        <div class="col-md-6">
                            <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" name="activo" id="activo" value="1" checked>
                                <label class="form-check-label" for="activo">
                                    Activo
                                </label>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-gradient-success">
                        <i class="fas fa-save me-1"></i>Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
});

function editarItem(item) {
    document.getElementById('modalTitleText').textContent = 'Editar Item';
    document.getElementById('item_id').value = item.id;
    
    <?php if ($catalogo_activo === 'cursos'): ?>
    document.getElementById('codigo').value = item.codigo || '';
    document.getElementById('nombre').value = item.nombre || '';
    document.getElementById('horas').value = item.horas || 0;
    document.getElementById('modalidad').value = item.modalidad || '';
    document.getElementById('descripcion').value = item.descripcion || '';
    document.getElementById('id_moodle').value = item.id_moodle || '';
    document.getElementById('categoria_moodle').value = item.categoria_moodle || '';
    document.getElementById('url_moodle').value = item.url_moodle || '';
    document.getElementById('estado_moodle').value = item.estado_moodle || 'pendiente';
    document.getElementById('activo').checked = item.activo == 1;
    <?php elseif ($catalogo_activo === 'puestos'): ?>
    document.getElementById('nombre').value = item.nombre || '';
    document.getElementById('descripcion').value = item.descripcion || '';
    document.getElementById('orden').value = item.orden || 0;
    document.getElementById('activo').checked = item.activo == 1;
    <?php elseif ($catalogo_activo === 'titulaciones'): ?>
    document.getElementById('nombre').value = item.nombre || '';
    document.getElementById('descripcion').value = item.descripcion || '';
    document.getElementById('nivel').value = item.nivel || 0;
    document.getElementById('orden').value = item.orden || 0;
    document.getElementById('activo').checked = item.activo == 1;
    <?php elseif ($catalogo_activo === 'regalos'): ?>
    document.getElementById('nombre').value = item.nombre || '';
    document.getElementById('descripcion').value = item.descripcion || '';
    document.getElementById('valor_aproximado').value = item.valor_aproximado || 0;
    document.getElementById('activo').checked = item.activo == 1;
    <?php endif; ?>
    
    new bootstrap.Modal(document.getElementById('modalItem')).show();
}

// Limpiar modal al cerrarlo
document.getElementById('modalItem').addEventListener('hidden.bs.modal', function() {
    document.getElementById('modalTitleText').textContent = 'Nuevo Item';
    document.querySelector('#modalItem form').reset();
    document.getElementById('item_id').value = '';
    <?php if ($catalogo_activo === 'cursos'): ?>
    document.getElementById('activo').checked = true;
    <?php endif; ?>
});
</script>

</body>
</html>

