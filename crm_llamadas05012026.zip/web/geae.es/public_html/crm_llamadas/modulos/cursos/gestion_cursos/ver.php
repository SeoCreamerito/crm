<?php
/*
 * CÓDIGO PARA AGREGAR A VER.PHP
 * Ubicación: Después de la card de "Información del Curso" (alrededor de línea 150-200)
 */

// ============================================================================
// OBTENER DATOS DE INTEGRACIÓN MOODLE
// ============================================================================

// Obtener datos de moodle_altas_log si existe
$sql_moodle = "SELECT mal.*, 
               mc.url_base as moodle_url_base
               FROM moodle_altas_log mal
               LEFT JOIN moodle_configuracion mc ON 1=1
               WHERE mal.id_curso = ?
               ORDER BY mal.fecha_hora_local DESC
               LIMIT 1";
$stmt_moodle = $conn->prepare($sql_moodle);
$stmt_moodle->bind_param('i', $curso['id']);
$stmt_moodle->execute();
$moodle_data = $stmt_moodle->get_result()->fetch_assoc();

// Obtener configuración de Moodle
$sql_config = "SELECT * FROM moodle_configuracion LIMIT 1";
$moodle_config = $conn->query($sql_config)->fetch_assoc();
$moodle_url = $moodle_config['url_base'] ?? 'https://www.geae.es/plataforma';
?>

<!-- ============================================================================ -->
<!-- CARD: INTEGRACIÓN CON MOODLE -->
<!-- ============================================================================ -->

<div class="card mb-4">
    <!-- Header con color según estado -->
    <div class="card-header <?php 
        if ($curso['moodle_estado'] == 'matriculado') echo 'bg-success';
        elseif ($curso['moodle_estado'] == 'error') echo 'bg-danger';
        elseif ($curso['moodle_estado'] == 'usuario_creado') echo 'bg-warning';
        else echo 'bg-secondary';
    ?> text-white">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0">
                <i class="fas fa-cloud me-2"></i>Integración con Moodle
            </h5>
            <span class="badge <?php 
                if ($curso['moodle_estado'] == 'matriculado') echo 'bg-light text-success';
                elseif ($curso['moodle_estado'] == 'error') echo 'bg-light text-danger';
                elseif ($curso['moodle_estado'] == 'usuario_creado') echo 'bg-light text-warning';
                else echo 'bg-light text-secondary';
            ?>">
                <?php echo strtoupper($curso['moodle_estado']); ?>
            </span>
        </div>
    </div>
    
    <div class="card-body">
        <div class="row">
            
            <!-- Columna Izquierda: Estado e Información -->
            <div class="col-md-6">
                <h6 class="text-primary mb-3">
                    <i class="fas fa-info-circle me-2"></i>Estado de Integración
                </h6>
                
                <!-- Alert según estado -->
                <?php if ($curso['moodle_estado'] == 'pendiente'): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-clock me-2"></i>
                    <strong>Pendiente de Alta</strong><br>
                    <small>Este curso aún no ha sido dado de alta en Moodle.</small>
                </div>
                
                <?php elseif ($curso['moodle_estado'] == 'error'): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Error en la Integración</strong><br>
                    <small><?php echo htmlspecialchars($curso['moodle_error']); ?></small>
                </div>
                
                <?php elseif ($curso['moodle_estado'] == 'usuario_creado'): ?>
                <div class="alert alert-info">
                    <i class="fas fa-user-check me-2"></i>
                    <strong>Usuario Creado</strong><br>
                    <small>Usuario creado pero pendiente de matriculación en el curso.</small>
                </div>
                
                <?php elseif ($curso['moodle_estado'] == 'matriculado'): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    <strong>Matriculado Correctamente</strong><br>
                    <small>El alumno está dado de alta y matriculado en Moodle.</small>
                </div>
                <?php endif; ?>
                
                <!-- Información detallada si existe -->
                <?php if ($moodle_data): ?>
                <div class="table-responsive mt-3">
                    <table class="table table-sm table-borderless">
                        <tbody>
                            <?php if ($moodle_data['username_moodle']): ?>
                            <tr>
                                <td width="40%"><strong><i class="fas fa-user me-1"></i>Usuario:</strong></td>
                                <td><code><?php echo htmlspecialchars($moodle_data['username_moodle']); ?></code></td>
                            </tr>
                            <?php endif; ?>
                            
                            <?php if ($moodle_data['moodle_user_id']): ?>
                            <tr>
                                <td><strong><i class="fas fa-id-badge me-1"></i>ID Usuario:</strong></td>
                                <td><?php echo $moodle_data['moodle_user_id']; ?></td>
                            </tr>
                            <?php endif; ?>
                            
                            <?php if ($curso['moodle_matricula_fecha']): ?>
                            <tr>
                                <td><strong><i class="fas fa-calendar me-1"></i>Fecha Alta:</strong></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($curso['moodle_matricula_fecha'])); ?></td>
                            </tr>
                            <?php endif; ?>
                            
                            <?php if ($moodle_data['email_enviado']): ?>
                            <tr>
                                <td><strong><i class="fas fa-envelope me-1"></i>Email Enviado:</strong></td>
                                <td>
                                    <span class="badge bg-success">
                                        <i class="fas fa-check me-1"></i>Sí
                                    </span>
                                </td>
                            </tr>
                            <?php endif; ?>
                            
                            <?php if ($moodle_data['moodle_course_id']): ?>
                            <tr>
                                <td><strong><i class="fas fa-book me-1"></i>ID Curso:</strong></td>
                                <td><?php echo $moodle_data['moodle_course_id']; ?></td>
                            </tr>
                            <?php endif; ?>
                            
                            <?php if (!empty($curso['moodle_course_id'])): ?>
                            <tr>
                                <td><strong><i class="fas fa-link me-1"></i>Curso Guardado:</strong></td>
                                <td>
                                    <span class="badge bg-info">
                                        ID: <?php echo $curso['moodle_course_id']; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Columna Derecha: Acciones Disponibles -->
            <div class="col-md-6">
                <h6 class="text-success mb-3">
                    <i class="fas fa-cogs me-2"></i>Acciones Disponibles
                </h6>
                
                <div class="d-grid gap-2">
                    
                    <!-- Botón: Dar de Alta en Moodle (si está pendiente o error) -->
                    <?php if (in_array($curso['moodle_estado'], ['pendiente', 'error'])): ?>
                    <a href="moodle_alta_individual.php?id=<?php echo $curso['id']; ?>" 
                       class="btn btn-success">
                        <i class="fas fa-cloud-upload-alt me-2"></i>
                        Dar de Alta en Moodle
                    </a>
                    <?php endif; ?>
                    
                    <!-- Botones: Usuario creado pero no matriculado -->
                    <?php if ($curso['moodle_estado'] == 'usuario_creado'): ?>
                    <button type="button" class="btn btn-primary" 
                            onclick="matricularEnCurso(<?php echo $curso['id']; ?>)">
                        <i class="fas fa-user-plus me-2"></i>
                        Matricular en Curso
                    </button>
                    
                    <button type="button" class="btn btn-info" 
                            onclick="verCredencialesMoodle(<?php echo $curso['id']; ?>)">
                        <i class="fas fa-key me-2"></i>
                        Ver Credenciales
                    </button>
                    <?php endif; ?>
                    
                    <!-- Botones: Ya matriculado -->
                    <?php if ($curso['moodle_estado'] == 'matriculado'): ?>
                    <button type="button" class="btn btn-info" 
                            onclick="verCredencialesMoodle(<?php echo $curso['id']; ?>)">
                        <i class="fas fa-key me-2"></i>
                        Ver Credenciales
                    </button>
                    
                    <button type="button" class="btn btn-warning" 
                            onclick="reenviarCredenciales(<?php echo $curso['id']; ?>)">
                        <i class="fas fa-envelope me-2"></i>
                        Reenviar Credenciales
                    </button>
                    
                    <?php if ($moodle_data && $moodle_data['moodle_course_id']): ?>
                    <a href="<?php echo $moodle_url; ?>/course/view.php?id=<?php echo $moodle_data['moodle_course_id']; ?>" 
                       target="_blank" 
                       class="btn btn-primary">
                        <i class="fas fa-external-link-alt me-2"></i>
                        Abrir en Moodle
                    </a>
                    <?php endif; ?>
                    <?php endif; ?>
                    
                    <!-- Botón: Ver Historial (siempre visible si hay datos) -->
                    <?php if ($moodle_data): ?>
                    <a href="moodle_historial.php?id_curso=<?php echo $curso['id']; ?>" 
                       class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-history me-2"></i>
                        Ver Historial de Acciones
                    </a>
                    <?php endif; ?>
                    
                </div>
            </div>
            
        </div>
    </div>
</div>

<!-- ============================================================================ -->
<!-- JAVASCRIPT: FUNCIONES MOODLE -->
<!-- ============================================================================ -->

<script>
/**
 * Ver credenciales de Moodle
 */
function verCredencialesMoodle(idCurso) {
    fetch('ajax/obtener_credenciales_moodle.php?id_curso=' + idCurso)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    title: '<i class="fas fa-key"></i> Credenciales de Moodle',
                    html: `
                        <div class="text-start">
                            <p><strong><i class="fas fa-user me-2"></i>Usuario:</strong> 
                               <code class="fs-5">${data.username}</code>
                               <button class="btn btn-sm btn-outline-secondary ms-2" 
                                       onclick="navigator.clipboard.writeText('${data.username}')">
                                   <i class="fas fa-copy"></i>
                               </button>
                            </p>
                            <p><strong><i class="fas fa-envelope me-2"></i>Email:</strong> ${data.email}</p>
                            <p><strong><i class="fas fa-id-badge me-2"></i>ID Usuario:</strong> ${data.moodle_user_id}</p>
                            <p><strong><i class="fas fa-globe me-2"></i>URL:</strong><br>
                               <a href="${data.url_moodle}" target="_blank">${data.url_moodle}</a>
                            </p>
                            ${data.fecha_alta ? `<p><strong><i class="fas fa-calendar me-2"></i>Fecha:</strong> ${data.fecha_alta}</p>` : ''}
                            ${data.email_enviado ? '<p class="text-success"><i class="fas fa-check me-1"></i>Email de credenciales enviado</p>' : ''}
                        </div>
                    `,
                    icon: 'info',
                    showCancelButton: true,
                    confirmButtonText: '<i class="fas fa-envelope me-2"></i>Reenviar Credenciales',
                    cancelButtonText: 'Cerrar',
                    confirmButtonColor: '#0d6efd'
                }).then((result) => {
                    if (result.isConfirmed) {
                        reenviarCredenciales(idCurso);
                    }
                });
            } else {
                Swal.fire('Error', data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire('Error', 'No se pudieron obtener las credenciales', 'error');
        });
}

/**
 * Reenviar credenciales por email
 */
function reenviarCredenciales(idCurso) {
    Swal.fire({
        title: '¿Reenviar credenciales?',
        text: 'Se enviará un email con las credenciales de acceso a Moodle',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, enviar',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#0d6efd'
    }).then((result) => {
        if (result.isConfirmed) {
            // Mostrar loading
            Swal.fire({
                title: 'Enviando...',
                text: 'Por favor espera',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            
            fetch('ajax/moodle_reenviar_claves.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id_curso=' + idCurso
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire('¡Enviado!', data.message, 'success');
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire('Error', 'No se pudo enviar el email', 'error');
            });
        }
    });
}

/**
 * Matricular en curso Moodle
 */
function matricularEnCurso(idCurso) {
    Swal.fire({
        title: '¿Matricular en curso?',
        text: 'Se matriculará al alumno en el curso de Moodle',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, matricular',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#0d6efd'
    }).then((result) => {
        if (result.isConfirmed) {
            // Mostrar loading
            Swal.fire({
                title: 'Matriculando...',
                text: 'Por favor espera',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            
            fetch('ajax/moodle_matricular.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id_curso=' + idCurso
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire('¡Matriculado!', data.message, 'success').then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire('Error', 'No se pudo matricular', 'error');
            });
        }
    });
}
</script>
