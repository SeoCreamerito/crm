<?php
/**
 * TEST DE BÚSQUEDA - Empresas y Alumnos
 * Verifica que los registros específicos se encuentran
 */

require_once __DIR__ . '/../../includes/config_cursos.php';
require_once __DIR__ . '/../../includes/functions_cursos.php';

// Verificar sesión
if (!isset($_SESSION['user_id'])) {
    die('Debes estar logueado. <a href="../../login.php">Login</a>');
}

echo "<h1>Test de Búsqueda de Empresas y Alumnos</h1>";
echo "<style>
    body { font-family: Arial; padding: 20px; }
    .test { background: #f0f0f0; padding: 15px; margin: 10px 0; border-radius: 5px; }
    .success { background: #d4edda; border-left: 5px solid #28a745; }
    .error { background: #f8d7da; border-left: 5px solid #dc3545; }
    .info { background: #d1ecf1; border-left: 5px solid #17a2b8; }
    pre { background: white; padding: 10px; overflow: auto; }
</style>";

echo "<hr>";

// ============================================================================
// TEST 1: Buscar Alumno Rafael Ceballos (ID 361)
// ============================================================================
echo "<h2>TEST 1: Buscar Alumno 'Rafael Ceballos' (ID 361)</h2>";

$sql_alumno = "SELECT id, nombre, dni, email, telefono_1, activo 
               FROM alumnos 
               WHERE id = 361";
$result_alumno = $conn->query($sql_alumno);

if ($result_alumno && $result_alumno->num_rows > 0) {
    $alumno = $result_alumno->fetch_assoc();
    echo "<div class='test success'>";
    echo "<h3>✅ Alumno encontrado en BD</h3>";
    echo "<pre>";
    print_r($alumno);
    echo "</pre>";
    echo "</div>";
    
    // Probar búsqueda por nombre
    echo "<h3>Probar búsqueda por nombre:</h3>";
    $search_nombre = '%rafael%';
    $sql_busqueda = "SELECT id, nombre, dni, email 
                     FROM alumnos 
                     WHERE (activo = 1 OR activo IS NULL)
                     AND nombre LIKE ?";
    $stmt = $conn->prepare($sql_busqueda);
    $stmt->bind_param('s', $search_nombre);
    $stmt->execute();
    $resultados = $stmt->get_result();
    
    if ($resultados->num_rows > 0) {
        echo "<div class='test success'>";
        echo "<h4>✅ Encontrado con búsqueda 'rafael'</h4>";
        echo "<p>Resultados: " . $resultados->num_rows . "</p>";
        while ($row = $resultados->fetch_assoc()) {
            echo "<pre>" . print_r($row, true) . "</pre>";
        }
        echo "</div>";
    } else {
        echo "<div class='test error'>";
        echo "<h4>❌ NO encontrado con búsqueda 'rafael'</h4>";
        echo "<p><strong>Posible causa:</strong> Campo 'activo' es 0 o búsqueda no coincide</p>";
        echo "</div>";
    }
    
    // Probar búsqueda sin filtro activo
    echo "<h3>Probar búsqueda SIN filtro activo:</h3>";
    $sql_sin_filtro = "SELECT id, nombre, dni, email, activo 
                       FROM alumnos 
                       WHERE nombre LIKE ?";
    $stmt2 = $conn->prepare($sql_sin_filtro);
    $stmt2->bind_param('s', $search_nombre);
    $stmt2->execute();
    $resultados2 = $stmt2->get_result();
    
    if ($resultados2->num_rows > 0) {
        echo "<div class='test info'>";
        echo "<h4>ℹ️ Encontrado SIN filtro activo</h4>";
        echo "<p>Resultados: " . $resultados2->num_rows . "</p>";
        while ($row = $resultados2->fetch_assoc()) {
            echo "<pre>" . print_r($row, true) . "</pre>";
        }
        echo "</div>";
    }
    
} else {
    echo "<div class='test error'>";
    echo "<h3>❌ Alumno ID 361 NO existe en la base de datos</h3>";
    echo "</div>";
}

echo "<hr>";

// ============================================================================
// TEST 2: Buscar Empresa "Grupo Empresarial Ether" (ID 345)
// ============================================================================
echo "<h2>TEST 2: Buscar Empresa 'Grupo Empresarial Ether' (ID 345)</h2>";

$sql_empresa = "SELECT id, cif, denominacion, direccion, poblacion, activo 
                FROM empresas 
                WHERE id = 345";
$result_empresa = $conn->query($sql_empresa);

if ($result_empresa && $result_empresa->num_rows > 0) {
    $empresa = $result_empresa->fetch_assoc();
    echo "<div class='test success'>";
    echo "<h3>✅ Empresa encontrada en BD</h3>";
    echo "<pre>";
    print_r($empresa);
    echo "</pre>";
    echo "</div>";
    
    // Probar búsqueda por nombre
    echo "<h3>Probar búsqueda por nombre:</h3>";
    $search_empresa = '%ether%';
    $sql_busqueda_emp = "SELECT id, cif, denominacion, poblacion 
                         FROM empresas 
                         WHERE (activo = 1 OR activo IS NULL)
                         AND denominacion LIKE ?";
    $stmt_emp = $conn->prepare($sql_busqueda_emp);
    $stmt_emp->bind_param('s', $search_empresa);
    $stmt_emp->execute();
    $resultados_emp = $stmt_emp->get_result();
    
    if ($resultados_emp->num_rows > 0) {
        echo "<div class='test success'>";
        echo "<h4>✅ Encontrada con búsqueda 'ether'</h4>";
        echo "<p>Resultados: " . $resultados_emp->num_rows . "</p>";
        while ($row = $resultados_emp->fetch_assoc()) {
            echo "<pre>" . print_r($row, true) . "</pre>";
        }
        echo "</div>";
    } else {
        echo "<div class='test error'>";
        echo "<h4>❌ NO encontrada con búsqueda 'ether'</h4>";
        echo "<p><strong>Posible causa:</strong> Campo 'activo' es 0 o búsqueda no coincide</p>";
        echo "</div>";
    }
    
    // Probar búsqueda sin filtro activo
    echo "<h3>Probar búsqueda SIN filtro activo:</h3>";
    $sql_sin_filtro_emp = "SELECT id, cif, denominacion, poblacion, activo 
                           FROM empresas 
                           WHERE denominacion LIKE ?";
    $stmt_emp2 = $conn->prepare($sql_sin_filtro_emp);
    $stmt_emp2->bind_param('s', $search_empresa);
    $stmt_emp2->execute();
    $resultados_emp2 = $stmt_emp2->get_result();
    
    if ($resultados_emp2->num_rows > 0) {
        echo "<div class='test info'>";
        echo "<h4>ℹ️ Encontrada SIN filtro activo</h4>";
        echo "<p>Resultados: " . $resultados_emp2->num_rows . "</p>";
        while ($row = $resultados_emp2->fetch_assoc()) {
            echo "<pre>" . print_r($row, true) . "</pre>";
        }
        echo "</div>";
    }
    
} else {
    echo "<div class='test error'>";
    echo "<h3>❌ Empresa ID 345 NO existe en la base de datos</h3>";
    echo "</div>";
}

echo "<hr>";

// ============================================================================
// TEST 3: Estadísticas Generales
// ============================================================================
echo "<h2>TEST 3: Estadísticas Generales</h2>";

// Alumnos
$sql_stats_alumnos = "SELECT 
                      COUNT(*) as total,
                      SUM(CASE WHEN activo = 1 THEN 1 ELSE 0 END) as activos,
                      SUM(CASE WHEN activo = 0 THEN 1 ELSE 0 END) as inactivos,
                      SUM(CASE WHEN activo IS NULL THEN 1 ELSE 0 END) as sin_estado
                      FROM alumnos";
$stats_alumnos = $conn->query($sql_stats_alumnos)->fetch_assoc();

echo "<div class='test info'>";
echo "<h3>📊 Alumnos</h3>";
echo "<ul>";
echo "<li><strong>Total:</strong> " . $stats_alumnos['total'] . "</li>";
echo "<li><strong>Activos (activo=1):</strong> " . $stats_alumnos['activos'] . "</li>";
echo "<li><strong>Inactivos (activo=0):</strong> " . $stats_alumnos['inactivos'] . "</li>";
echo "<li><strong>Sin estado (activo=NULL):</strong> " . $stats_alumnos['sin_estado'] . "</li>";
echo "</ul>";
echo "</div>";

// Empresas
$sql_stats_empresas = "SELECT 
                       COUNT(*) as total,
                       SUM(CASE WHEN activo = 1 THEN 1 ELSE 0 END) as activos,
                       SUM(CASE WHEN activo = 0 THEN 1 ELSE 0 END) as inactivos,
                       SUM(CASE WHEN activo IS NULL THEN 1 ELSE 0 END) as sin_estado
                       FROM empresas";
$stats_empresas = $conn->query($sql_stats_empresas)->fetch_assoc();

echo "<div class='test info'>";
echo "<h3>📊 Empresas</h3>";
echo "<ul>";
echo "<li><strong>Total:</strong> " . $stats_empresas['total'] . "</li>";
echo "<li><strong>Activas (activo=1):</strong> " . $stats_empresas['activos'] . "</li>";
echo "<li><strong>Inactivas (activo=0):</strong> " . $stats_empresas['inactivos'] . "</li>";
echo "<li><strong>Sin estado (activo=NULL):</strong> " . $stats_empresas['sin_estado'] . "</li>";
echo "</ul>";
echo "</div>";

echo "<hr>";
echo "<h2>✅ Test Completado</h2>";
echo "<p><a href='crear.php'>← Volver a Crear Curso</a></p>";
?>
