<?php
/**
 * Crear Curso - Módulo FUNDAE
 * VERSIÓN MEJORADA con búsqueda AJAX y autoguardado
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos']);

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->begin_transaction();
        
        // Validar campos obligatorios
        $required = ['id_empresa', 'id_alumno', 'nombre_curso', 'fecha_inicio'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("El campo $field es obligatorio");
            }
        }
        
        // Calcular mes y año de acción desde fecha_inicio
        $fecha_inicio = $_POST['fecha_inicio'];
        $mes_accion = date('Y-m', strtotime($fecha_inicio));
        $anio_accion = date('Y', strtotime($fecha_inicio));
        $periodo_accion = date('F Y', strtotime($fecha_inicio));
        
        // Insertar curso
        $sql = "
            INSERT INTO cursos (
                id_teleoperadora, id_empresa, id_alumno,
                id_fundae, codigo_curso, numero_curso_anual,
                id_catalogo_curso, nombre_curso, horas_curso,
                fecha_inicio, fecha_fin,
                notificacion_inicio, notificacion_fin,
                fecha_notif_inicio, fecha_notif_fin,
                credito_formacion, cofinanciacion,
                id_regalo, fecha_envio_tarjeta, fecha_envio_regalo,
                envio_claves, fecha_envio_claves, claves_no_oficial_fecha,
                comentario, estado, id_usuario_creador,
                mes_accion, anio_accion, periodo_accion
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pendiente', ?, ?, ?, ?)
        ";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            'iiississsssiiissdissssssisss',
            $_POST['id_teleoperadora'],
            $_POST['id_empresa'],
            $_POST['id_alumno'],
            $_POST['id_fundae'],
            $_POST['codigo_curso'],
            $_POST['numero_curso_anual'],
            $_POST['id_catalogo_curso'],
            $_POST['nombre_curso'],
            $_POST['horas_curso'],
            $_POST['fecha_inicio'],
            $_POST['fecha_fin'],
            $_POST['notificacion_inicio'],
            $_POST['notificacion_fin'],
            $_POST['fecha_notif_inicio'],
            $_POST['fecha_notif_fin'],
            $_POST['credito_formacion'],
            $_POST['cofinanciacion'],
            $_POST['id_regalo'],
            $_POST['fecha_envio_tarjeta'],
            $_POST['fecha_envio_regalo'],
            $_POST['envio_claves'],
            $_POST['fecha_envio_claves'],
            $_POST['claves_no_oficial_fecha'],
            $_POST['comentario'],
            $_SESSION['user_id'],
            $mes_accion,
            $anio_accion,
            $periodo_accion
        );
        
        $stmt->execute();
        $id_curso = $conn->insert_id();
        
        // Registrar en historial
        registrarHistorial($conn, $id_curso, $_SESSION['user_id'], 'Creación', 'Curso creado en el sistema');
        
        $conn->commit();
        
        header('Location: ver.php?id=' . $id_curso . '&success=created');
        exit;
        
    } catch (Exception $e) {
        $conn->rollback();
        $error = $e->getMessage();
    }
}

// Obtener datos para formulario (solo lo mínimo necesario)
$teleoperadoras = getTeleoperadoras($conn);
$regalos = getRegalos($conn);
$catalogoCursos = getCatalogoCursos($conn);

$page_title = "Crear Nuevo Curso";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/cursos.css">
    
    <style>
        .select2-container--bootstrap-5 .select2-selection {
            min-height: 38px;
        }
        .autoguardado-indicator {
            position: fixed;
            top: 70px;
            right: 20px;
            z-index: 9999;
            transition: all 0.3s;
        }
        .select2-results__option--loading {
            color: #999;
        }
    </style>
</head>
<body>

<!-- Indicador de autoguardado -->
<div id="autoguardado-indicator" class="autoguardado-indicator" style="display: none;">
    <div class="alert alert-success mb-0 shadow-sm">
        <i class="fas fa-check-circle me-2"></i>
        <span id="autoguardado-text">Guardando...</span>
    </div>
</div>

<div class="wrapper">
    <?php include 'sidebar.php'; ?>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-plus-circle me-2"></i>Crear Nuevo Curso
                </span>
                
                <div class="ms-auto">
                    <a href="listado.php" class="btn btn-outline-secondary btn-sm btn-custom">
                        <i class="fas fa-arrow-left me-1"></i>Cancelar
                    </a>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <form method="POST" id="formCrearCurso">
                
                <!-- Sección: Información del Curso -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-book me-2"></i>Información del Curso</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Curso del Catálogo</label>
                                <select name="id_catalogo_curso" id="curso_catalogo" class="form-select select2">
                                    <option value="">Seleccionar curso...</option>
                                    <?php foreach ($catalogoCursos as $c): ?>
                                    <option value="<?php echo $c['id']; ?>"
                                            data-nombre="<?php echo htmlspecialchars($c['nombre']); ?>"
                                            data-horas="<?php echo $c['horas']; ?>"
                                            data-codigo="<?php echo htmlspecialchars($c['codigo']); ?>">
                                        <?php echo htmlspecialchars($c['nombre'] . ' (' . $c['horas'] . 'h)'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Nombre del Curso <span class="text-danger">*</span></label>
                                <input type="text" name="nombre_curso" id="nombre_curso" class="form-control" required>
                            </div>
                            
                            <div class="col-md-4">
                                <label class="form-label">Código del Curso</label>
                                <input type="text" name="codigo_curso" id="codigo_curso" class="form-control">
                            </div>
                            
                            <div class="col-md-4">
                                <label class="form-label">Horas</label>
                                <input type="number" name="horas_curso" id="horas_curso" class="form-control" min="1">
                            </div>
                            
                            <div class="col-md-4">
                                <label class="form-label">Número Curso Anual</label>
                                <input type="number" name="numero_curso_anual" class="form-control">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha de Inicio <span class="text-danger">*</span></label>
                                <input type="date" name="fecha_inicio" class="form-control" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha de Fin</label>
                                <input type="date" name="fecha_fin" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección: Empresa -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-building me-2"></i>Empresa</h5>
                            <a href="../empresas/crear.php" target="_blank" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-plus me-1"></i>Nueva Empresa
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-12">
                                <label class="form-label">Buscar Empresa <span class="text-danger">*</span></label>
                                <select name="id_empresa" id="empresa" class="form-select" required>
                                    <option value="">Escribe para buscar por CIF o nombre...</option>
                                </select>
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Escribe al menos 2 caracteres para buscar
                                </small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección: Alumno -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-user-graduate me-2"></i>Alumno</h5>
                            <a href="../alumnos/crear.php" target="_blank" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-plus me-1"></i>Nuevo Alumno
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-12">
                                <label class="form-label">Buscar Alumno <span class="text-danger">*</span></label>
                                <select name="id_alumno" id="alumno" class="form-select" required>
                                    <option value="">Escribe para buscar por DNI, nombre o email...</option>
                                </select>
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Escribe al menos 2 caracteres para buscar
                                </small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Resto de secciones sin cambios... -->
                <!-- Sección: FUNDAE -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-euro-sign me-2"></i>Información FUNDAE</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">ID FUNDAE</label>
                                <input type="text" name="id_fundae" class="form-control">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Crédito de Formación (€)</label>
                                <input type="number" name="credito_formacion" class="form-control" step="0.01" min="0" value="0">
                            </div>
                            
                            <div class="col-md-3">
                                <label class="form-label">Cofinanciación (€)</label>
                                <input type="number" name="cofinanciacion" class="form-control" step="0.01" min="0" value="0">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Notificación Inicio</label>
                                <input type="date" name="fecha_notif_inicio" class="form-control">
                                <div class="form-check mt-2">
                                    <input type="checkbox" name="notificacion_inicio" value="1" class="form-check-input" id="notif_inicio">
                                    <label class="form-check-label" for="notif_inicio">Notificación enviada</label>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Notificación Fin</label>
                                <input type="date" name="fecha_notif_fin" class="form-control">
                                <div class="form-check mt-2">
                                    <input type="checkbox" name="notificacion_fin" value="1" class="form-check-input" id="notif_fin">
                                    <label class="form-check-label" for="notif_fin">Notificación enviada</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección: Comercial -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-gift me-2"></i>Información Comercial</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Teleoperadora</label>
                                <select name="id_teleoperadora" class="form-select">
                                    <option value="">Seleccionar...</option>
                                    <?php foreach ($teleoperadoras as $t): ?>
                                    <option value="<?php echo $t['id']; ?>"
                                            <?php echo ($_SESSION['rol'] === 'agent' && $t['id'] == $_SESSION['user_id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($t['nombre'] . ' ' . ($t['apellidos'] ?? '')); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Regalo</label>
                                <select name="id_regalo" class="form-select">
                                    <option value="">Sin regalo</option>
                                    <?php foreach ($regalos as $r): ?>
                                    <option value="<?php echo $r['id']; ?>">
                                        <?php echo htmlspecialchars($r['nombre']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Envío Tarjeta</label>
                                <input type="date" name="fecha_envio_tarjeta" class="form-control">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Envío Regalo</label>
                                <input type="date" name="fecha_envio_regalo" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección: Moodle -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-key me-2"></i>Acceso Moodle</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Fecha Envío Claves</label>
                                <input type="date" name="fecha_envio_claves" class="form-control">
                                <div class="form-check mt-2">
                                    <input type="checkbox" name="envio_claves" value="1" class="form-check-input" id="envio_claves">
                                    <label class="form-check-label" for="envio_claves">Claves enviadas</label>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Fecha Claves No Oficial</label>
                                <input type="date" name="claves_no_oficial_fecha" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección: Comentarios -->
                <div class="card table-custom mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-comment me-2"></i>Observaciones</h5>
                    </div>
                    <div class="card-body">
                        <textarea name="comentario" class="form-control" rows="4"
                                  placeholder="Comentarios adicionales sobre el curso..."></textarea>
                    </div>
                </div>

                <!-- Botones -->
                <div class="text-end">
                    <a href="listado.php" class="btn btn-secondary btn-custom">
                        <i class="fas fa-times me-1"></i>Cancelar
                    </a>
                    <button type="submit" class="btn btn-gradient-success btn-custom">
                        <i class="fas fa-save me-1"></i>Crear Curso
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
// Toggle sidebar
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
});

$(document).ready(function() {
    // ========================================================================
    // INICIALIZAR SELECT2 PARA EMPRESAS (CON AJAX)
    // ========================================================================
    $('#empresa').select2({
        theme: 'bootstrap-5',
        width: '100%',
        placeholder: 'Escribe para buscar por CIF o nombre...',
        allowClear: true,
        minimumInputLength: 2,
        ajax: {
            url: 'ajax/buscar_empresas.php',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    q: params.term,
                    page: params.page || 1
                };
            },
            processResults: function(data, params) {
                params.page = params.page || 1;
                
                return {
                    results: data.results,
                    pagination: {
                        more: data.pagination.more
                    }
                };
            },
            cache: true
        },
        language: {
            inputTooShort: function() {
                return 'Escribe al menos 2 caracteres';
            },
            searching: function() {
                return 'Buscando...';
            },
            noResults: function() {
                return 'No se encontraron empresas';
            }
        }
    });
    
    // ========================================================================
    // INICIALIZAR SELECT2 PARA ALUMNOS (CON AJAX)
    // ========================================================================
    $('#alumno').select2({
        theme: 'bootstrap-5',
        width: '100%',
        placeholder: 'Escribe para buscar por DNI, nombre o email...',
        allowClear: true,
        minimumInputLength: 2,
        ajax: {
            url: 'ajax/buscar_alumnos.php',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    q: params.term,
                    page: params.page || 1
                };
            },
            processResults: function(data, params) {
                params.page = params.page || 1;
                
                return {
                    results: data.results,
                    pagination: {
                        more: data.pagination.more
                    }
                };
            },
            cache: true
        },
        language: {
            inputTooShort: function() {
                return 'Escribe al menos 2 caracteres';
            },
            searching: function() {
                return 'Buscando...';
            },
            noResults: function() {
                return 'No se encontraron alumnos';
            }
        }
    });
    
    // ========================================================================
    // SELECT2 NORMAL PARA CATÁLOGO DE CURSOS
    // ========================================================================
    $('#curso_catalogo').select2({
        theme: 'bootstrap-5',
        width: '100%',
        placeholder: 'Seleccionar curso...',
        allowClear: true
    });
    
    // ========================================================================
    // AUTO-COMPLETAR DATOS DEL CURSO SELECCIONADO
    // ========================================================================
    $('#curso_catalogo').on('change', function() {
        var option = $(this).find(':selected');
        if (option.val()) {
            $('#nombre_curso').val(option.data('nombre'));
            $('#horas_curso').val(option.data('horas'));
            $('#codigo_curso').val(option.data('codigo'));
            mostrarAutoguardado('Datos del curso cargados');
        }
    });
    
    // ========================================================================
    // AUTOGUARDADO EN LOCALSTORAGE
    // ========================================================================
    const STORAGE_KEY = 'crear_curso_draft';
    
    // Cargar draft si existe
    const draft = localStorage.getItem(STORAGE_KEY);
    if (draft) {
        try {
            const data = JSON.parse(draft);
            
            // Confirmar si quiere cargar el borrador
            if (confirm('Se encontró un borrador guardado. ¿Deseas cargarlo?')) {
                // Cargar campos de texto
                Object.keys(data).forEach(key => {
                    const field = document.querySelector(`[name="${key}"]`);
                    if (field && field.type !== 'select-one') {
                        field.value = data[key];
                    }
                });
                
                mostrarAutoguardado('Borrador cargado');
            } else {
                localStorage.removeItem(STORAGE_KEY);
            }
        } catch (e) {
            console.error('Error al cargar borrador:', e);
        }
    }
    
    // Guardar draft cada 5 segundos si hay cambios
    let cambiosRealizados = false;
    let autoguardadoTimeout;
    
    $('#formCrearCurso').on('change input', 'input, select, textarea', function() {
        cambiosRealizados = true;
        
        // Reiniciar timeout
        clearTimeout(autoguardadoTimeout);
        autoguardadoTimeout = setTimeout(function() {
            if (cambiosRealizados) {
                guardarBorrador();
                cambiosRealizados = false;
            }
        }, 2000); // Guardar después de 2 segundos de inactividad
    });
    
    function guardarBorrador() {
        const formData = {};
        $('#formCrearCurso').serializeArray().forEach(item => {
            formData[item.name] = item.value;
        });
        
        localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
        mostrarAutoguardado('Borrador guardado automáticamente');
    }
    
    // Limpiar draft al enviar
    $('#formCrearCurso').on('submit', function() {
        localStorage.removeItem(STORAGE_KEY);
    });
});

// ========================================================================
// MOSTRAR INDICADOR DE AUTOGUARDADO
// ========================================================================
function mostrarAutoguardado(mensaje) {
    const indicator = $('#autoguardado-indicator');
    const text = $('#autoguardado-text');
    
    text.text(mensaje);
    indicator.fadeIn(300);
    
    setTimeout(function() {
        indicator.fadeOut(300);
    }, 2000);
}

// ========================================================================
// VALIDACIÓN DEL FORMULARIO
// ========================================================================
document.getElementById('formCrearCurso').addEventListener('submit', function(e) {
    const required = ['nombre_curso', 'fecha_inicio', 'id_empresa', 'id_alumno'];
    let valid = true;
    
    required.forEach(field => {
        const input = document.querySelector(`[name="${field}"]`);
        if (!input.value) {
            input.classList.add('is-invalid');
            valid = false;
        } else {
            input.classList.remove('is-invalid');
        }
    });
    
    if (!valid) {
        e.preventDefault();
        alert('Por favor, completa todos los campos obligatorios marcados con *');
    }
});
</script>

</body>
</html>
