<?php
/**
 * AJAX: Matricular Usuario en Curso Moodle
 * Matricula un usuario ya creado en un curso específico
 */

require_once __DIR__ . '/../../includes/config_cursos.php';
require_once __DIR__ . '/../../includes/functions_cursos.php';
require_once INCLUDES_DIR . '/MoodleAPI.php';

header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Sesión no válida']);
    exit;
}

// Leer datos JSON
$input = json_decode(file_get_contents('php://input'), true);
$id_curso = isset($input['id_curso']) ? (int)$input['id_curso'] : 0;

if (!$id_curso) {
    echo json_encode(['success' => false, 'message' => 'ID de curso no válido']);
    exit;
}

try {
    // Obtener datos del curso
    $sql = "SELECT 
                c.*,
                cc.id_moodle as curso_id_moodle,
                mal.moodle_user_id
            FROM cursos c
            LEFT JOIN catalogo_cursos cc ON c.id_catalogo_curso = cc.id
            LEFT JOIN moodle_altas_log mal ON mal.id_curso = c.id
            WHERE c.id = ?
            ORDER BY mal.id DESC
            LIMIT 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id_curso);
    $stmt->execute();
    $curso = $stmt->get_result()->fetch_assoc();
    
    if (!$curso) {
        echo json_encode(['success' => false, 'message' => 'Curso no encontrado']);
        exit;
    }
    
    if (!$curso['moodle_user_id']) {
        echo json_encode([
            'success' => false,
            'message' => 'El usuario aún no ha sido creado en Moodle'
        ]);
        exit;
    }
    
    if (!$curso['curso_id_moodle']) {
        echo json_encode([
            'success' => false,
            'message' => 'El curso no tiene un ID de Moodle asociado'
        ]);
        exit;
    }
    
    // Crear conexión PDO para MoodleAPI
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    $moodle = new MoodleAPI($pdo);
    
    // Matricular usuario
    $result = $moodle->matricularUsuario(
        $curso['moodle_user_id'],
        $curso['curso_id_moodle']
    );
    
    if ($result['success']) {
        // Actualizar estado en BD
        $sql_update = "UPDATE cursos 
                      SET moodle_estado = 'matriculado',
                          moodle_matricula_fecha = NOW(),
                          moodle_error = NULL
                      WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param('i', $id_curso);
        $stmt_update->execute();
        
        // Actualizar log
        $sql_log_update = "UPDATE moodle_altas_log 
                          SET moodle_course_id = ?
                          WHERE id_curso = ? 
                          ORDER BY id DESC LIMIT 1";
        $stmt_log = $conn->prepare($sql_log_update);
        $stmt_log->bind_param('ii', $curso['curso_id_moodle'], $id_curso);
        $stmt_log->execute();
        
        echo json_encode([
            'success' => true,
            'message' => 'Usuario matriculado correctamente en el curso de Moodle'
        ]);
    } else {
        // Registrar error
        $sql_error = "UPDATE cursos 
                     SET moodle_estado = 'error',
                         moodle_error = ?
                     WHERE id = ?";
        $stmt_error = $conn->prepare($sql_error);
        $error_msg = substr($result['message'], 0, 500);
        $stmt_error->bind_param('si', $error_msg, $id_curso);
        $stmt_error->execute();
        
        echo json_encode([
            'success' => false,
            'message' => $result['message']
        ]);
    }
    
} catch (Exception $e) {
    // Registrar error
    $sql_error = "UPDATE cursos 
                 SET moodle_estado = 'error',
                     moodle_error = ?
                 WHERE id = ?";
    $stmt_error = $conn->prepare($sql_error);
    $error_msg = substr($e->getMessage(), 0, 500);
    $stmt_error->bind_param('si', $error_msg, $id_curso);
    $stmt_error->execute();
    
    echo json_encode([
        'success' => false,
        'message' => 'Error al matricular: ' . $e->getMessage()
    ]);
}
