<?php
/**
 * DIAGNÓSTICO DE ERROR 500 EN VER.PHP
 * 
 * INSTRUCCIONES:
 * 1. Guardar este archivo como: diagnostico_ver.php
 * 2. Subir a: /crm_llamadas/modulos/cursos/gestion_cursos/
 * 3. Acceder a: https://www.geae.es/crm_llamadas/modulos/cursos/gestion_cursos/diagnostico_ver.php?id=256
 * 4. Ver qué error muestra
 */

// Activar mostrar todos los errores
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

echo "<h1>Diagnóstico de ver.php</h1>";
echo "<hr>";

// Test 1: Verificar archivos requeridos
echo "<h2>1. Verificando archivos requeridos...</h2>";

$archivos = [
    '../includes/config_cursos.php',
    '../includes/functions_cursos.php'
];

foreach ($archivos as $archivo) {
    if (file_exists(__DIR__ . '/' . $archivo)) {
        echo "✅ <strong>$archivo</strong> - EXISTE<br>";
    } else {
        echo "❌ <strong>$archivo</strong> - NO EXISTE<br>";
    }
}

echo "<hr>";

// Test 2: Incluir archivos
echo "<h2>2. Intentando incluir archivos...</h2>";

try {
    require_once __DIR__ . '/../includes/config_cursos.php';
    echo "✅ config_cursos.php incluido correctamente<br>";
} catch (Exception $e) {
    echo "❌ Error en config_cursos.php: " . $e->getMessage() . "<br>";
}

try {
    require_once __DIR__ . '/../includes/functions_cursos.php';
    echo "✅ functions_cursos.php incluido correctamente<br>";
} catch (Exception $e) {
    echo "❌ Error en functions_cursos.php: " . $e->getMessage() . "<br>";
}

echo "<hr>";

// Test 3: Verificar conexión a BD
echo "<h2>3. Verificando conexión a base de datos...</h2>";

if (isset($conn)) {
    if ($conn->ping()) {
        echo "✅ Conexión a BD activa (mysqli)<br>";
    } else {
        echo "❌ Conexión a BD caída<br>";
    }
} else {
    echo "❌ Variable \$conn no existe<br>";
}

echo "<hr>";

// Test 4: Verificar parámetro ID
echo "<h2>4. Verificando parámetro ID...</h2>";

$id_curso = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id_curso > 0) {
    echo "✅ ID recibido: <strong>$id_curso</strong><br>";
} else {
    echo "❌ ID no válido o no recibido<br>";
}

echo "<hr>";

// Test 5: Consultar curso
echo "<h2>5. Intentando consultar curso...</h2>";

if ($id_curso > 0 && isset($conn)) {
    try {
        $sql = "SELECT c.*, 
                e.denominacion as empresa_nombre,
                a.nombre as alumno_nombre_completo,
                cc.nombre as catalogo_nombre
                FROM cursos c
                LEFT JOIN empresas e ON c.id_empresa = e.id
                LEFT JOIN alumnos a ON c.id_alumno = a.id
                LEFT JOIN catalogo_cursos cc ON c.id_catalogo_curso = cc.id
                WHERE c.id = ?";
        
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            echo "✅ Query preparado correctamente<br>";
            
            $stmt->bind_param('i', $id_curso);
            $stmt->execute();
            $curso = $stmt->get_result()->fetch_assoc();
            
            if ($curso) {
                echo "✅ Curso encontrado: <strong>" . htmlspecialchars($curso['nombre_curso']) . "</strong><br>";
                echo "<pre style='background:#f0f0f0; padding:10px; margin-top:10px;'>";
                echo "Datos del curso:\n";
                echo "- ID: " . $curso['id'] . "\n";
                echo "- Nombre: " . $curso['nombre_curso'] . "\n";
                echo "- Alumno: " . $curso['alumno_nombre_completo'] . "\n";
                echo "- Empresa: " . $curso['empresa_nombre'] . "\n";
                echo "- Estado: " . $curso['estado'] . "\n";
                if (isset($curso['moodle_estado'])) {
                    echo "- Moodle Estado: " . $curso['moodle_estado'] . "\n";
                }
                if (isset($curso['moodle_course_id'])) {
                    echo "- Moodle Course ID: " . $curso['moodle_course_id'] . "\n";
                }
                echo "</pre>";
            } else {
                echo "❌ Curso no encontrado con ID: $id_curso<br>";
            }
        } else {
            echo "❌ Error al preparar query: " . $conn->error . "<br>";
        }
        
    } catch (Exception $e) {
        echo "❌ Excepción al consultar: " . $e->getMessage() . "<br>";
    }
} else {
    echo "⚠️ No se puede consultar (ID no válido o sin conexión)<br>";
}

echo "<hr>";

// Test 6: Verificar funciones personalizadas
echo "<h2>6. Verificando funciones personalizadas...</h2>";

$funciones = ['formatFecha', 'verificarRolCursos', 'getNombreUsuarioActual'];

foreach ($funciones as $funcion) {
    if (function_exists($funcion)) {
        echo "✅ <strong>$funcion()</strong> - existe<br>";
    } else {
        echo "❌ <strong>$funcion()</strong> - NO existe<br>";
    }
}

echo "<hr>";

// Test 7: Verificar sesión
echo "<h2>7. Verificando sesión...</h2>";

if (session_status() === PHP_SESSION_ACTIVE) {
    echo "✅ Sesión activa<br>";
    
    if (isset($_SESSION['user_id'])) {
        echo "✅ Usuario logueado: ID " . $_SESSION['user_id'] . "<br>";
        if (isset($_SESSION['nombre'])) {
            echo "✅ Nombre: " . $_SESSION['nombre'] . "<br>";
        }
        if (isset($_SESSION['rol'])) {
            echo "✅ Rol: " . $_SESSION['rol'] . "<br>";
        }
    } else {
        echo "⚠️ No hay usuario en sesión<br>";
    }
} else {
    echo "❌ Sesión no activa<br>";
}

echo "<hr>";

// Test 8: Verificar tabla moodle_altas_log
echo "<h2>8. Verificando tabla moodle_altas_log...</h2>";

if (isset($conn)) {
    try {
        $check_table = $conn->query("SHOW TABLES LIKE 'moodle_altas_log'");
        
        if ($check_table && $check_table->num_rows > 0) {
            echo "✅ Tabla moodle_altas_log existe<br>";
            
            // Intentar consultar
            if ($id_curso > 0) {
                $sql_log = "SELECT COUNT(*) as total FROM moodle_altas_log WHERE id_curso = ?";
                $stmt_log = $conn->prepare($sql_log);
                $stmt_log->bind_param('i', $id_curso);
                $stmt_log->execute();
                $result_log = $stmt_log->get_result()->fetch_assoc();
                
                echo "✅ Registros en log para este curso: <strong>" . $result_log['total'] . "</strong><br>";
            }
        } else {
            echo "❌ Tabla moodle_altas_log NO existe<br>";
        }
    } catch (Exception $e) {
        echo "❌ Error al verificar tabla: " . $e->getMessage() . "<br>";
    }
}

echo "<hr>";

// Resumen final
echo "<h2>✅ RESUMEN</h2>";
echo "<p>Si todos los tests muestran ✅, entonces ver.php debería funcionar.</p>";
echo "<p>Si hay errores ❌, esos son los que causan el error 500.</p>";
echo "<p><a href='ver.php?id=$id_curso' style='padding:10px 20px; background:#007bff; color:white; text-decoration:none; border-radius:5px;'>Probar ver.php</a></p>";
?>
