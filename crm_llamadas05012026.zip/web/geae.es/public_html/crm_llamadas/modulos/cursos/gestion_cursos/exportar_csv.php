<?php
/**
 * Exportar Cursos a CSV
 * Exporta los cursos filtrados a formato CSV
 * NO REQUIERE LIBRERÍAS EXTERNAS
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos', 'agent']);

// Obtener filtros de la URL
$filtros = [];
if (!empty($_GET['id_teleoperadora'])) {
    $filtros['id_teleoperadora'] = (int)$_GET['id_teleoperadora'];
}
if (!empty($_GET['empresa'])) {
    $filtros['empresa'] = $_GET['empresa'];
}
if (!empty($_GET['estado'])) {
    $filtros['estado'] = $_GET['estado'];
}
if (!empty($_GET['mes_accion'])) {
    $filtros['mes_accion'] = $_GET['mes_accion'];
}
if (!empty($_GET['fecha_desde'])) {
    $filtros['fecha_desde'] = $_GET['fecha_desde'];
}
if (!empty($_GET['fecha_hasta'])) {
    $filtros['fecha_hasta'] = $_GET['fecha_hasta'];
}
if (!empty($_GET['busqueda'])) {
    $filtros['busqueda'] = $_GET['busqueda'];
}

// Si es agent, solo sus cursos
if ($_SESSION['rol'] === 'agent') {
    $filtros['id_teleoperadora'] = $_SESSION['user_id'];
}

// Obtener todos los cursos (sin paginación)
$resultado = getCursos($conn, $filtros, 1, 10000);
$cursos = $resultado['cursos'];

if (empty($cursos)) {
    die("No hay cursos para exportar con los filtros seleccionados.");
}

// Nombre del archivo
$filename = 'Cursos_FUNDAE_' . date('Y-m-d_His');
if (!empty($filtros['mes_accion'])) {
    $filename .= '_' . str_replace('-', '', $filtros['mes_accion']);
}
$filename .= '.csv';

// Headers para descarga
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

// Abrir salida
$output = fopen('php://output', 'w');

// BOM para UTF-8 (para que Excel lo abra correctamente)
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Encabezados
$headers = [
    'ID',
    'Mes Acción',
    'Estado',
    'CIF',
    'Empresa',
    'Representante Legal',
    'DNI Representante',
    'Contacto Admin',
    'Teléfono Admin',
    'Email Admin',
    'DNI Alumno',
    'Nombre Alumno',
    'Teléfono 1',
    'Email Alumno',
    'Código Curso',
    'Nombre Curso',
    'Horas',
    'Fecha Inicio',
    'Fecha Fin',
    'Crédito FUNDAE',
    'Cofinanciación',
    'ID FUNDAE',
    'Notif. Inicio',
    'Notif. Fin',
    'Regalo',
    'Envío Claves',
    'Teleoperadora',
    'Comentarios'
];

fputcsv($output, $headers, ';');

// Datos
foreach ($cursos as $curso) {
    $row = [
        $curso['id'],
        $curso['periodo_accion'] ?? '-',
        $curso['estado'],
        $curso['cif'],
        $curso['empresa'],
        $curso['representante_legal'] ?? '',
        $curso['dni_representante'] ?? '',
        $curso['contacto_administrativo'] ?? '',
        $curso['telefono_administrativo'] ?? '',
        $curso['email_administrativo'] ?? '',
        $curso['dni_alumno'],
        $curso['alumno'],
        $curso['telefono_1'] ?? '',
        $curso['email_alumno'] ?? '',
        $curso['codigo_curso'] ?? '',
        $curso['nombre_curso'],
        $curso['horas_curso'],
        $curso['fecha_inicio'] ? date('d/m/Y', strtotime($curso['fecha_inicio'])) : '',
        $curso['fecha_fin'] ? date('d/m/Y', strtotime($curso['fecha_fin'])) : '',
        number_format($curso['credito_formacion'], 2, ',', '.'),
        number_format($curso['cofinanciacion'], 2, ',', '.'),
        $curso['id_fundae'] ?? '',
        $curso['notificacion_inicio'] ? 'Sí' : 'No',
        $curso['notificacion_fin'] ? 'Sí' : 'No',
        $curso['regalo'] ?? '',
        $curso['envio_claves'] ? 'Sí' : 'No',
        $curso['teleoperadora'] ?? '',
        $curso['comentario'] ?? ''
    ];
    
    fputcsv($output, $row, ';');
}

fclose($output);
exit;
