<?php
/**
 * Listado de Cursos - Módulo FUNDAE
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos', 'agent']);

$id_usuario = $_SESSION['user_id'];
$rol = $_SESSION['rol'];

// Procesar filtros
$filtros = [];
if (!empty($_GET['id_teleoperadora'])) {
    $filtros['id_teleoperadora'] = (int)$_GET['id_teleoperadora'];
}
if (!empty($_GET['empresa'])) {
    $filtros['empresa'] = $_GET['empresa'];
}
if (!empty($_GET['estado'])) {
    $filtros['estado'] = $_GET['estado'];
}
if (!empty($_GET['mes_accion'])) {
    $filtros['mes_accion'] = $_GET['mes_accion'];
}
if (!empty($_GET['fecha_desde'])) {
    $filtros['fecha_desde'] = $_GET['fecha_desde'];
}
if (!empty($_GET['fecha_hasta'])) {
    $filtros['fecha_hasta'] = $_GET['fecha_hasta'];
}
if (!empty($_GET['busqueda'])) {
    $filtros['busqueda'] = $_GET['busqueda'];
}

// Si es agent, solo sus cursos
if ($rol === 'agent') {
    $filtros['id_teleoperadora'] = $id_usuario;
}

// Paginación
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 20;

// Obtener cursos
$resultado = getCursos($conn, $filtros, $page, $perPage);
$cursos = $resultado['cursos'];
$total = $resultado['total'];
$totalPages = $resultado['total_pages'];

// Obtener datos para filtros
$teleoperadoras = getTeleoperadoras($conn);

// Obtener meses disponibles
$sql_meses = "SELECT DISTINCT mes_accion, periodo_accion FROM cursos WHERE mes_accion IS NOT NULL ORDER BY mes_accion DESC";
$result_meses = $conn->query($sql_meses);
$meses_disponibles = [];
while ($row = $result_meses->fetch_assoc()) {
    $meses_disponibles[] = $row;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Cursos - FUNDAE</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/cursos.css">
</head>
<!-- Scripts Moodle --><script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script><script>function verCredencialesMoodle(idCurso) {    // Mostrar loading    Swal.fire({        title: 'Cargando...',        allowOutsideClick: false,        didOpen: () => {            Swal.showLoading();        }    });        // Hacer petición AJAX    fetch(`ajax/obtener_credenciales_moodle.php?id=${idCurso}`)        .then(response => response.json())        .then(data => {            if (data.success) {                Swal.fire({                    title: '<i class="fas fa-key me-2"></i>Credenciales Moodle',                    html: `                        <div class="text-start">                            <div class="alert alert-info">                                <strong><i class="fas fa-user me-1"></i> Usuario:</strong>                                 <code class="fs-6">${data.username}</code>                            </div>                            <div class="alert alert-secondary">                                <strong><i class="fas fa-envelope me-1"></i> Email:</strong>                                 ${data.email}                            </div>                            <div class="alert alert-primary">                                <strong><i class="fas fa-link me-1"></i> URL Moodle:</strong><br>                                <a href="${data.url_moodle}" target="_blank" class="btn btn-link">                                    ${data.url_moodle}                                </a>                            </div>                            <p class="text-muted small mt-3">                                <i class="fas fa-info-circle me-1"></i>                                La contraseña fue enviada por email al alumno                            </p>                            <hr>                            <div class="d-grid gap-2">                                <button onclick="reenviarCredenciales(${idCurso})" class="btn btn-warning">                                    <i class="fas fa-envelope me-2"></i>Reenviar Credenciales                                </button>                                <a href="${data.url_moodle}" target="_blank" class="btn btn-primary">                                    <i class="fas fa-external-link-alt me-2"></i>Abrir Moodle                                </a>                            </div>                        </div>                    `,                    icon: 'info',                    showConfirmButton: true,                    confirmButtonText: 'Cerrar',                    width: '600px'                });            } else {                Swal.fire('Error', data.message || 'No se pudieron obtener las credenciales', 'error');            }        })        .catch(error => {            Swal.fire('Error', 'Error de conexión', 'error');        });}
function reenviarCredenciales(idCurso) {    Swal.fire({        title: '¿Reenviar credenciales?',        text: 'Se enviará un email con las credenciales de acceso a Moodle',        icon: 'question',        showCancelButton: true,        confirmButtonText: 'Sí, reenviar',        cancelButtonText: 'Cancelar',        confirmButtonColor: '#ffc107',        cancelButtonColor: '#6c757d'    }).then((result) => {        if (result.isConfirmed) {            // Mostrar loading            Swal.fire({                title: 'Enviando...',                allowOutsideClick: false,                didOpen: () => {                    Swal.showLoading();                }            });                        fetch('ajax/moodle_reenviar_claves.php', {                method: 'POST',                headers: {'Content-Type': 'application/json'},                body: JSON.stringify({id_curso: idCurso})            })            .then(response => response.json())            .then(data => {                if (data.success) {                    Swal.fire({                        title: '¡Enviado!',                        text: data.message,                        icon: 'success',                        timer: 2000                    });                } else {                    Swal.fire('Error', data.message, 'error');                }            })            .catch(error => {                Swal.fire('Error', 'Error al enviar el email', 'error');            });        }    });}</script>
<body>

<div class="wrapper">
    <?php include 'sidebar.php'; ?>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-list me-2"></i>Listado de Cursos
                </span>
                
                <div class="ms-auto">
                    <a href="crear.php" class="btn btn-gradient-success btn-custom">
                        <i class="fas fa-plus-circle me-1"></i>Nuevo Curso
                    </a>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <!-- Filtros -->
            <div class="filter-card">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Búsqueda</label>
                        <input type="text" name="busqueda" class="form-control" 
                               placeholder="Curso, empresa, alumno..." 
                               value="<?php echo htmlspecialchars($_GET['busqueda'] ?? ''); ?>">
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label"><i class="fas fa-calendar-alt me-1"></i>Mes de Acción</label>
                        <select name="mes_accion" class="form-select">
                            <option value="">Todos los meses</option>
                            <?php foreach ($meses_disponibles as $mes): ?>
                            <option value="<?php echo $mes['mes_accion']; ?>" 
                                    <?php echo (isset($_GET['mes_accion']) && $_GET['mes_accion'] == $mes['mes_accion']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($mes['periodo_accion']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <?php if ($rol !== 'agent'): ?>
                    <div class="col-md-2">
                        <label class="form-label">Teleoperadora</label>
                        <select name="id_teleoperadora" class="form-select">
                            <option value="">Todas</option>
                            <?php foreach ($teleoperadoras as $t): ?>
                            <option value="<?php echo $t['id']; ?>" 
                                    <?php echo (isset($_GET['id_teleoperadora']) && $_GET['id_teleoperadora'] == $t['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($t['nombre'] . ' ' . ($t['apellidos'] ?? '')); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    
                    <div class="col-md-2">
                        <label class="form-label">Estado</label>
                        <select name="estado" class="form-select">
                            <option value="">Todos</option>
                            <option value="Pendiente" <?php echo (isset($_GET['estado']) && $_GET['estado'] == 'Pendiente') ? 'selected' : ''; ?>>Pendiente</option>
                            <option value="En Curso" <?php echo (isset($_GET['estado']) && $_GET['estado'] == 'En Curso') ? 'selected' : ''; ?>>En Curso</option>
                            <option value="Finalizado" <?php echo (isset($_GET['estado']) && $_GET['estado'] == 'Finalizado') ? 'selected' : ''; ?>>Finalizado</option>
                            <option value="Cancelado" <?php echo (isset($_GET['estado']) && $_GET['estado'] == 'Cancelado') ? 'selected' : ''; ?>>Cancelado</option>
                        </select>
                    </div>
                    
                    <div class="col-md-1 d-flex align-items-end">
                        <button type="submit" class="btn btn-gradient-primary btn-custom w-100">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>

            <!-- Tabla de Cursos -->
            <div class="card table-custom">
                <div class="card-header bg-white border-0 pt-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list-ul me-2"></i>
                            Cursos (<?php echo number_format($total); ?> registros)
                        </h5>
                        <div>
                            <a href="exportar_csv.php?<?php echo http_build_query($_GET); ?>" class="btn btn-success btn-sm btn-custom">
                                <i class="fas fa-file-csv me-1"></i>CSV
                            </a>
                            <a href="exportar_excel.php?<?php echo http_build_query($_GET); ?>" class="btn btn-success btn-sm btn-custom">
                                <i class="fas fa-file-excel me-1"></i>Excel
                            </a>
                            <button onclick="window.print()" class="btn btn-secondary btn-sm btn-custom">
                                <i class="fas fa-print me-1"></i>Imprimir
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>    <tr>        <th>ID</th>        <th>Mes</th>        <th>Curso</th>        <th>Empresa</th>        <th>Alumno</th>        <th>Teleoperadora</th>        <th>F. Inicio</th>        <th>Crédito</th>        <th>Estado</th>        <th width="120">Moodle</th>        <th class="text-center">Acciones</th>    </tr></thead>
                            <tbody>
                                <?php if (empty($cursos)): ?>
                                <tr>
                                    <td colspan="10" class="text-center py-5">
                                        <i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i>
                                        <p class="text-muted">No se encontraron cursos</p>
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach ($cursos as $curso): ?>
                                <tr>
                                    <td><?php echo $curso['id']; ?></td>
                                    <td>
                                        <span class="badge bg-info">
                                            <?php echo htmlspecialchars($curso['periodo_accion'] ?? '-'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($curso['nombre_curso']); ?></strong><br>
                                        <small class="text-muted"><?php echo $curso['horas_curso']; ?>h</small>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($curso['empresa']); ?><br>
                                        <small class="text-muted"><?php echo htmlspecialchars($curso['cif']); ?></small>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($curso['alumno']); ?><br>
                                        <small class="text-muted"><?php echo htmlspecialchars($curso['dni_alumno']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($curso['teleoperadora'] ?? '-'); ?></td>
                                    <td><?php echo formatFecha($curso['fecha_inicio']); ?></td>
                                    <td><?php echo formatMoneda($curso['credito_formacion']); ?></td>
                                    <td><?php echo getEstadoBadge($curso['estado']); ?></td>
                                    <td><?php echo getEstadoBadge($curso['estado']); ?></td>
<!-- COLUMNA MOODLE --><td>    <?php    $moodle_estado = $curso['moodle_estado'] ?? 'pendiente';    $badge_class = '';    $badge_text = '';    $icon = '';        switch($moodle_estado) {        case 'matriculado':            $badge_class = 'bg-success';            $badge_text = 'Matriculado';            $icon = '<i class="fas fa-check-circle me-1"></i>';            break;        case 'usuario_creado':            $badge_class = 'bg-info';            $badge_text = 'Usuario';            $icon = '<i class="fas fa-user-check me-1"></i>';            break;        case 'error':            $badge_class = 'bg-danger';            $badge_text = 'Error';            $icon = '<i class="fas fa-exclamation-triangle me-1"></i>';            break;        default:            $badge_class = 'bg-secondary';            $badge_text = 'Pendiente';            $icon = '<i class="fas fa-clock me-1"></i>';    }    ?>    <span class="badge <?php echo $badge_class; ?>" style="font-size: 0.7rem;">        <?php echo $icon . $badge_text; ?>    </span></td>
<td class="text-center">
                                    <td class="text-center">
                                      <div class="btn-group" role="group">    <a href="ver.php?id=<?php echo $curso['id']; ?>"        class="btn btn-sm btn-info" title="Ver detalle">        <i class="fas fa-eye"></i>    </a>    <a href="editar.php?id=<?php echo $curso['id']; ?>"        class="btn btn-sm btn-warning" title="Editar">        <i class="fas fa-edit"></i>    </a>        <!-- BOTÓN MOODLE -->    <?php if ($moodle_estado === 'pendiente' || $moodle_estado === 'error'): ?>    <a href="moodle_alta_individual.php?id=<?php echo $curso['id']; ?>"        class="btn btn-sm btn-success"        title="Alta en Moodle">        <i class="fas fa-cloud-upload-alt"></i>    </a>    <?php elseif ($moodle_estado === 'matriculado'): ?>    <button onclick="verCredencialesMoodle(<?php echo $curso['id']; ?>)"             class="btn btn-sm btn-primary"             title="Ver credenciales">        <i class="fas fa-key"></i>    </button>    <?php endif; ?>        <?php if ($rol === 'admin'): ?>    <button onclick="eliminarCurso(<?php echo $curso['id']; ?>)"             class="btn btn-sm btn-danger" title="Eliminar">        <i class="fas fa-trash"></i>    </button>    <?php endif; ?></div>  
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Paginación -->
                <?php if ($totalPages > 1): ?>
                <div class="card-footer bg-white border-0">
                    <nav>
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            </li>
                            <?php endif; ?>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                            <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
});

function eliminarCurso(id) {
    if (confirm('¿Estás seguro de eliminar este curso? Esta acción no se puede deshacer.')) {
        window.location.href = 'eliminar.php?id=' + id;
    }
}

function exportarExcel() {
    window.location.href = 'exportar.php?formato=excel&' + new URLSearchParams(<?php echo json_encode($_GET); ?>);
}
</script>

</body>
</html>
