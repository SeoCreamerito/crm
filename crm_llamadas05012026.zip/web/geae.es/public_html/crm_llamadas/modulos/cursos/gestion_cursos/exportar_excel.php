<?php
/**
 * Exportar Cursos a Excel
 * Exporta los cursos filtrados a formato Excel (.xlsx)
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos', 'agent']);

// Instalar PHPSpreadsheet si no existe
if (!class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
    // Intentar cargar desde autoload
    if (file_exists(__DIR__ . '/../../../vendor/autoload.php')) {
        require_once __DIR__ . '/../../../vendor/autoload.php';
    } else {
        die("ERROR: PHPSpreadsheet no está instalado. Ejecuta: composer require phpoffice/phpspreadsheet");
    }
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

// Obtener filtros de la URL
$filtros = [];
if (!empty($_GET['id_teleoperadora'])) {
    $filtros['id_teleoperadora'] = (int)$_GET['id_teleoperadora'];
}
if (!empty($_GET['empresa'])) {
    $filtros['empresa'] = $_GET['empresa'];
}
if (!empty($_GET['estado'])) {
    $filtros['estado'] = $_GET['estado'];
}
if (!empty($_GET['mes_accion'])) {
    $filtros['mes_accion'] = $_GET['mes_accion'];
}
if (!empty($_GET['fecha_desde'])) {
    $filtros['fecha_desde'] = $_GET['fecha_desde'];
}
if (!empty($_GET['fecha_hasta'])) {
    $filtros['fecha_hasta'] = $_GET['fecha_hasta'];
}
if (!empty($_GET['busqueda'])) {
    $filtros['busqueda'] = $_GET['busqueda'];
}

// Si es agent, solo sus cursos
if ($_SESSION['rol'] === 'agent') {
    $filtros['id_teleoperadora'] = $_SESSION['user_id'];
}

// Obtener todos los cursos (sin paginación)
$resultado = getCursos($conn, $filtros, 1, 10000);
$cursos = $resultado['cursos'];

if (empty($cursos)) {
    die("No hay cursos para exportar con los filtros seleccionados.");
}

// Crear Excel
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Establecer título
$sheet->setTitle('Cursos FUNDAE');

// ==========================================
// ENCABEZADOS
// ==========================================

$headers = [
    'A1' => 'ID',
    'B1' => 'Mes Acción',
    'C1' => 'Estado',
    'D1' => 'CIF',
    'E1' => 'Empresa',
    'F1' => 'Representante Legal',
    'G1' => 'DNI Representante',
    'H1' => 'Contacto Admin',
    'I1' => 'Teléfono Admin',
    'J1' => 'Email Admin',
    'K1' => 'DNI Alumno',
    'L1' => 'Nombre Alumno',
    'M1' => 'Teléfono 1',
    'N1' => 'Email Alumno',
    'O1' => 'Código Curso',
    'P1' => 'Nombre Curso',
    'Q1' => 'Horas',
    'R1' => 'Fecha Inicio',
    'S1' => 'Fecha Fin',
    'T1' => 'Crédito FUNDAE',
    'U1' => 'Cofinanciación',
    'V1' => 'ID FUNDAE',
    'W1' => 'Notif. Inicio',
    'X1' => 'Notif. Fin',
    'Y1' => 'Regalo',
    'Z1' => 'Envío Claves',
    'AA1' => 'Teleoperadora',
    'AB1' => 'Comentarios'
];

foreach ($headers as $cell => $value) {
    $sheet->setCellValue($cell, $value);
}

// Estilo de encabezados
$headerStyle = [
    'font' => [
        'bold' => true,
        'color' => ['rgb' => 'FFFFFF'],
        'size' => 11
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => '4472C4']
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical' => Alignment::VERTICAL_CENTER
    ],
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => '000000']
        ]
    ]
];

$sheet->getStyle('A1:AB1')->applyFromArray($headerStyle);

// Ajustar altura de fila de encabezados
$sheet->getRowDimension(1)->setRowHeight(25);

// ==========================================
// DATOS
// ==========================================

$row = 2;
foreach ($cursos as $curso) {
    $sheet->setCellValue('A' . $row, $curso['id']);
    $sheet->setCellValue('B' . $row, $curso['periodo_accion'] ?? '-');
    $sheet->setCellValue('C' . $row, $curso['estado']);
    $sheet->setCellValue('D' . $row, $curso['cif']);
    $sheet->setCellValue('E' . $row, $curso['empresa']);
    $sheet->setCellValue('F' . $row, $curso['representante_legal'] ?? '');
    $sheet->setCellValue('G' . $row, $curso['dni_representante'] ?? '');
    $sheet->setCellValue('H' . $row, $curso['contacto_administrativo'] ?? '');
    $sheet->setCellValue('I' . $row, $curso['telefono_administrativo'] ?? '');
    $sheet->setCellValue('J' . $row, $curso['email_administrativo'] ?? '');
    $sheet->setCellValue('K' . $row, $curso['dni_alumno']);
    $sheet->setCellValue('L' . $row, $curso['alumno']);
    $sheet->setCellValue('M' . $row, $curso['telefono_1'] ?? '');
    $sheet->setCellValue('N' . $row, $curso['email_alumno'] ?? '');
    $sheet->setCellValue('O' . $row, $curso['codigo_curso'] ?? '');
    $sheet->setCellValue('P' . $row, $curso['nombre_curso']);
    $sheet->setCellValue('Q' . $row, $curso['horas_curso']);
    $sheet->setCellValue('R' . $row, $curso['fecha_inicio'] ? date('d/m/Y', strtotime($curso['fecha_inicio'])) : '');
    $sheet->setCellValue('S' . $row, $curso['fecha_fin'] ? date('d/m/Y', strtotime($curso['fecha_fin'])) : '');
    $sheet->setCellValue('T' . $row, $curso['credito_formacion']);
    $sheet->setCellValue('U' . $row, $curso['cofinanciacion']);
    $sheet->setCellValue('V' . $row, $curso['id_fundae'] ?? '');
    $sheet->setCellValue('W' . $row, $curso['notificacion_inicio'] ? 'Sí' : 'No');
    $sheet->setCellValue('X' . $row, $curso['notificacion_fin'] ? 'Sí' : 'No');
    $sheet->setCellValue('Y' . $row, $curso['regalo'] ?? '');
    $sheet->setCellValue('Z' . $row, $curso['envio_claves'] ? 'Sí' : 'No');
    $sheet->setCellValue('AA' . $row, $curso['teleoperadora'] ?? '');
    $sheet->setCellValue('AB' . $row, $curso['comentario'] ?? '');
    
    // Aplicar color según estado
    $fillColor = 'FFFFFF';
    switch ($curso['estado']) {
        case 'Pendiente':
            $fillColor = 'FFF3CD';
            break;
        case 'En Curso':
            $fillColor = 'CCE5FF';
            break;
        case 'Finalizado':
            $fillColor = 'D4EDDA';
            break;
        case 'Cancelado':
            $fillColor = 'F8D7DA';
            break;
    }
    
    $sheet->getStyle('C' . $row)->applyFromArray([
        'fill' => [
            'fillType' => Fill::FILL_SOLID,
            'startColor' => ['rgb' => $fillColor]
        ]
    ]);
    
    $row++;
}

// ==========================================
// FORMATO
// ==========================================

// Formato de números
$lastRow = $row - 1;
$sheet->getStyle('T2:U' . $lastRow)->getNumberFormat()->setFormatCode('#,##0.00 €');

// Bordes en todas las celdas con datos
$sheet->getStyle('A1:AB' . $lastRow)->applyFromArray([
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => 'CCCCCC']
        ]
    ]
]);

// Ajustar ancho de columnas automáticamente
foreach (range('A', 'AB') as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

// ==========================================
// HOJA DE RESUMEN
// ==========================================

$resumenSheet = $spreadsheet->createSheet();
$resumenSheet->setTitle('Resumen');

$resumenSheet->setCellValue('A1', 'RESUMEN DE EXPORTACIÓN');
$resumenSheet->mergeCells('A1:D1');
$resumenSheet->getStyle('A1')->applyFromArray([
    'font' => ['bold' => true, 'size' => 16],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
]);

$resumenSheet->setCellValue('A3', 'Fecha de exportación:');
$resumenSheet->setCellValue('B3', date('d/m/Y H:i:s'));

$resumenSheet->setCellValue('A4', 'Usuario:');
$resumenSheet->setCellValue('B4', getNombreUsuarioActual());

$resumenSheet->setCellValue('A5', 'Total de cursos:');
$resumenSheet->setCellValue('B5', count($cursos));

// Estadísticas
$resumenSheet->setCellValue('A7', 'ESTADÍSTICAS POR ESTADO');
$resumenSheet->mergeCells('A7:C7');
$resumenSheet->getStyle('A7')->getFont()->setBold(true);

$estados = ['Pendiente' => 0, 'En Curso' => 0, 'Finalizado' => 0, 'Cancelado' => 0];
$creditoTotal = 0;

foreach ($cursos as $curso) {
    if (isset($estados[$curso['estado']])) {
        $estados[$curso['estado']]++;
    }
    $creditoTotal += $curso['credito_formacion'];
}

$resumenRow = 8;
foreach ($estados as $estado => $cantidad) {
    $resumenSheet->setCellValue('A' . $resumenRow, $estado);
    $resumenSheet->setCellValue('B' . $resumenRow, $cantidad);
    $resumenRow++;
}

$resumenSheet->setCellValue('A13', 'Crédito FUNDAE Total:');
$resumenSheet->setCellValue('B13', $creditoTotal);
$resumenSheet->getStyle('B13')->getNumberFormat()->setFormatCode('#,##0.00 €');
$resumenSheet->getStyle('A13:B13')->getFont()->setBold(true);

// Ajustar columnas
$resumenSheet->getColumnDimension('A')->setWidth(25);
$resumenSheet->getColumnDimension('B')->setWidth(20);

// ==========================================
// DESCARGAR
// ==========================================

// Nombre del archivo
$filename = 'Cursos_FUNDAE_' . date('Y-m-d_His');
if (!empty($filtros['mes_accion'])) {
    $filename .= '_' . str_replace('-', '', $filtros['mes_accion']);
}
$filename .= '.xlsx';

// Headers para descarga
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

// Escribir archivo
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
