<?php
/**
 * CAPTURADOR DE ERRORES - ver.php
 * Este archivo simula ver.php pero captura el error exacto
 */

// Activar TODOS los errores
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Función para capturar errores fatales
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        echo "<div style='background:#ff0000; color:white; padding:20px; margin:20px;'>";
        echo "<h2>🚨 ERROR FATAL CAPTURADO:</h2>";
        echo "<p><strong>Tipo:</strong> " . $error['type'] . "</p>";
        echo "<p><strong>Mensaje:</strong> " . $error['message'] . "</p>";
        echo "<p><strong>Archivo:</strong> " . $error['file'] . "</p>";
        echo "<p><strong>Línea:</strong> " . $error['line'] . "</p>";
        echo "</div>";
    }
});

echo "<h1>Simulando ver.php paso a paso...</h1><hr>";

try {
    // PASO 1: Includes
    echo "<h3>PASO 1: Incluyendo archivos...</h3>";
    require_once __DIR__ . '/../includes/config_cursos.php';
    echo "✅ config_cursos.php<br>";
    
    require_once __DIR__ . '/../includes/functions_cursos.php';
    echo "✅ functions_cursos.php<br>";
    echo "<hr>";
    
    // PASO 2: Verificar rol
    echo "<h3>PASO 2: Verificando rol...</h3>";
    verificarRolCursos(['admin', 'gestion_cursos']);
    echo "✅ Rol verificado<br>";
    echo "<hr>";
    
    // PASO 3: Obtener ID
    echo "<h3>PASO 3: Obteniendo ID del curso...</h3>";
    $id_curso = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if (!$id_curso) {
        echo "❌ <strong>PROBLEMA ENCONTRADO:</strong> No hay ID en la URL<br>";
        echo "⚠️ Accede con: ?id=256 al final de la URL<br>";
        echo "<hr>";
        die();
    }
    echo "✅ ID recibido: <strong>$id_curso</strong><br>";
    echo "<hr>";
    
    // PASO 4: Consultar curso
    echo "<h3>PASO 4: Consultando curso...</h3>";
    $sql = "SELECT c.*, 
            e.denominacion as empresa_nombre,
            e.cif as empresa_cif,
            a.nombre as alumno_nombre_completo,
            a.dni as alumno_dni,
            a.email as alumno_email,
            a.telefono_1 as alumno_telefono,
            cc.nombre as catalogo_nombre,
            cc.id_moodle as catalogo_id_moodle
            FROM cursos c
            LEFT JOIN empresas e ON c.id_empresa = e.id
            LEFT JOIN alumnos a ON c.id_alumno = a.id
            LEFT JOIN catalogo_cursos cc ON c.id_catalogo_curso = cc.id
            WHERE c.id = ?";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "❌ Error al preparar consulta: " . $conn->error . "<br>";
        die();
    }
    
    $stmt->bind_param('i', $id_curso);
    $stmt->execute();
    $curso = $stmt->get_result()->fetch_assoc();
    
    if (!$curso) {
        echo "❌ Curso no encontrado con ID: $id_curso<br>";
        die();
    }
    
    echo "✅ Curso encontrado: <strong>" . htmlspecialchars($curso['nombre_curso']) . "</strong><br>";
    echo "<hr>";
    
    // PASO 5: Verificar campo moodle_course_id
    echo "<h3>PASO 5: Verificando campo moodle_course_id...</h3>";
    if (array_key_exists('moodle_course_id', $curso)) {
        echo "✅ Campo moodle_course_id existe<br>";
        echo "Valor: " . ($curso['moodle_course_id'] ?? 'NULL') . "<br>";
    } else {
        echo "❌ <strong>PROBLEMA ENCONTRADO:</strong> Campo moodle_course_id NO existe en la consulta<br>";
        echo "⚠️ Ejecuta este SQL:<br>";
        echo "<pre style='background:#f0f0f0; padding:10px;'>";
        echo "ALTER TABLE `cursos` \n";
        echo "ADD COLUMN `moodle_course_id` int(11) DEFAULT NULL \n";
        echo "COMMENT 'ID del curso en Moodle' \n";
        echo "AFTER `moodle_error`;";
        echo "</pre>";
    }
    echo "<hr>";
    
    // PASO 6: Consultar moodle_altas_log
    echo "<h3>PASO 6: Consultando moodle_altas_log...</h3>";
    $sql_moodle = "SELECT mal.*, 
                   mc.url_base as moodle_url_base
                   FROM moodle_altas_log mal
                   LEFT JOIN moodle_configuracion mc ON 1=1
                   WHERE mal.id_curso = ?
                   ORDER BY mal.fecha_hora_local DESC
                   LIMIT 1";
    
    $stmt_moodle = $conn->prepare($sql_moodle);
    if (!$stmt_moodle) {
        echo "❌ Error al preparar consulta moodle: " . $conn->error . "<br>";
    } else {
        $stmt_moodle->bind_param('i', $id_curso);
        $stmt_moodle->execute();
        $moodle_data = $stmt_moodle->get_result()->fetch_assoc();
        
        if ($moodle_data) {
            echo "✅ Datos de Moodle encontrados<br>";
            echo "Username: " . ($moodle_data['username_moodle'] ?? 'N/A') . "<br>";
        } else {
            echo "⚠️ No hay datos de Moodle para este curso (normal si no se ha dado de alta)<br>";
        }
    }
    echo "<hr>";
    
    // PASO 7: Obtener configuración Moodle
    echo "<h3>PASO 7: Obteniendo configuración Moodle...</h3>";
    $sql_config = "SELECT * FROM moodle_configuracion LIMIT 1";
    $moodle_config = $conn->query($sql_config);
    
    if ($moodle_config && $moodle_config->num_rows > 0) {
        echo "✅ Configuración Moodle encontrada<br>";
    } else {
        echo "⚠️ No hay configuración Moodle (se usará URL por defecto)<br>";
    }
    echo "<hr>";
    
    // PASO 8: Simular historial
    echo "<h3>PASO 8: Consultando historial...</h3>";
    $sql_historial = "SELECT * FROM historial_cursos WHERE id_curso = ? ORDER BY fecha_accion DESC LIMIT 10";
    $stmt_hist = $conn->prepare($sql_historial);
    
    if ($stmt_hist) {
        $stmt_hist->bind_param('i', $id_curso);
        $stmt_hist->execute();
        $historial = $stmt_hist->get_result()->fetch_all(MYSQLI_ASSOC);
        echo "✅ Historial consultado: " . count($historial) . " registros<br>";
    } else {
        echo "⚠️ Tabla historial_cursos no existe o error: " . $conn->error . "<br>";
    }
    echo "<hr>";
    
    // RESUMEN FINAL
    echo "<h2 style='color:green;'>✅ TODOS LOS PASOS COMPLETADOS SIN ERRORES</h2>";
    echo "<p>Si este script funciona pero ver.php da error 500, el problema está en:</p>";
    echo "<ul>";
    echo "<li>Código HTML/JavaScript en ver.php</li>";
    echo "<li>Alguna función formatFecha() o similar</li>";
    echo "<li>Código agregado recientemente</li>";
    echo "</ul>";
    
    echo "<hr>";
    echo "<h3>Datos del curso cargados:</h3>";
    echo "<pre style='background:#f0f0f0; padding:15px;'>";
    print_r($curso);
    echo "</pre>";
    
    echo "<hr>";
    echo "<p><a href='ver.php?id=$id_curso' style='padding:15px 30px; background:#28a745; color:white; text-decoration:none; border-radius:5px; font-size:18px;'>🚀 Probar ver.php ahora</a></p>";
    
} catch (Exception $e) {
    echo "<div style='background:#ff0000; color:white; padding:20px; margin:20px;'>";
    echo "<h2>🚨 EXCEPCIÓN CAPTURADA:</h2>";
    echo "<p><strong>Mensaje:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Archivo:</strong> " . $e->getFile() . "</p>";
    echo "<p><strong>Línea:</strong> " . $e->getLine() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
    echo "</div>";
}
?>

<style>
body {
    font-family: Arial, sans-serif;
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background: #f5f5f5;
}
h1, h2, h3 { color: #333; }
hr { border: 0; border-top: 2px solid #ddd; margin: 20px 0; }
</style>
