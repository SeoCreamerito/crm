<?php
/**
 * AJAX: Obtener Credenciales Moodle
 * Retorna las credenciales de un curso dado su ID
 */

require_once __DIR__ . '/../../includes/config_cursos.php';
require_once __DIR__ . '/../../includes/functions_cursos.php';

header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Sesión no válida']);
    exit;
}

$id_curso = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id_curso) {
    echo json_encode(['success' => false, 'message' => 'ID de curso no válido']);
    exit;
}

try {
    // Obtener datos de Moodle
    $sql = "SELECT 
                c.id,
                c.moodle_user_id,
                c.moodle_estado,
                mal.username_moodle,
                mal.email,
                mal.moodle_course_id,
                mal.fecha_hora_local,
                mal.email_enviado
            FROM cursos c
            LEFT JOIN moodle_altas_log mal ON mal.id_curso = c.id
            WHERE c.id = ?
            ORDER BY mal.id DESC
            LIMIT 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id_curso);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if (!$result || !$result['username_moodle']) {
        echo json_encode([
            'success' => false, 
            'message' => 'No se encontraron credenciales para este curso'
        ]);
        exit;
    }
    
    // Obtener URL de Moodle desde configuración
    $sql_config = "SELECT valor FROM moodle_configuracion WHERE clave = 'url_moodle' LIMIT 1";
    $url_moodle = $conn->query($sql_config)->fetch_assoc()['valor'] ?? 'https://www.geae.es/plataforma';
    
    echo json_encode([
        'success' => true,
        'username' => $result['username_moodle'],
        'email' => $result['email'],
        'moodle_user_id' => $result['moodle_user_id'],
        'moodle_course_id' => $result['moodle_course_id'],
        'url_moodle' => $url_moodle,
        'fecha_alta' => $result['fecha_hora_local'],
        'email_enviado' => (bool)$result['email_enviado']
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error al obtener credenciales: ' . $e->getMessage()
    ]);
}
