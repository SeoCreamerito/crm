<?php
/**
 * Gestión de Alumnos - Módulo FUNDAE
 */

require_once __DIR__ . '/../includes/config_cursos.php';
require_once __DIR__ . '/../includes/functions_cursos.php';

verificarRolCursos(['admin', 'gestion_cursos']);

$mensaje = '';
$tipo_mensaje = '';

// Crear/Editar alumno
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!empty($_POST['id'])) {
            // Actualizar
            $sql = "UPDATE alumnos SET 
                    nombre = ?, dni = ?, telefono_1 = ?, telefono_2 = ?, email = ?,
                    id_puesto = ?, id_titulacion = ?,
                    actualizado_en = NOW()
                    WHERE id = ?";
            
            $stmt = $conn->prepare($sql);
            $id_puesto = !empty($_POST['id_puesto']) ? (int)$_POST['id_puesto'] : null;
            $id_titulacion = !empty($_POST['id_titulacion']) ? (int)$_POST['id_titulacion'] : null;
            
            $stmt->bind_param('sssssiiii',
                $_POST['nombre'], $_POST['dni'], $_POST['telefono_1'], $_POST['telefono_2'], $_POST['email'],
                $id_puesto, $id_titulacion,
                $_POST['id']
            );
            $stmt->execute();
            $mensaje = "Alumno actualizado correctamente";
            $tipo_mensaje = "success";
        } else {
            // Crear
            $sql = "INSERT INTO alumnos (
                    nombre, dni, telefono_1, telefono_2, email,
                    id_puesto, id_titulacion,
                    activo, creado_en
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW())";
            
            $stmt = $conn->prepare($sql);
            $id_puesto = !empty($_POST['id_puesto']) ? (int)$_POST['id_puesto'] : null;
            $id_titulacion = !empty($_POST['id_titulacion']) ? (int)$_POST['id_titulacion'] : null;
            
            $stmt->bind_param('sssssii',
                $_POST['nombre'], $_POST['dni'], $_POST['telefono_1'], $_POST['telefono_2'], $_POST['email'],
                $id_puesto, $id_titulacion
            );
            $stmt->execute();
            $mensaje = "Alumno creado correctamente";
            $tipo_mensaje = "success";
        }
    } catch (Exception $e) {
        $mensaje = "Error: " . $e->getMessage();
        $tipo_mensaje = "danger";
    }
}

// Eliminar alumno (desactivar)
if (isset($_GET['eliminar'])) {
    $sql = "UPDATE alumnos SET activo = 0 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $_GET['eliminar']);
    $stmt->execute();
    $mensaje = "Alumno desactivado correctamente";
    $tipo_mensaje = "success";
}

// Buscar alumnos
$busqueda = $_GET['busqueda'] ?? '';
$sql = "SELECT a.*, 
               cp.nombre as puesto_nombre,
               ct.nombre as titulacion_nombre,
               COUNT(c.id) as total_cursos 
        FROM alumnos a 
        LEFT JOIN cursos c ON a.id = c.id_alumno
        LEFT JOIN catalogo_puestos cp ON a.id_puesto = cp.id
        LEFT JOIN catalogo_titulaciones ct ON a.id_titulacion = ct.id
        WHERE a.activo = 1";

if ($busqueda) {
    $sql .= " AND (a.nombre LIKE ? OR a.dni LIKE ? OR a.email LIKE ?)";
}

$sql .= " GROUP BY a.id ORDER BY a.nombre ASC";

$stmt = $conn->prepare($sql);
if ($busqueda) {
    $search = "%$busqueda%";
    $stmt->bind_param('sss', $search, $search, $search);
}
$stmt->execute();
$alumnos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Obtener catálogos
$puestos = getPuestos($conn);
$titulaciones = getTitulaciones($conn);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Alumnos - FUNDAE</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/cursos.css">
</head>
<body>

<div class="wrapper">
    <?php include 'sidebar.php'; ?>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <button type="button" id="sidebarCollapse" class="btn btn-custom btn-sm">
                    <i class="fas fa-bars"></i>
                </button>
                
                <span class="navbar-brand ms-3">
                    <i class="fas fa-user-graduate me-2"></i>Gestión de Alumnos
                </span>
                
                <div class="ms-auto">
                    <button class="btn btn-gradient-success btn-custom" data-bs-toggle="modal" data-bs-target="#modalAlumno">
                        <i class="fas fa-plus-circle me-1"></i>Nuevo Alumno
                    </button>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <?php if ($mensaje): ?>
            <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show">
                <?php echo htmlspecialchars($mensaje); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <!-- Búsqueda -->
            <div class="filter-card mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-10">
                        <input type="text" name="busqueda" class="form-control" 
                               placeholder="Buscar por nombre, DNI o email..." 
                               value="<?php echo htmlspecialchars($busqueda); ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-gradient-primary btn-custom w-100">
                            <i class="fas fa-search me-1"></i>Buscar
                        </button>
                    </div>
                </form>
            </div>

            <!-- Tabla de Alumnos -->
            <div class="card table-custom">
                <div class="card-header bg-white border-0 pt-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list-ul me-2"></i>
                            Alumnos (<?php echo count($alumnos); ?> registros)
                        </h5>
                        <div>
                            <button onclick="exportarCSV()" class="btn btn-success btn-sm btn-custom">
                                <i class="fas fa-file-csv me-1"></i>Exportar CSV
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>DNI</th>
                                    <th>Nombre</th>
                                    <th>Teléfono</th>
                                    <th>Email</th>
                                    <th>Puesto</th>
                                    <th>Titulación</th>
                                    <th>Cursos</th>
                                    <th class="text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($alumnos)): ?>
                                <tr>
                                    <td colspan="9" class="text-center py-5">
                                        <i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i>
                                        <p class="text-muted">No se encontraron alumnos</p>
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach ($alumnos as $alumno): ?>
                                <tr>
                                    <td><?php echo $alumno['id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($alumno['dni']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($alumno['nombre']); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($alumno['telefono_1'] ?? '-'); ?>
                                        <?php if ($alumno['telefono_2']): ?>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($alumno['telefono_2']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($alumno['email'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($alumno['puesto_nombre'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($alumno['titulacion_nombre'] ?? '-'); ?></td>
                                    <td>
                                        <?php if ($alumno['total_cursos'] > 0): ?>
                                        <a href="listado.php?busqueda=<?php echo urlencode($alumno['nombre']); ?>" class="badge bg-primary">
                                            <?php echo $alumno['total_cursos']; ?> cursos
                                        </a>
                                        <?php else: ?>
                                        <span class="text-muted">0 cursos</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <button onclick='editarAlumno(<?php echo json_encode($alumno); ?>)' 
                                                    class="btn btn-sm btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php if ($alumno['total_cursos'] == 0): ?>
                                            <a href="?eliminar=<?php echo $alumno['id']; ?>" 
                                               onclick="return confirm('¿Eliminar este alumno?')"
                                               class="btn btn-sm btn-danger" title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Modal Alumno -->
<div class="modal fade" id="modalAlumno" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">
                        <i class="fas fa-user-graduate me-2"></i>
                        <span id="modalTitleText">Nuevo Alumno</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="alumno_id">
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Nombre Completo <span class="text-danger">*</span></label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">DNI <span class="text-danger">*</span></label>
                            <input type="text" name="dni" id="dni" class="form-control" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Teléfono 1</label>
                            <input type="text" name="telefono_1" id="telefono_1" class="form-control">
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Teléfono 2</label>
                            <input type="text" name="telefono_2" id="telefono_2" class="form-control">
                        </div>
                        
                        <div class="col-md-12">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" id="email" class="form-control">
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Puesto de Trabajo</label>
                            <select name="id_puesto" id="id_puesto" class="form-select">
                                <option value="">Seleccionar puesto...</option>
                                <?php foreach ($puestos as $puesto): ?>
                                <option value="<?php echo $puesto['id']; ?>">
                                    <?php echo htmlspecialchars($puesto['nombre']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Titulación</label>
                            <select name="id_titulacion" id="id_titulacion" class="form-select">
                                <option value="">Seleccionar titulación...</option>
                                <?php foreach ($titulaciones as $titulacion): ?>
                                <option value="<?php echo $titulacion['id']; ?>">
                                    <?php echo htmlspecialchars($titulacion['nombre']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-gradient-success">
                        <i class="fas fa-save me-1"></i>Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarCollapse').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
});

function editarAlumno(alumno) {
    document.getElementById('modalTitleText').textContent = 'Editar Alumno';
    document.getElementById('alumno_id').value = alumno.id;
    document.getElementById('nombre').value = alumno.nombre || '';
    document.getElementById('dni').value = alumno.dni || '';
    document.getElementById('telefono_1').value = alumno.telefono_1 || '';
    document.getElementById('telefono_2').value = alumno.telefono_2 || '';
    document.getElementById('email').value = alumno.email || '';
    document.getElementById('id_puesto').value = alumno.id_puesto || '';
    document.getElementById('id_titulacion').value = alumno.id_titulacion || '';
    
    new bootstrap.Modal(document.getElementById('modalAlumno')).show();
}

// Limpiar modal al cerrarlo
document.getElementById('modalAlumno').addEventListener('hidden.bs.modal', function() {
    document.getElementById('modalTitleText').textContent = 'Nuevo Alumno';
    document.querySelector('#modalAlumno form').reset();
    document.getElementById('alumno_id').value = '';
});

function exportarCSV() {
    const busqueda = new URLSearchParams(window.location.search).get('busqueda') || '';
    window.location.href = 'exportar_alumnos_csv.php?busqueda=' + encodeURIComponent(busqueda);
}
</script>

</body>
</html>

