<?php
/**
 * Funciones Auxiliares - Módulo de Cursos FUNDAE
 */

/**
 * Obtener todos los cursos con paginación y filtros
 */
function getCursos($conn, $filtros = [], $page = 1, $perPage = 20) {
    $offset = ($page - 1) * $perPage;
    $where = [];
    $params = [];
    $types = '';
    
    // Filtro por teleoperadora
    if (!empty($filtros['id_teleoperadora'])) {
        $where[] = "c.id_teleoperadora = ?";
        $params[] = $filtros['id_teleoperadora'];
        $types .= 'i';
    }
    
    // Filtro por empresa
    if (!empty($filtros['empresa'])) {
        $where[] = "e.denominacion LIKE ?";
        $params[] = '%' . $filtros['empresa'] . '%';
        $types .= 's';
    }
    
    // Filtro por estado
    if (!empty($filtros['estado'])) {
        $where[] = "c.estado = ?";
        $params[] = $filtros['estado'];
        $types .= 's';
    }
    
    // Filtro por mes de acción
    if (!empty($filtros['mes_accion'])) {
        $where[] = "c.mes_accion = ?";
        $params[] = $filtros['mes_accion'];
        $types .= 's';
    }
    
    // Filtro por fecha inicio
    if (!empty($filtros['fecha_desde'])) {
        $where[] = "c.fecha_inicio >= ?";
        $params[] = $filtros['fecha_desde'];
        $types .= 's';
    }
    
    if (!empty($filtros['fecha_hasta'])) {
        $where[] = "c.fecha_inicio <= ?";
        $params[] = $filtros['fecha_hasta'];
        $types .= 's';
    }
    
    // Filtro por búsqueda general
    if (!empty($filtros['busqueda'])) {
        $where[] = "(c.nombre_curso LIKE ? OR a.nombre LIKE ? OR e.denominacion LIKE ?)";
        $busqueda = '%' . $filtros['busqueda'] . '%';
        $params[] = $busqueda;
        $params[] = $busqueda;
        $params[] = $busqueda;
        $types .= 'sss';
    }
    
    $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
    
    // Consulta principal
    $sql = "
        SELECT 
            c.*,
            e.denominacion as empresa,
            e.cif,
            a.nombre as alumno,
            a.dni as dni_alumno,
            a.telefono_1,
            a.email as email_alumno,
            u.nombre as teleoperadora,
            cr.nombre as regalo,
            cp.nombre as puesto,
            ct.nombre as titulacion,
            c.mes_accion,
            c.periodo_accion,
            c.moodle_estado,
            c.moodle_user_id,
            c.moodle_matricula_fecha,
            c.moodle_error
        FROM cursos c
        LEFT JOIN empresas e ON c.id_empresa = e.id
        LEFT JOIN alumnos a ON c.id_alumno = a.id
        LEFT JOIN usuarios u ON c.id_teleoperadora = u.id
        LEFT JOIN catalogo_regalos cr ON c.id_regalo = cr.id
        LEFT JOIN catalogo_puestos cp ON a.id_puesto = cp.id
        LEFT JOIN catalogo_titulaciones ct ON a.id_titulacion = ct.id
        $whereClause
        ORDER BY c.creado_en DESC
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $perPage;
    $params[] = $offset;
    $types .= 'ii';
    
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    $cursos = [];
    while ($row = $result->fetch_assoc()) {
        $cursos[] = $row;
    }
    
    // Contar total
    $sqlCount = "
        SELECT COUNT(*) as total
        FROM cursos c
        LEFT JOIN empresas e ON c.id_empresa = e.id
        LEFT JOIN alumnos a ON c.id_alumno = a.id
        LEFT JOIN usuarios u ON c.id_teleoperadora = u.id
        $whereClause
    ";
    
    $stmtCount = $conn->prepare($sqlCount);
    if (!empty($where)) {
        // Eliminar los últimos dos parámetros (LIMIT y OFFSET)
        $paramsCount = array_slice($params, 0, -2);
        $typesCount = substr($types, 0, -2);
        $stmtCount->bind_param($typesCount, ...$paramsCount);
    }
    $stmtCount->execute();
    $total = $stmtCount->get_result()->fetch_assoc()['total'];
    
    return [
        'cursos' => $cursos,
        'total' => $total,
        'total_pages' => ceil($total / $perPage),
        'current_page' => $page
    ];
}

/**
 * Obtener un curso por ID
 */
function getCursoById($conn, $id) {
    $sql = "
        SELECT 
            c.*,
            e.cif,
            e.denominacion as empresa,
            e.representante_legal,
            e.dni_representante,
            e.contacto_administrativo,
            e.telefono_administrativo,
            e.email_administrativo,
            e.nombre_asesoria,
            e.telefono_asesoria,
            e.email_asesoria,
            a.dni as dni_alumno,
            a.nombre as alumno,
            a.telefono_1,
            a.telefono_2,
            a.email as email_alumno,
            u.nombre as teleoperadora,
            u.apellidos as teleoperadora_apellidos,
            cr.nombre as regalo,
            cp.nombre as puesto,
            ct.nombre as titulacion,
            cc.nombre as nombre_catalogo_curso,
            cc.codigo as codigo_catalogo,
            cc.horas as horas_catalogo,
            cc.id_moodle,
            cc.url_moodle,
            cc.modalidad as modalidad_catalogo
        FROM cursos c
        LEFT JOIN empresas e ON c.id_empresa = e.id
        LEFT JOIN alumnos a ON c.id_alumno = a.id
        LEFT JOIN usuarios u ON c.id_teleoperadora = u.id
        LEFT JOIN catalogo_regalos cr ON c.id_regalo = cr.id
        LEFT JOIN catalogo_puestos cp ON a.id_puesto = cp.id
        LEFT JOIN catalogo_titulaciones ct ON a.id_titulacion = ct.id
        LEFT JOIN catalogo_cursos cc ON c.id_catalogo_curso = cc.id
        WHERE c.id = ?
    ";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

/**
 * Obtener todas las teleoperadoras
 */
function getTeleoperadoras($conn) {
    $sql = "SELECT id, nombre, apellidos FROM usuarios WHERE rol IN ('agent', 'admin') AND activo = 1 ORDER BY nombre";
    $result = $conn->query($sql);
    $teleoperadoras = [];
    while ($row = $result->fetch_assoc()) {
        $teleoperadoras[] = $row;
    }
    return $teleoperadoras;
}

/**
 * Obtener todas las empresas
 */
function getEmpresas($conn, $limit = null) {
    $sql = "SELECT id, cif, denominacion FROM empresas WHERE activo = 1 ORDER BY denominacion";
    if ($limit) {
        $sql .= " LIMIT $limit";
    }
    $result = $conn->query($sql);
    $empresas = [];
    while ($row = $result->fetch_assoc()) {
        $empresas[] = $row;
    }
    return $empresas;
}

/**
 * Obtener todos los alumnos
 */
function getAlumnos($conn, $limit = null) {
    $sql = "SELECT id, nombre, dni, email FROM alumnos WHERE activo = 1 ORDER BY nombre";
    if ($limit) {
        $sql .= " LIMIT $limit";
    }
    $result = $conn->query($sql);
    $alumnos = [];
    while ($row = $result->fetch_assoc()) {
        $alumnos[] = $row;
    }
    return $alumnos;
}

/**
 * Obtener catálogo de regalos
 */
function getRegalos($conn) {
    $sql = "SELECT id, nombre, valor_aproximado FROM catalogo_regalos WHERE activo = 1 ORDER BY nombre";
    $result = $conn->query($sql);
    $regalos = [];
    while ($row = $result->fetch_assoc()) {
        $regalos[] = $row;
    }
    return $regalos;
}

/**
 * Obtener catálogo de puestos
 */
function getPuestos($conn) {
    $sql = "SELECT id, nombre FROM catalogo_puestos WHERE activo = 1 ORDER BY orden, nombre";
    $result = $conn->query($sql);
    $puestos = [];
    while ($row = $result->fetch_assoc()) {
        $puestos[] = $row;
    }
    return $puestos;
}

/**
 * Obtener catálogo de titulaciones
 */
function getTitulaciones($conn) {
    $sql = "SELECT id, nombre FROM catalogo_titulaciones WHERE activo = 1 ORDER BY nivel, orden, nombre";
    $result = $conn->query($sql);
    $titulaciones = [];
    while ($row = $result->fetch_assoc()) {
        $titulaciones[] = $row;
    }
    return $titulaciones;
}

/**
 * Obtener catálogo de cursos
 */
function getCatalogoCursos($conn) {
    $sql = "SELECT id, codigo, nombre, horas, id_moodle, url_moodle, modalidad, descripcion 
            FROM catalogo_cursos 
            WHERE activo = 1 
            ORDER BY nombre";
    $result = $conn->query($sql);
    
    if (!$result) {
        // Si hay error (tabla no existe aún), retornar array vacío
        return [];
    }
    
    $cursos = [];
    while ($row = $result->fetch_assoc()) {
        $cursos[] = $row;
    }
    return $cursos;
}

/**
 * Obtener estadísticas del dashboard
 */
function getEstadisticasDashboard($conn, $id_teleoperadora = null) {
    $where = $id_teleoperadora ? "WHERE id_teleoperadora = $id_teleoperadora" : "";
    
    $sql = "
        SELECT 
            COUNT(*) as total_cursos,
            SUM(CASE WHEN estado = 'Pendiente' THEN 1 ELSE 0 END) as pendientes,
            SUM(CASE WHEN estado = 'En Curso' THEN 1 ELSE 0 END) as en_curso,
            SUM(CASE WHEN estado = 'Finalizado' THEN 1 ELSE 0 END) as finalizados,
            SUM(CASE WHEN estado = 'Cancelado' THEN 1 ELSE 0 END) as cancelados,
            SUM(credito_formacion) as credito_total,
            SUM(cofinanciacion) as cofinanciacion_total,
            COUNT(CASE WHEN envio_claves = 0 AND fecha_inicio BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 1 END) as claves_pendientes,
            COUNT(CASE WHEN fecha_envio_tarjeta IS NULL AND id_regalo IS NOT NULL THEN 1 END) as regalos_pendientes,
            COUNT(CASE WHEN notificacion_inicio = 0 AND fecha_inicio < CURDATE() THEN 1 END) as notificaciones_pendientes
        FROM cursos
        $where
    ";
    
    $result = $conn->query($sql);
    return $result->fetch_assoc();
}

/**
 * Obtener historial de un curso
 */
function getHistorialCurso($conn, $id_curso) {
    // Verificar si la tabla existe
    $check = $conn->query("SHOW TABLES LIKE 'historial_cursos'");
    if ($check->num_rows === 0) {
        // La tabla no existe, retornar array vacío
        return [];
    }
    
    // Verificar estructura de la tabla
    $columns = $conn->query("SHOW COLUMNS FROM historial_cursos");
    $has_id_usuario = false;
    
    while ($col = $columns->fetch_assoc()) {
        if ($col['Field'] === 'id_usuario') {
            $has_id_usuario = true;
            break;
        }
    }
    
    if (!$has_id_usuario) {
        // Si no tiene id_usuario, buscar alternativas
        $sql = "
            SELECT 
                h.*
            FROM historial_cursos h
            WHERE h.id_curso = ?
            ORDER BY h.fecha_accion DESC
        ";
    } else {
        // Si tiene id_usuario, hacer JOIN con usuarios
        $sql = "
            SELECT 
                h.*,
                u.nombre as usuario_nombre,
                u.apellidos as usuario_apellidos
            FROM historial_cursos h
            LEFT JOIN usuarios u ON h.id_usuario = u.id
            WHERE h.id_curso = ?
            ORDER BY h.fecha_accion DESC
        ";
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id_curso);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $historial = [];
    while ($row = $result->fetch_assoc()) {
        $historial[] = $row;
    }
    return $historial;
}

/**
 * Formatear fecha
 */
function formatFecha($fecha) {
    if (!$fecha) return '-';
    return date('d/m/Y', strtotime($fecha));
}

/**
 * Formatear moneda
 */
function formatMoneda($cantidad) {
    if (!$cantidad) return '0,00 €';
    return number_format($cantidad, 2, ',', '.') . ' €';
}

/**
 * Obtener badge de estado
 */
function getEstadoBadge($estado) {
    $badges = [
        'Pendiente' => 'warning',
        'En Curso' => 'primary',
        'Finalizado' => 'success',
        'Cancelado' => 'danger'
    ];
    $color = $badges[$estado] ?? 'secondary';
    return "<span class='badge bg-$color'>$estado</span>";
}

/**
 * Registrar acción en historial
 */
function registrarHistorial($conn, $id_curso, $id_usuario, $accion, $observaciones = null) {
    // Verificar si la tabla existe
    $check = @$conn->query("SHOW TABLES LIKE 'historial_cursos'");
    if (!$check || $check->num_rows === 0) {
        // La tabla no existe, no hacer nada (evitar error)
        return false;
    }
    
    try {
        $sql = "INSERT INTO historial_cursos (id_curso, id_usuario, accion, observaciones) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('iiss', $id_curso, $id_usuario, $accion, $observaciones);
        return $stmt->execute();
    } catch (Exception $e) {
        // Silenciar error si la tabla no existe
        return false;
    }
}
