<?php
/**
 * Configuración del Módulo de Cursos FUNDAE
 * Integrado con CRM GEAE
 */

// Activar errores para debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Iniciar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Incluir configuración principal del CRM
$config_path = __DIR__ . '/../../../includes/config.php';

if (!file_exists($config_path)) {
    die("ERROR: No se encuentra el archivo config.php en: $config_path<br>
         Por favor, verifica la ruta de instalación.");
}

try {
    require_once $config_path;
} catch (Exception $e) {
    die("ERROR al cargar config.php: " . $e->getMessage());
}

// Incluir configuración de rutas
require_once __DIR__ . '/rutas.php';

// Verificar que existe la conexión a BD
if (!isset($conn)) {
    die("ERROR: La variable \$conn no está definida en config.php<br>
         Verifica que config.php crea la conexión a la base de datos.");
}

// Funciones de verificación de rol
function verificarRolCursos($rolesPermitidos = ['admin', 'gestion_cursos']) {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['rol'])) {
        // Redirigir a login del CRM
        header('Location: ' . CRM_LOGIN_URL);
        exit;
    }
    
    if (!in_array($_SESSION['rol'], $rolesPermitidos)) {
        // Redirigir al dashboard principal del CRM
        header('Location: ' . CRM_INDEX_URL);
        exit;
    }
}

// Función para obtener el nombre del usuario actual
function getNombreUsuarioActual() {
    if (isset($_SESSION['nombre'])) {
        $apellidos = isset($_SESSION['apellidos']) ? ' ' . $_SESSION['apellidos'] : '';
        return $_SESSION['nombre'] . $apellidos;
    }
    return 'Usuario';
}
