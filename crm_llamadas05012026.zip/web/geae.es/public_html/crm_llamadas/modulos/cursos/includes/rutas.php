<?php
/**
 * Configuración de Rutas - Módulo Cursos FUNDAE
 * Define todas las rutas del sistema
 */

// Ruta base del CRM
define('CRM_BASE_URL', '/crm_llamadas');

// Rutas del módulo de cursos
define('CURSOS_BASE_URL', CRM_BASE_URL . '/modulos/cursos/gestion_cursos');

// Rutas del CRM principal
define('CRM_INDEX_URL', CRM_BASE_URL . '/index.php');
define('CRM_LOGIN_URL', CRM_BASE_URL . '/login.php');
define('CRM_LOGOUT_URL', CRM_BASE_URL . '/logout.php');

// Rutas de assets
define('CURSOS_CSS_URL', CRM_BASE_URL . '/modulos/cursos/assets/css');
define('CURSOS_JS_URL', CRM_BASE_URL . '/modulos/cursos/assets/js');
define('CURSOS_IMG_URL', CRM_BASE_URL . '/modulos/cursos/assets/images');

// Función helper para generar URLs del módulo
function cursos_url($path = '') {
    return CURSOS_BASE_URL . ($path ? '/' . ltrim($path, '/') : '');
}

// Función helper para generar URLs del CRM
function crm_url($path = '') {
    return CRM_BASE_URL . ($path ? '/' . ltrim($path, '/') : '');
}
