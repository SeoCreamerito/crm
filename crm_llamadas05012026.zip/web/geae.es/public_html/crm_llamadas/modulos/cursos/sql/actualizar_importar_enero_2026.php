<?php
/**
 * ACTUALIZAR E IMPORTAR CSV ENERO 2026
 * Actualiza registros existentes y agrega nuevos sin duplicar
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

// ==========================================
// CONFIGURACIÓN
// ==========================================

$config = [
    'host' => 'localhost',
    'user' => 'geae_crm_llamadas',
    'pass' => '&4222SFCrb1975',
    'db'   => 'geae_crm_llamadas',
    'csv_file' => __DIR__ . '/cursosonline.csv', // Ruta al CSV actualizado
    'delimiter' => ';',
    'encoding' => 'UTF-8'
];

// ==========================================
// CONEXIÓN
// ==========================================

$conn = new mysqli($config['host'], $config['user'], $config['pass'], $config['db']);
if ($conn->connect_error) {
    die("ERROR: No se pudo conectar a la base de datos: " . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

echo "<h1>Actualización e Importación de Cursos Enero 2026</h1>";
echo "<hr>";

// ==========================================
// PASO 1: LEER CSV
// ==========================================

echo "<h2>PASO 1: Leyendo archivo CSV...</h2>";

if (!file_exists($config['csv_file'])) {
    die("ERROR: No se encuentra el archivo CSV en: {$config['csv_file']}");
}

$file = fopen($config['csv_file'], 'r');
if (!$file) {
    die("ERROR: No se pudo abrir el archivo CSV");
}

// Detectar encoding
$first_line = fgets($file);
rewind($file);
if (!mb_check_encoding($first_line, 'UTF-8')) {
    stream_filter_append($file, 'convert.iconv.ISO-8859-1/UTF-8');
}

// Leer encabezados
$headers = fgetcsv($file, 0, $config['delimiter']);
if (!$headers) {
    die("ERROR: No se pudieron leer los encabezados del CSV");
}

echo "✓ CSV abierto correctamente<br>";
echo "✓ Columnas encontradas: " . count($headers) . "<br>";
echo "<hr>";

// ==========================================
// PASO 2: PROCESAR REGISTROS
// ==========================================

echo "<h2>PASO 2: Procesando registros...</h2>";

$estadisticas = [
    'total' => 0,
    'actualizados' => 0,
    'nuevos' => 0,
    'errores' => 0,
    'empresas_creadas' => 0,
    'alumnos_creados' => 0
];

$errores = [];
$linea = 1;

// Preparar mapeo de columnas
$col_map = array_flip($headers);

while (($data = fgetcsv($file, 0, $config['delimiter'])) !== false) {
    $linea++;
    $estadisticas['total']++;
    
    try {
        // Crear array asociativo
        $row = array_combine($headers, $data);
        
        // ==========================================
        // VALIDAR DATOS MÍNIMOS
        // ==========================================
        
        $cif = trim($row['CIF'] ?? '');
        $dni = trim($row['DNI ALUMNO'] ?? '');
        $nombre_curso = trim($row['NOMBRE CURSO'] ?? '');
        
        if (empty($cif) || empty($dni) || empty($nombre_curso)) {
            $errores[] = "Línea $linea: Faltan datos obligatorios (CIF, DNI o Nombre Curso)";
            $estadisticas['errores']++;
            continue;
        }
        
        // ==========================================
        // BUSCAR/CREAR EMPRESA
        // ==========================================
        
        $sql_empresa = "SELECT id FROM empresas WHERE cif = ?";
        $stmt = $conn->prepare($sql_empresa);
        $stmt->bind_param('s', $cif);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $id_empresa = $result->fetch_assoc()['id'];
        } else {
            // Crear empresa
            $sql_insert_empresa = "
                INSERT INTO empresas (
                    cif, denominacion, representante_legal, dni_representante,
                    contacto_administrativo, telefono_administrativo, email_administrativo,
                    nombre_asesoria, telefono_asesoria, email_asesoria,
                    activo, creado_en
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())
            ";
            
            $stmt_empresa = $conn->prepare($sql_insert_empresa);
            $stmt_empresa->bind_param(
                'ssssssssss',
                $cif,
                $row['DENOMINACIÓN'] ?? '',
                $row['REPRESENTANTE LEGAL'] ?? '',
                $row['DNI REPRESENTANTE'] ?? '',
                $row['CONTACTO ADMINISTRATIVO'] ?? '',
                $row['TELEFONO ADMINISTRATIVO'] ?? '',
                $row['EMAIL ADMINISTRATIVO'] ?? '',
                $row['NOMBRE ASESORIA'] ?? '',
                $row['TELEFONO ASESORIA'] ?? '',
                $row['EMAIL ASESORIA'] ?? ''
            );
            $stmt_empresa->execute();
            $id_empresa = $conn->insert_id;
            $estadisticas['empresas_creadas']++;
        }
        
        // ==========================================
        // BUSCAR/CREAR ALUMNO
        // ==========================================
        
        $sql_alumno = "SELECT id FROM alumnos WHERE dni = ?";
        $stmt = $conn->prepare($sql_alumno);
        $stmt->bind_param('s', $dni);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $id_alumno = $result->fetch_assoc()['id'];
        } else {
            // Crear alumno
            $sql_insert_alumno = "
                INSERT INTO alumnos (
                    dni, nombre, telefono_1, telefono_2, email, activo, creado_en
                ) VALUES (?, ?, ?, ?, ?, 1, NOW())
            ";
            
            $stmt_alumno = $conn->prepare($sql_insert_alumno);
            $stmt_alumno->bind_param(
                'sssss',
                $dni,
                $row['NOMBRE ALUMNO'] ?? '',
                $row['TELEFONO 1'] ?? '',
                $row['TELEFONO 2'] ?? '',
                $row['EMAIL ALUMNO'] ?? ''
            );
            $stmt_alumno->execute();
            $id_alumno = $conn->insert_id;
            $estadisticas['alumnos_creados']++;
        }
        
        // ==========================================
        // VERIFICAR SI EL CURSO YA EXISTE
        // ==========================================
        
        // Criterio de duplicado: misma empresa + mismo alumno + mismo curso + misma fecha inicio
        $fecha_inicio = !empty($row['FECHA INICIO']) ? date('Y-m-d', strtotime($row['FECHA INICIO'])) : null;
        
        $sql_check = "
            SELECT id FROM cursos 
            WHERE id_empresa = ? 
            AND id_alumno = ? 
            AND nombre_curso = ?
            AND (fecha_inicio = ? OR (fecha_inicio IS NULL AND ? IS NULL))
            LIMIT 1
        ";
        
        $stmt = $conn->prepare($sql_check);
        $stmt->bind_param('iisss', $id_empresa, $id_alumno, $nombre_curso, $fecha_inicio, $fecha_inicio);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // ==========================================
            // ACTUALIZAR CURSO EXISTENTE
            // ==========================================
            
            $id_curso = $result->fetch_assoc()['id'];
            
            $sql_update = "
                UPDATE cursos SET
                    codigo_curso = ?,
                    horas_curso = ?,
                    fecha_fin = ?,
                    credito_formacion = ?,
                    cofinanciacion = ?,
                    comentario = ?,
                    mes_accion = '2026-01',
                    anio_accion = 2026,
                    periodo_accion = 'Enero 2026',
                    actualizado_en = NOW()
                WHERE id = ?
            ";
            
            $fecha_fin = !empty($row['FECHA FIN']) ? date('Y-m-d', strtotime($row['FECHA FIN'])) : null;
            $horas = !empty($row['HORAS']) ? (int)$row['HORAS'] : null;
            $credito = !empty($row['CREDITO FORMACION']) ? (float)str_replace(',', '.', $row['CREDITO FORMACION']) : 0;
            $cofinanciacion = !empty($row['COFINANCIACION']) ? (float)str_replace(',', '.', $row['COFINANCIACION']) : 0;
            
            $stmt = $conn->prepare($sql_update);
            $stmt->bind_param(
                'sisddssi',
                $row['CODIGO CURSO'] ?? '',
                $horas,
                $fecha_fin,
                $credito,
                $cofinanciacion,
                $row['COMENTARIOS'] ?? '',
                $id_curso
            );
            $stmt->execute();
            
            $estadisticas['actualizados']++;
            
        } else {
            // ==========================================
            // INSERTAR NUEVO CURSO
            // ==========================================
            
            $sql_insert = "
                INSERT INTO cursos (
                    id_empresa, id_alumno,
                    codigo_curso, nombre_curso, horas_curso,
                    fecha_inicio, fecha_fin,
                    credito_formacion, cofinanciacion,
                    comentario, estado,
                    mes_accion, anio_accion, periodo_accion,
                    creado_en
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pendiente', '2026-01', 2026, 'Enero 2026', NOW())
            ";
            
            $stmt = $conn->prepare($sql_insert);
            $stmt->bind_param(
                'iissisdds',
                $id_empresa,
                $id_alumno,
                $row['CODIGO CURSO'] ?? '',
                $nombre_curso,
                $horas,
                $fecha_inicio,
                $fecha_fin,
                $credito,
                $cofinanciacion,
                $row['COMENTARIOS'] ?? ''
            );
            $stmt->execute();
            
            $estadisticas['nuevos']++;
        }
        
    } catch (Exception $e) {
        $errores[] = "Línea $linea: " . $e->getMessage();
        $estadisticas['errores']++;
    }
}

fclose($file);

// ==========================================
// PASO 3: RESULTADOS
// ==========================================

echo "<h2>PASO 3: Resultados</h2>";
echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; border-left: 4px solid #28a745;'>";
echo "<h3>✓ Importación Completada</h3>";
echo "<p><strong>Total de registros procesados:</strong> {$estadisticas['total']}</p>";
echo "<p><strong>Cursos actualizados:</strong> {$estadisticas['actualizados']}</p>";
echo "<p><strong>Cursos nuevos creados:</strong> {$estadisticas['nuevos']}</p>";
echo "<p><strong>Empresas nuevas creadas:</strong> {$estadisticas['empresas_creadas']}</p>";
echo "<p><strong>Alumnos nuevos creados:</strong> {$estadisticas['alumnos_creados']}</p>";
echo "<p><strong>Errores:</strong> {$estadisticas['errores']}</p>";
echo "</div>";

if (!empty($errores)) {
    echo "<h3 style='color: #dc3545;'>Errores encontrados:</h3>";
    echo "<ul>";
    foreach ($errores as $error) {
        echo "<li>" . htmlspecialchars($error) . "</li>";
    }
    echo "</ul>";
}

// ==========================================
// PASO 4: VERIFICACIÓN
// ==========================================

echo "<hr>";
echo "<h2>PASO 4: Verificación en Base de Datos</h2>";

// Contar cursos de Enero 2026
$result = $conn->query("
    SELECT 
        COUNT(*) as total,
        SUM(credito_formacion) as credito_total
    FROM cursos 
    WHERE mes_accion = '2026-01'
");
$totales = $result->fetch_assoc();

echo "<div style='background: #cce5ff; padding: 15px; border-radius: 5px; border-left: 4px solid #007bff;'>";
echo "<p><strong>Cursos de Enero 2026 en BD:</strong> {$totales['total']}</p>";
echo "<p><strong>Crédito FUNDAE Total:</strong> " . number_format($totales['credito_total'], 2, ',', '.') . " €</p>";
echo "</div>";

// Mostrar algunos ejemplos
echo "<h3>Últimos 5 cursos importados/actualizados:</h3>";
$result = $conn->query("
    SELECT 
        c.id,
        c.nombre_curso,
        e.denominacion as empresa,
        a.nombre as alumno,
        c.fecha_inicio,
        c.credito_formacion,
        c.actualizado_en
    FROM cursos c
    LEFT JOIN empresas e ON c.id_empresa = e.id
    LEFT JOIN alumnos a ON c.id_alumno = a.id
    WHERE c.mes_accion = '2026-01'
    ORDER BY c.actualizado_en DESC
    LIMIT 5
");

echo "<table border='1' cellpadding='8' style='border-collapse: collapse; width: 100%;'>";
echo "<tr style='background: #007bff; color: white;'>";
echo "<th>ID</th><th>Curso</th><th>Empresa</th><th>Alumno</th><th>F. Inicio</th><th>Crédito</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>{$row['id']}</td>";
    echo "<td>" . htmlspecialchars($row['nombre_curso']) . "</td>";
    echo "<td>" . htmlspecialchars($row['empresa']) . "</td>";
    echo "<td>" . htmlspecialchars($row['alumno']) . "</td>";
    echo "<td>" . date('d/m/Y', strtotime($row['fecha_inicio'])) . "</td>";
    echo "<td>" . number_format($row['credito_formacion'], 2, ',', '.') . " €</td>";
    echo "</tr>";
}
echo "</table>";

$conn->close();

echo "<hr>";
echo "<h2>✓ Proceso Completado</h2>";
echo "<p>Puedes verificar los datos en el dashboard: <a href='../gestion_cursos/'>Ver Dashboard</a></p>";
?>
