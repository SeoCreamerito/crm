<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (isLoggedIn()) {
    switch ($_SESSION['rol']) {
        case 'admin':
            header("Location: admin/dashboard.php");
            break;
        case 'agent':
            header("Location: agent/panel.php");
            break;
        case 'inspeccion':
            header("Location: inspeccion/fichajes_consulta.php");
            break;
        case 'gestion_cursos':
            header("Location: admin/dashboard.php"); // placeholder
            break;
        default:
            header("Location: auth/logout.php");
    }
} else {
    header("Location: auth/login.php");
}
exit;
?>