<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
requireLogin();
requireRole('agent');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo_pausa = $_POST['tipo_pausa'] ?? 'otro';
    
    // ✅ Usar la sesión activa (no id_usuario)
    $sesion_id = session_id();
    
    // ✅ Insertar en pausas con campos correctos
    $conexion->query("
        INSERT INTO pausas (id_sesion, tipo_pausa, hora_inicio)
        VALUES ('$sesion_id', '$tipo_pausa', NOW())
    ");
    
    // Redirigir a temporizador o volver
    header("Location: gestionar_lead.php");
    exit;
}
?>