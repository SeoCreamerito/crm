<?php
// fix_session.php - Script para reparar la sesión actual
// Guardar en: /agent/fix_session.php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';

echo "<h1>Reparar Sesión</h1>";

// Verificar sesión actual
echo "<h2>Estado Actual de la Sesión:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

// Si hay user_id, obtener todos los datos del usuario
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conexion->prepare("SELECT id, nombre, email, rol, activo FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        echo "<h2>✅ Usuario encontrado en BD:</h2>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Campo</th><th>Valor</th></tr>";
        foreach ($user as $key => $value) {
            echo "<tr><td><strong>$key</strong></td><td>$value</td></tr>";
        }
        echo "</table>";
        
        // Actualizar/completar sesión con TODOS los datos necesarios
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['nombre'];
        $_SESSION['nombre'] = $user['nombre'];
        $_SESSION['user_rol'] = $user['rol'];
        $_SESSION['rol'] = $user['rol'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['activo'] = $user['activo'];
        
        echo "<h2>✅ Sesión actualizada:</h2>";
        echo "<pre>";
        print_r($_SESSION);
        echo "</pre>";
        
        echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
        echo "<h3 style='color: #155724; margin: 0 0 10px 0;'>✅ Sesión reparada correctamente</h3>";
        echo "<p style='margin: 0;'>Todos los datos de sesión han sido actualizados desde la base de datos.</p>";
        echo "</div>";
        
        echo "<div style='margin: 20px 0;'>";
        echo "<a href='gestionar_lead.php' style='display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin: 5px;'>Ir a Gestionar Lead</a> ";
        echo "<a href='panel.php' style='display: inline-block; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; margin: 5px;'>Ir al Panel</a>";
        echo "</div>";
        
    } else {
        echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
        echo "<p style='color: #721c24; margin: 0;'>❌ No se encontró el usuario con ID $user_id en la base de datos</p>";
        echo "</div>";
    }
} else {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
    echo "<p style='color: #721c24; margin: 0;'>❌ No hay sesión activa (no existe user_id)</p>";
    echo "</div>";
    echo "<p><a href='../auth/login.php' style='display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;'>Ir al Login</a></p>";
}

// Información adicional
echo "<hr>";
echo "<h2>Información de PHP:</h2>";
echo "<ul>";
echo "<li><strong>Versión PHP:</strong> " . phpversion() . "</li>";
echo "<li><strong>Estado Sesión:</strong> " . (session_status() === PHP_SESSION_ACTIVE ? 'Activa' : 'No activa') . "</li>";
echo "<li><strong>ID Sesión:</strong> " . session_id() . "</li>";
echo "</ul>";
?>