<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';
require_once '../includes/auth.php';

requireLogin();
requireRole('agent');

$teleoperadora_id = $_SESSION['user_id'];

if (!isset($conexion)) {
    die("Error: No hay conexión a la base de datos");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: gestionar_lead.php?error=metodo_invalido");
    exit;
}

$lead_id = (int)($_POST['lead_id'] ?? 0);
$estado_id = (int)($_POST['estado_id'] ?? 0);
$notas = trim($_POST['notas'] ?? '');
$verificado = isset($_POST['verificado']) ? 1 : 0;
$fecha_programada = $_POST['fecha_programada'] ?? null;
$id_programacion = (int)($_POST['id_programacion'] ?? 0); // ID de la programación anterior

if (!$lead_id || !$estado_id) {
    header("Location: gestionar_lead.php?error=datos_requeridos");
    exit;
}

try {
    $conexion->begin_transaction();

    // 1. Verificar que el lead pertenece a la teleoperadora
    $stmt = $conexion->prepare("
        SELECT * FROM leads_activos 
        WHERE id = ? AND id_teleoperadora = ?
    ");
    $stmt->bind_param("ii", $lead_id, $teleoperadora_id);
    $stmt->execute();
    $lead = $stmt->get_result()->fetch_assoc();
    
    if (!$lead) {
        throw new Exception("Lead no encontrado o no autorizado");
    }

    // 2. Obtener información del estado
    $stmt = $conexion->prepare("SELECT * FROM estados_llamada WHERE id = ?");
    $stmt->bind_param("i", $estado_id);
    $stmt->execute();
    $estado = $stmt->get_result()->fetch_assoc();
    
    if (!$estado) {
        throw new Exception("Estado no válido");
    }

    // 3. INSERTAR EN HISTORIAL (con desde_tabla en el orden correcto)
    $stmt = $conexion->prepare("
        INSERT INTO historial_llamadas (
            id_lead,
            desde_tabla,
            id_teleoperadora,
            estado_anterior,
            estado_nuevo,
            notas,
            verificado,
            telefono_usado,
            fecha_llamada
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $estado_anterior = 'Lead en gestión';
    $desde_tabla = 'leads_activos';
    
    $stmt->bind_param(
        "isisssis",
        $lead_id,
        $desde_tabla,
        $teleoperadora_id,
        $estado_anterior,
        $estado['nombre'],
        $notas,
        $verificado,
        $lead['telefono1']
    );
    $stmt->execute();

    // 4. ACTUALIZAR VERIFICADO en el lead
    if ($verificado) {
        $stmt = $conexion->prepare("UPDATE leads_activos SET verificado = 1 WHERE id = ?");
        $stmt->bind_param("i", $lead_id);
        $stmt->execute();
    }

    // 5. MARCAR COMO COMPLETADA la llamada programada anterior (si existe)
    if ($id_programacion > 0) {
        $stmt = $conexion->prepare("UPDATE llamadas_programadas SET completada = 1 WHERE id = ?");
        $stmt->bind_param("i", $id_programacion);
        $stmt->execute();
    }

    // 6. LÓGICA SEGÚN ESTADO
    switch ($estado_id) {
        case 1: // 1 No Contesta
            $stmt = $conexion->prepare("
                UPDATE leads_activos 
                SET intentos_no_contesta = 1 
                WHERE id = ?
            ");
            $stmt->bind_param("i", $lead_id);
            $stmt->execute();
            
            if ($fecha_programada) {
                $stmt = $conexion->prepare("
                    INSERT INTO llamadas_programadas 
                    (id_lead, desde_tabla, id_teleoperadora, fecha_programada, estado_programado, completada)
                    VALUES (?, ?, ?, ?, ?, 0)
                ");
                $desde_tabla_prog = 'leads_activos';
                $estado_prog = '1 No Contesta';
                $stmt->bind_param("isiss", $lead_id, $desde_tabla_prog, $teleoperadora_id, $fecha_programada, $estado_prog);
                $stmt->execute();
            }
            break;

        case 2: // 2 No Contesta
            $stmt = $conexion->prepare("
                UPDATE leads_activos 
                SET intentos_no_contesta = 2 
                WHERE id = ?
            ");
            $stmt->bind_param("i", $lead_id);
            $stmt->execute();
            
            if ($fecha_programada) {
                $stmt = $conexion->prepare("
                    INSERT INTO llamadas_programadas 
                    (id_lead, desde_tabla, id_teleoperadora, fecha_programada, estado_programado, completada)
                    VALUES (?, ?, ?, ?, ?, 0)
                ");
                $desde_tabla_prog = 'leads_activos';
                $estado_prog = '2 No Contesta';
                $stmt->bind_param("isiss", $lead_id, $desde_tabla_prog, $teleoperadora_id, $fecha_programada, $estado_prog);
                $stmt->execute();
            }
            break;

        case 3: // 3 No Contesta - MOVER A TABLA FINAL
            moverATablaFinal($conexion, $lead, 'leads_no_contesta', $lead_id);
            break;

        default:
            // Verificar si es estado FINAL
            if ($estado['tipo'] === 'final' && !empty($estado['tabla_destino'])) {
                moverATablaFinal($conexion, $lead, $estado['tabla_destino'], $lead_id);
            }
            // Verificar si es estado PROGRAMABLE
            elseif ($estado['tipo'] === 'programable' && $fecha_programada) {
                $stmt = $conexion->prepare("
                    INSERT INTO llamadas_programadas 
                    (id_lead, desde_tabla, id_teleoperadora, fecha_programada, estado_programado, completada)
                    VALUES (?, ?, ?, ?, ?, 0)
                ");
                $desde_tabla_prog = 'leads_activos';
                $stmt->bind_param("isiss", $lead_id, $desde_tabla_prog, $teleoperadora_id, $fecha_programada, $estado['nombre']);
                $stmt->execute();
            }
            break;
    }

    $conexion->commit();
    
    // Redirigir al siguiente lead
    header("Location: gestionar_lead.php?success=1");
    exit;

} catch (Exception $e) {
    if (isset($conexion)) {
        $conexion->rollback();
    }
    error_log("Error en procesar_estado.php: " . $e->getMessage());
    header("Location: gestionar_lead.php?error=error_interno&detalle=" . urlencode($e->getMessage()));
    exit;
}

/**
 * Función para mover un lead a una tabla final
 * EXCLUYE el campo 'id' para evitar conflictos con auto_increment
 */
function moverATablaFinal($conexion, $lead, $tabla_destino, $lead_id) {
    // Lista de campos a copiar (EXCLUYENDO 'id')
    $campos_copiar = [
        'actividad', 'empresa', 'tipovia', 'direccion', 'numerocalle',
        'poblacion', 'provincia', 'cp', 'telefono1', 'telefono2',
        'cnaecod', 'comunidad', 'facturacion', 'nr_trabajadores', 'cif',
        'gerentes_autonomos', 'cautonoma', 'codoperador', 'razonoperador',
        'id_teleoperadora', 'intentos_no_contesta', 'verificado'
    ];
    
    // Construir INSERT
    $columns = implode(', ', $campos_copiar);
    $placeholders = implode(', ', array_fill(0, count($campos_copiar), '?'));
    
    $sql = "INSERT INTO `$tabla_destino` ($columns) VALUES ($placeholders)";
    $stmt = $conexion->prepare($sql);
    
    if (!$stmt) {
        throw new Exception("Error al preparar INSERT en $tabla_destino: " . $conexion->error);
    }
    
    // Preparar valores
    $valores = [];
    foreach ($campos_copiar as $campo) {
        $valores[] = $lead[$campo] ?? null;
    }
    
    // Tipos: todos string excepto id_teleoperadora, intentos_no_contesta, verificado (int)
    $tipos = str_repeat('s', count($campos_copiar));
    $tipos = str_replace(
        ['s', 's', 's'], // Posiciones 19, 20, 21
        ['i', 'i', 'i'],
        $tipos,
        19 // Empieza en posición 19 (id_teleoperadora)
    );
    
    $stmt->bind_param($tipos, ...$valores);
    $stmt->execute();
    
    // Eliminar de leads_activos
    $stmt = $conexion->prepare("DELETE FROM leads_activos WHERE id = ?");
    $stmt->bind_param("i", $lead_id);
    $stmt->execute();
}
