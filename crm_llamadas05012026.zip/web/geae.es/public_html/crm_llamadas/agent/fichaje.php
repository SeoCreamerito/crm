<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();
requireRole('agent');

$id_agente = $_SESSION['user_id'];

// Verificar si ya tiene una sesión activa
$sesion_activa = null;
$stmt = $conexion->prepare("
    SELECT id, fecha_entrada, fecha_salida 
    FROM sesiones_actividad 
    WHERE id_usuario = ? AND fecha_salida IS NULL 
    ORDER BY fecha_entrada DESC LIMIT 1
");
$stmt->bind_param("i", $id_agente);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $sesion_activa = $row;
}

// Registrar entrada manual
if (isset($_POST['fichar_entrada'])) {
    if (!$sesion_activa) {
        $stmt = $conexion->prepare("INSERT INTO sesiones_actividad (id_usuario, fecha_entrada) VALUES (?, NOW())");
        $stmt->bind_param("i", $id_agente);
        $stmt->execute();
        header("Location: fichaje.php?ok=1");
        exit;
    }
}

// Registrar salida
if (isset($_POST['fichar_salida']) && $sesion_activa) {
    $stmt = $conexion->prepare("UPDATE sesiones_actividad SET fecha_salida = NOW() WHERE id = ?");
    $stmt->bind_param("i", $sesion_activa['id']);
    $stmt->execute();
    header("Location: fichaje.php?salida=1");
    exit;
}

// Iniciar pausa
if (isset($_POST['iniciar_pausa']) && $sesion_activa) {
    $tipo = $_POST['tipo_pausa'];
    $stmt = $conexion->prepare("INSERT INTO pausas (id_sesion, tipo, hora_inicio) VALUES (?, ?, NOW())");
    $stmt->bind_param("is", $sesion_activa['id'], $tipo);
    $stmt->execute();
    header("Location: fichaje.php?pausa=1");
    exit;
}

// Finalizar última pausa abierta
if (isset($_POST['finalizar_pausa']) && $sesion_activa) {
    $stmt = $conexion->prepare("
        UPDATE pausas 
        SET hora_fin = NOW() 
        WHERE id_sesion = ? AND hora_fin IS NULL 
        ORDER BY hora_inicio DESC LIMIT 1
    ");
    $stmt->bind_param("i", $sesion_activa['id']);
    $stmt->execute();
    header("Location: fichaje.php?pausa_fin=1");
    exit;
}

// Registrar horas extra
if (isset($_POST['registrar_he'])) {
    $stmt = $conexion->prepare("
        INSERT INTO horas_extra (id_usuario, fecha, horas, motivo, tipo) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "isdds", 
        $id_agente, 
        $_POST['he_fecha'], 
        $_POST['he_horas'], 
        $_POST['he_motivo'], 
        $_POST['he_tipo']
    );
    $stmt->execute();
    header("Location: fichaje.php?he=1");
    exit;
}

// Obtener pausas de la sesión actual
$pausas = [];
if ($sesion_activa) {
    $stmt = $conexion->prepare("SELECT * FROM pausas WHERE id_sesion = ? ORDER BY hora_inicio DESC");
    $stmt->bind_param("i", $sesion_activa['id']);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($p = $res->fetch_assoc()) {
        $pausas[] = $p;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Fichaje - <?= htmlspecialchars($_SESSION['nombre']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .jornada-activa { background-color: #d1ecf1; padding: 15px; border-radius: 8px; }
        .jornada-cerrada { background-color: #e9ecef; padding: 15px; border-radius: 8px; }
        .pausa-activa { background-color: #fff3cd; }
    </style>
<!-- 🔹 AÑADIDO: CSS personalizado -->    
<link rel="stylesheet" href="/crm_llamadas/assets/css/main.css">
</head>
<body>
<div class="container mt-4">
    <h2>⏱️ Mi Fichaje Diario</h2>

    <?php if (isset($_GET['ok'])): ?>
        <div class="alert alert-success">✅ Entrada registrada correctamente.</div>
    <?php elseif (isset($_GET['salida'])): ?>
        <div class="alert alert-success">✅ Salida registrada. ¡Hasta mañana!</div>
        <script>setTimeout(() => { window.location.href = '../auth/logout.php'; }, 3000);</script>
    <?php elseif (isset($_GET['pausa'])): ?>
        <div class="alert alert-info">⏸️ Pausa iniciada.</div>
    <?php elseif (isset($_GET['pausa_fin'])): ?>
        <div class="alert alert-info">⏯️ Pausa finalizada.</div>
    <?php elseif (isset($_GET['he'])): ?>
        <div class="alert alert-success">✅ Solicitud de horas extra enviada para aprobación.</div>
    <?php endif; ?>

    <?php if (!$sesion_activa || !$sesion_activa['fecha_salida']): ?>
        <div class="<?= $sesion_activa ? 'jornada-activa' : '' ?>">
            <?php if (!$sesion_activa): ?>
                <h4>¿Aún no has fichado entrada?</h4>
                <form method="POST">
                    <button type="submit" name="fichar_entrada" class="btn btn-success">✅ Fichar Entrada Ahora</button>
                </form>
            <?php else: ?>
                <h4>Jornada en curso</h4>
                <p><strong>Entrada:</strong> <?= date('d/m/Y H:i', strtotime($sesion_activa['fecha_entrada'])) ?></p>
                
                <!-- Pausas -->
                <h5>Pausas</h5>
                <?php if (!empty($pausas) && $pausas[0]['hora_fin'] === null): ?>
                    <div class="alert alert-warning pausa-activa">
                        ⏸️ Pausa <strong><?= $pausas[0]['tipo'] ?></strong> iniciada a las <?= date('H:i', strtotime($pausas[0]['hora_inicio'])) ?>
                        <form method="POST" class="mt-2">
                            <button type="submit" name="finalizar_pausa" class="btn btn-warning btn-sm">⏯️ Finalizar Pausa</button>
                        </form>
                    </div>
                <?php else: ?>
                    <form method="POST" class="mb-3">
                        <div class="row g-2">
                            <div class="col-md-3">
                                <select name="tipo_pausa" class="form-select" required>
                                    <option value="">Tipo de pausa</option>
                                    <option value="descanso">Descanso</option>
                                    <option value="pausa_visual">Pausa Visual</option>
                                    <option value="otros">Otros</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" name="iniciar_pausa" class="btn btn-outline-primary btn-sm">⏸️ Iniciar Pausa</button>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>

                <!-- Historial de pausas -->
                <?php if (!empty($pausas)): ?>
                    <details>
                        <summary>Ver historial de pausas</summary>
                        <ul>
                            <?php foreach ($pausas as $p): ?>
                                <li>
                                    <?= $p['tipo'] ?>: 
                                    <?= date('H:i', strtotime($p['hora_inicio'])) ?> - 
                                    <?= $p['hora_fin'] ? date('H:i', strtotime($p['hora_fin'])) : 'en curso' ?>
                                    <?php if ($p['duracion_minutos']): ?> (<?= $p['duracion_minutos'] ?> min)<?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </details>
                <?php endif; ?>

                <!-- Fichar salida -->
                <form method="POST" class="mt-4">
                    <button type="submit" name="fichar_salida" class="btn btn-danger"
                            onclick="return confirm('¿Confirmas que finalizas tu jornada?')">
                        🚪 Fichar Salida
                    </button>
                </form>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="jornada-cerrada">
            <h4>Jornada finalizada</h4>
            <p><strong>Entrada:</strong> <?= date('d/m/Y H:i', strtotime($sesion_activa['fecha_entrada'])) ?></p>
            <p><strong>Salida:</strong> <?= date('d/m/Y H:i', strtotime($sesion_activa['fecha_salida'])) ?></p>
            <a href="panel.php" class="btn btn-primary">← Volver a mi panel</a>
        </div>
    <?php endif; ?>

    <!-- Registrar horas extra -->
    <div class="card mt-4">
        <div class="card-header bg-warning text-dark">
            ⏳ Registrar Horas Extra
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="row g-2">
                    <div class="col-md-2">
                        <label>Fecha</label>
                        <input type="date" name="he_fecha" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label>Horas</label>
                        <input type="number" step="0.25" min="0.25" name="he_horas" class="form-control" required>
                    </div>
                    <div class="col-md-2">
                        <label>Tipo</label>
                        <select name="he_tipo" class="form-select" required>
                            <option value="pagadas">Se pagarán</option>
                            <option value="compensadas">Se compensarán</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>Motivo</label>
                        <input type="text" name="he_motivo" class="form-control" placeholder="Motivo de las horas extra" required>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" name="registrar_he" class="btn btn-warning w-100">Enviar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- 🔹 AÑADIDO: JS personalizado -->    
<script src="/crm_llamadas/assets/js/main.js"></script>
</body>
</html>