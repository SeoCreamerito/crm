<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();
requireRole('agent');

$teleoperadora_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: panel.php");
    exit;
}

$pdo->beginTransaction();

try {
    $lead_id = (int)$_POST['lead_id'] ?? 0;
    $estado_anterior = $_POST['estado_anterior'] ?? 'nuevo';
    
    if (!$lead_id) {
        throw new Exception("ID de lead inválido");
    }
    
    // Verificar que el lead pertenece a esta teleoperadora
    $check_stmt = $pdo->prepare("SELECT id FROM leads_activos WHERE id = ? AND id_teleoperadora = ?");
    $check_stmt->execute([$lead_id, $teleoperadora_id]);
    if (!$check_stmt->fetch()) {
        throw new Exception("Lead no encontrado o no autorizado");
    }
    
    $accion = $_POST['accion'] ?? '';
    $comentario = $_POST['comentario'] ?? null;
    
    // ACCIÓN 1: Solo guardar datos del cliente
    if ($accion === 'guardar_datos') {
        $empresa = trim($_POST['empresa'] ?? '');
        $telefono1 = trim($_POST['telefono1'] ?? '');
        
        if (empty($empresa) || empty($telefono1)) {
            throw new Exception("Empresa y Teléfono 1 son obligatorios");
        }
        
        $stmt = $pdo->prepare("
            UPDATE leads_activos SET
                empresa = ?, telefono1 = ?, telefono2 = ?, cif = ?, actividad = ?,
                tipovia = ?, direccion = ?, numerocalle = ?, poblacion = ?, provincia = ?,
                cp = ?, cnaecod = ?, comunidad = ?, facturacion = ?, nr_trabajadores = ?,
                gerentes_autonomos = ?, cautonoma = ?, codoperador = ?, razonoperador = ?,
                verificado = ?
            WHERE id = ? AND id_teleoperadora = ?
        ");
        
        $stmt->execute([
            $empresa,
            $telefono1,
            $_POST['telefono2'] ?? null,
            $_POST['cif'] ?? null,
            $_POST['actividad'] ?? null,
            $_POST['tipovia'] ?? null,
            $_POST['direccion'] ?? null,
            $_POST['numerocalle'] ?? null,
            $_POST['poblacion'] ?? null,
            $_POST['provincia'] ?? null,
            $_POST['cp'] ?? null,
            $_POST['cnaecod'] ?? null,
            $_POST['comunidad'] ?? null,
            $_POST['facturacion'] ?? null,
            $_POST['nr_trabajadores'] ?? null,
            $_POST['gerentes_autonomos'] ?? null,
            $_POST['cautonoma'] ?? null,
            $_POST['codoperador'] ?? null,
            $_POST['razonoperador'] ?? null,
            isset($_POST['verificado']) ? 1 : 0,
            $lead_id,
            $teleoperadora_id
        ]);
        
        // Registrar en auditoría
        $audit = $pdo->prepare("
            INSERT INTO auditoria (tabla, registro_id, accion, usuario_id, datos_anteriores, datos_nuevos, fecha)
            VALUES ('leads_activos', ?, 'UPDATE', ?, ?, ?, NOW())
        ");
        // Aquí iría la lógica de auditoría real...
        
        $pdo->commit();
        header("Location: gestionar_lead.php?id=$lead_id&mensaje=datos_actualizados");
        exit;
    }
    
    // ACCIÓN 2: Cambiar estado del lead
    if ($accion === 'cambiar_estado') {
        $estado_nuevo = $_POST['estado_nuevo'] ?? '';
        if (empty($estado_nuevo)) {
            throw new Exception("Estado nuevo es obligatorio");
        }
        
        // Registrar en historial (SIEMPRE)
        $historial = $pdo->prepare("
            INSERT INTO historial_llamadas 
            (id_lead, id_teleoperadora, estado_anterior, estado_nuevo, comentario, fecha)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $historial->execute([$lead_id, $teleoperadora_id, $estado_anterior, $estado_nuevo, $comentario]);
        
        // LOGICA PRINCIPAL: Manejar diferentes tipos de estados
        $estados_programables = ['interesado', 'volver_llamar', 'mando_info', 'no_contesta'];
        $estados_finales = ['no_interesa', 'creditos_agotados', 'tardes', 'curso', 'ellos_contestan', 'ellos_llaman'];
        
        // CASO A: Estado "No Contesta" - Manejar contador y movimiento a tabla final
        if ($estado_nuevo === 'no_contesta') {
            // Obtener intentos actuales
            $intentos_stmt = $pdo->prepare("SELECT intentos_no_contesta FROM leads_activos WHERE id = ?");
            $intentos_stmt->execute([$lead_id]);
            $intentos_actuales = (int)$intentos_stmt->fetchColumn();
            $nuevos_intentos = $intentos_actuales + 1;
            
            // Actualizar contador en leads_activos
            $update_intentos = $pdo->prepare("
                UPDATE leads_activos 
                SET intentos_no_contesta = ?, estado_actual = 'no_contesta'
                WHERE id = ?
            ");
            $update_intentos->execute([$nuevos_intentos, $lead_id]);
            
            // Verificar si es el tercer intento
            if ($nuevos_intentos >= 3) {
                // MOVER a leads_no_contesta
                $lead_data = $pdo->prepare("SELECT * FROM leads_activos WHERE id = ?");
                $lead_data->execute([$lead_id]);
                $datos = $lead_data->fetch(PDO::FETCH_ASSOC);
                
                if ($datos) {
                    // Insertar en tabla final
                    $insert_final = $pdo->prepare("
                        INSERT INTO leads_no_contesta 
                        (actividad, empresa, tipovia, direccion, numerocalle, poblacion, provincia, cp,
                         telefono1, telefono2, cnaecod, comunidad, facturacion, nr_trabajadores, cif,
                         gerentes_autonomos, cautonoma, codoperador, razonoperador, id_teleoperadora,
                         verificado, creado_en)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ");
                    
                    $insert_final->execute([
                        $datos['actividad'], $datos['empresa'], $datos['tipovia'], $datos['direccion'],
                        $datos['numerocalle'], $datos['poblacion'], $datos['provincia'], $datos['cp'],
                        $datos['telefono1'], $datos['telefono2'], $datos['cnaecod'], $datos['comunidad'],
                        $datos['facturacion'], $datos['nr_trabajadores'], $datos['cif'],
                        $datos['gerentes_autonomos'], $datos['cautonoma'], $datos['codoperador'],
                        $datos['razonoperador'], $datos['id_teleoperadora'], $datos['verificado']
                    ]);
                    
                    // ELIMINAR de leads_activos
                    $delete_activos = $pdo->prepare("DELETE FROM leads_activos WHERE id = ?");
                    $delete_activos->execute([$lead_id]);
                }
            } else {
                // Menos de 3 intentos: programar siguiente llamada
                if (!empty($_POST['fecha_programada'])) {
                    $programada = $pdo->prepare("
                        INSERT INTO llamadas_programadas (id_lead, fecha_programada, prioridad)
                        VALUES (?, ?, 4)
                    ");
                    $programada->execute([$lead_id, $_POST['fecha_programada']]);
                }
            }
        }
        
        // CASO B: Otros estados programables
        elseif (in_array($estado_nuevo, ['interesado', 'volver_llamar', 'mando_info'])) {
            // Actualizar estado en leads_activos
            $prioridad_map = ['interesado' => 1, 'volver_llamar' => 2, 'mando_info' => 3];
            $prioridad = $prioridad_map[$estado_nuevo];
            
            $update_estado = $pdo->prepare("
                UPDATE leads_activos 
                SET estado_actual = ?
                WHERE id = ?
            ");
            $update_estado->execute([$estado_nuevo, $lead_id]);
            
            // Programar llamada
            if (!empty($_POST['fecha_programada'])) {
                $programada = $pdo->prepare("
                    INSERT INTO llamadas_programadas (id_lead, fecha_programada, prioridad)
                    VALUES (?, ?, ?)
                ");
                $programada->execute([$lead_id, $_POST['fecha_programada'], $prioridad]);
            }
        }
        
        // CASO C: Estados finales
        elseif (in_array($estado_nuevo, $estados_finales)) {
            // Mapear estado a tabla destino
            $tabla_destino_map = [
                'no_interesa' => 'leads_no_interesa',
                'creditos_agotados' => 'leads_creditos_agotados',
                'tardes' => 'leads_tardes',
                'curso' => 'leads_curso',
                'ellos_contestan' => 'leads_ellos_contestan',
                'ellos_llaman' => 'leads_ellos_llaman'
            ];
            
            $tabla_destino = $tabla_destino_map[$estado_nuevo];
            
            // Obtener datos del lead
            $lead_data = $pdo->prepare("SELECT * FROM leads_activos WHERE id = ?");
            $lead_data->execute([$lead_id]);
            $datos = $lead_data->fetch(PDO::FETCH_ASSOC);
            
            if ($datos) {
                // Construir consulta dinámica para la tabla destino
                $columns = implode(',', array_keys($datos));
                $placeholders = ':' . implode(', :', array_keys($datos));
                
                $insert_final = $pdo->prepare("INSERT INTO `$tabla_destino` ($columns) VALUES ($placeholders)");
                
                // Preparar datos (eliminar ID si la tabla destino no lo necesita)
                unset($datos['id']);
                $insert_final->execute($datos);
                
                // ELIMINAR de leads_activos
                $delete_activos = $pdo->prepare("DELETE FROM leads_activos WHERE id = ?");
                $delete_activos->execute([$lead_id]);
            }
        }
        
        $pdo->commit();
        header("Location: panel.php?mensaje=estado_actualizado");
        exit;
    }
    
    throw new Exception("Acción no reconocida");
    
} catch (Exception $e) {
    $pdo->rollback();
    error_log("Error en procesar_llamada.php: " . $e->getMessage());
    header("Location: panel.php?error=" . urlencode($e->getMessage()));
    exit;
}
?>