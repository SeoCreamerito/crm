<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
requireLogin();
requireRole('agent');

$accion = $_POST['accion'] ?? '';
$teleoperadora_id = $_SESSION['user_id'];

if ($accion === 'inicio_pausa') {
    // Obtener sesión activa
    $sesion = $pdo->prepare("
        SELECT id FROM sesiones_actividad 
        WHERE id_teleoperadora = ? AND hora_salida IS NULL
    ");
    $sesion->execute([$teleoperadora_id]);
    $sesion_id = $sesion->fetchColumn();
    
    if ($sesion_id) {
        $stmt = $pdo->prepare("
            INSERT INTO pausas (id_sesion, tipo_pausa, hora_inicio)
            VALUES (?, ?, NOW())
        ");
        $stmt->execute([$sesion_id, $_POST['tipo_pausa']]);
    }
}

if ($accion === 'fin_pausa') {
    $stmt = $pdo->prepare("
        UPDATE pausas 
        SET hora_fin = NOW() 
        WHERE id_sesion IN (
            SELECT id FROM sesiones_actividad 
            WHERE id_teleoperadora = ? AND hora_salida IS NULL
        ) AND hora_fin IS NULL
    ");
    $stmt->execute([$teleoperadora_id]);
}

header("Location: panel.php");
?>