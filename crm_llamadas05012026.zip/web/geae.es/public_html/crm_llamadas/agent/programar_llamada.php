<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
requireLogin();
requireRole('agent');

// Verificar que el lead todavía esté en leads_activos
$stmt = $conexion->prepare("SELECT id FROM leads_activos WHERE id = ? AND id_teleoperadora = ?");
$stmt->bind_param("ii", $_POST['id_lead'], $_SESSION['user_id']);
$stmt->execute();
if ($stmt->get_result()->num_rows === 0) {
    die("Lead no encontrado o no asignado.");
}

$stmt = $conexion->prepare("
    INSERT INTO llamadas_programadas (id_lead, desde_tabla, id_teleoperadora, fecha_programada, estado_programado)
    VALUES (?, 'leads_activos', ?, ?, ?)
");
$stmt->bind_param("iiss", $_POST['id_lead'], $_SESSION['user_id'], $_POST['fecha_programada'], $_POST['estado_programado']);
$stmt->execute();

header("Location: panel.php");
exit;
?>