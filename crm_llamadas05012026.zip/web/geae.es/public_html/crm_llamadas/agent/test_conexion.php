<?php
// Archivo de diagnóstico - Guardar como: /agent/test_conexion.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Test de Conexión CRM</h1>";

// Test 1: Includes
echo "<h2>1. Verificando archivos includes</h2>";
echo "Buscando config.php... ";
if (file_exists('../includes/config.php')) {
    echo "✅ Encontrado<br>";
    require_once '../includes/config.php';
} else {
    echo "❌ NO encontrado<br>";
    die("No se puede continuar sin config.php");
}

echo "Buscando auth.php... ";
if (file_exists('../includes/auth.php')) {
    echo "✅ Encontrado<br>";
    require_once '../includes/auth.php';
} else {
    echo "❌ NO encontrado<br>";
}

// Test 2: Conexión
echo "<h2>2. Verificando conexión a base de datos</h2>";
if (isset($conexion)) {
    echo "✅ Variable \$conexion existe<br>";
    
    if ($conexion->connect_error) {
        echo "❌ Error de conexión: " . $conexion->connect_error . "<br>";
    } else {
        echo "✅ Conexión establecida correctamente<br>";
        echo "Base de datos: " . DB_NAME . "<br>";
    }
} else {
    echo "❌ Variable \$conexion NO existe<br>";
}

// Test 3: Tablas
echo "<h2>3. Verificando tablas</h2>";
$tablas_necesarias = [
    'usuarios',
    'estados_llamada',
    'leads_activos',
    'historial_llamadas',
    'llamadas_programadas'
];

foreach ($tablas_necesarias as $tabla) {
    $result = $conexion->query("SHOW TABLES LIKE '$tabla'");
    if ($result && $result->num_rows > 0) {
        echo "✅ Tabla '$tabla' existe<br>";
        
        // Contar registros
        $count = $conexion->query("SELECT COUNT(*) as total FROM $tabla");
        if ($count) {
            $row = $count->fetch_assoc();
            echo "&nbsp;&nbsp;&nbsp;→ Registros: " . $row['total'] . "<br>";
        }
    } else {
        echo "❌ Tabla '$tabla' NO existe<br>";
    }
}

// Test 4: Sesión
echo "<h2>4. Verificando sesión</h2>";
if (session_status() === PHP_SESSION_ACTIVE) {
    echo "✅ Sesión activa<br>";
    
    if (isset($_SESSION['user_id'])) {
        echo "✅ user_id en sesión: " . $_SESSION['user_id'] . "<br>";
    } else {
        echo "❌ user_id NO está en sesión<br>";
    }
    
    if (isset($_SESSION['user_rol'])) {
        echo "✅ user_rol en sesión: " . $_SESSION['user_rol'] . "<br>";
    } else {
        echo "❌ user_rol NO está en sesión<br>";
    }
} else {
    echo "⚠️ Sesión NO activa<br>";
}

// Test 5: Query de prueba
echo "<h2>5. Test de consulta a leads_activos</h2>";
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conexion->prepare("SELECT COUNT(*) as total FROM leads_activos WHERE id_teleoperadora = ?");
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        echo "✅ Leads asignados a ti: " . $row['total'] . "<br>";
        
        // Intentar obtener un lead
        $stmt2 = $conexion->prepare("SELECT * FROM leads_activos WHERE id_teleoperadora = ? LIMIT 1");
        $stmt2->bind_param("i", $user_id);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        
        if ($result2->num_rows > 0) {
            $lead = $result2->fetch_assoc();
            echo "✅ Lead encontrado:<br>";
            echo "<pre>";
            print_r($lead);
            echo "</pre>";
        } else {
            echo "⚠️ No tienes leads asignados<br>";
        }
    } else {
        echo "❌ Error en prepare: " . $conexion->error . "<br>";
    }
} else {
    echo "⚠️ No se puede probar sin sesión activa<br>";
}

// Test 6: Estados
echo "<h2>6. Verificando estados de llamada</h2>";
$result = $conexion->query("SELECT * FROM estados_llamada ORDER BY id");
if ($result) {
    echo "✅ Estados encontrados:<br>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Nombre</th><th>Tipo</th><th>Tabla Destino</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['nombre'] . "</td>";
        echo "<td>" . $row['tipo'] . "</td>";
        echo "<td>" . ($row['tabla_destino'] ?? '—') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "❌ Error al obtener estados: " . $conexion->error . "<br>";
}

echo "<h2>✅ Diagnóstico completado</h2>";
echo "<p><a href='gestionar_lead.php'>Volver a gestionar_lead.php</a></p>";
?>