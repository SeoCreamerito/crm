<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
requireLogin();
requireRole('agent');

if ($_POST['fichar_entrada'] ?? false) {
    $stmt = $pdo->prepare("
        INSERT INTO sesiones_actividad (id_teleoperadora, hora_entrada, ip_entrada, id_sesion)
        VALUES (?, NOW(), ?, ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $_SERVER['REMOTE_ADDR'], session_id()]);
}

if ($_POST['fichar_salida'] ?? false) {
    $stmt = $pdo->prepare("
        UPDATE sesiones_actividad 
        SET hora_salida = NOW(), ip_salida = ? 
        WHERE id_teleoperadora = ? AND hora_salida IS NULL
    ");
    $stmt->execute([$_SERVER['REMOTE_ADDR'], $_SESSION['user_id']]);
    session_destroy();
}

header("Location: panel.php");
?>