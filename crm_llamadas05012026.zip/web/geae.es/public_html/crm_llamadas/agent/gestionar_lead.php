<?php
/**
 * Gestionar Lead - CRM Llamadas
 * Adaptado a la estructura real de la BD
 */
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('agent');

$id_teleop = $_SESSION['user_id'];
$id_lead = intval($_GET['id'] ?? 0);
$modo_ver = isset($_GET['modo']) && $_GET['modo'] === 'ver';
$mensaje = '';
$tipo = '';

if ($id_lead <= 0) {
    header('Location: panel.php');
    exit;
}

$lead = getLeadById($pdo, $id_lead);
if (!$lead || $lead['id_teleoperadora'] != $id_teleop) {
    $_SESSION['error'] = 'No tienes permiso para este lead.';
    header('Location: panel.php');
    exit;
}

$estados = getEstadosLlamada($pdo);
$historial = getHistorialLlamadas($pdo, $id_lead);
$ultimo_estado = $historial[0]['estado_nuevo'] ?? null;

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';
    
    try {
        if ($accion === 'actualizar_datos') {
            // Actualizar datos del lead
            $stmt = $pdo->prepare("
                UPDATE leads_activos SET
                    actividad = :actividad, empresa = :empresa, tipovia = :tipovia, 
                    direccion = :direccion, numerocalle = :numerocalle, poblacion = :poblacion, 
                    provincia = :provincia, cp = :cp, telefono2 = :telefono2, email = :email, 
                    cnaecod = :cnaecod, comunidad = :comunidad, facturacion = :facturacion, 
                    nr_trabajadores = :nr_trabajadores, gerentes_autonomos = :gerentes
                WHERE id = :id AND id_teleoperadora = :id_teleop
            ");
            $stmt->execute([
                ':actividad' => $_POST['actividad'] ?? '',
                ':empresa' => $_POST['empresa'] ?? '',
                ':tipovia' => $_POST['tipovia'] ?? '',
                ':direccion' => $_POST['direccion'] ?? '',
                ':numerocalle' => $_POST['numerocalle'] ?? '',
                ':poblacion' => $_POST['poblacion'] ?? '',
                ':provincia' => $_POST['provincia'] ?? '',
                ':cp' => $_POST['cp'] ?? '',
                ':telefono2' => $_POST['telefono2'] ?? '',
                ':email' => $_POST['email'] ?? '',
                ':cnaecod' => $_POST['cnaecod'] ?? '',
                ':comunidad' => $_POST['comunidad'] ?? '',
                ':facturacion' => $_POST['facturacion'] ?? '',
                ':nr_trabajadores' => $_POST['nr_trabajadores'] ?? '',
                ':gerentes' => $_POST['gerentes_autonomos'] ?? '',
                ':id' => $id_lead,
                ':id_teleop' => $id_teleop
            ]);
            $mensaje = 'Datos actualizados correctamente.';
            $tipo = 'success';
            $lead = getLeadById($pdo, $id_lead);
            
        } elseif ($accion === 'actualizar_estado') {
            $nuevo_estado = $_POST['nuevo_estado'] ?? '';
            $notas = $_POST['notas'] ?? '';
            $verificado = isset($_POST['verificado']) ? 1 : 0;
            $consentimiento_rgpd = isset($_POST['consentimiento_rgpd']) ? 1 : 0;
            $telefono_usado = $_POST['telefono_usado'] ?? $lead['telefono1'];
            $fecha_prog = $_POST['fecha_programada'] ?? '';
            $hora_prog = $_POST['hora_programada'] ?? '';
            
            if (empty($nuevo_estado)) {
                throw new Exception('Selecciona un estado.');
            }
            
            $estado_info = getEstadoByNombre($pdo, $nuevo_estado);
            if (!$estado_info) {
                throw new Exception('Estado no válido.');
            }
            
            // Verificar si requiere RGPD
            if (!empty($estado_info['requiere_rgpd_check']) && !$consentimiento_rgpd) {
                throw new Exception('Este estado requiere marcar el consentimiento RGPD.');
            }
            
            // Verificar si requiere programación
            $es_programable = ($estado_info['tipo'] === 'programable');
            $es_no_contesta = (strpos($nuevo_estado, 'No Contesta') !== false && $nuevo_estado !== 'No Contesta 3');
            
            if (($es_programable || $es_no_contesta) && (empty($fecha_prog) || empty($hora_prog))) {
                throw new Exception('Este estado requiere programar la próxima llamada.');
            }
            
            $pdo->beginTransaction();
            
            // Registrar en historial (con desde_tabla)
            registrarLlamada($pdo, [
                'id_lead' => $id_lead,
                'desde_tabla' => 'leads_activos',
                'id_teleoperadora' => $id_teleop,
                'estado_anterior' => $ultimo_estado,
                'estado_nuevo' => $nuevo_estado,
                'notas' => $notas,
                'verificado' => $verificado,
                'telefono_usado' => $telefono_usado
            ]);
            
            // Actualizar verificado y RGPD
            if ($verificado) {
                marcarVerificado($pdo, $id_lead, true);
            }
            if ($consentimiento_rgpd) {
                marcarConsentimientoRGPD($pdo, $id_lead);
            }
            
            // Si es estado FINAL -> mover a tabla destino
            if ($estado_info['tipo'] === 'final' && !empty($estado_info['tabla_destino'])) {
                moverLeadATablaFinal($pdo, $id_lead, $estado_info['tabla_destino'], $estado_info['id']);
                $pdo->commit();
                
                // Buscar siguiente lead
                $fecha_hoy = date('Y-m-d');
                $siguiente = obtenerSiguienteLead($pdo, $id_teleop, $id_lead, $fecha_hoy);
                
                if ($siguiente) {
                    $_SESSION['exito'] = "Lead '{$nuevo_estado}'. Pasando al siguiente...";
                    header("Location: gestionar_lead.php?id=$siguiente");
                    exit;
                } else {
                    $_SESSION['exito'] = "Lead movido a '{$nuevo_estado}'. ¡Has gestionado todos tus leads!";
                    header('Location: panel.php');
                    exit;
                }
            }
            
            // Programar siguiente llamada si aplica
            if (!empty($fecha_prog) && !empty($hora_prog)) {
                programarLlamada($pdo, [
                    'id_lead' => $id_lead,
                    'desde_tabla' => 'leads_activos',
                    'id_teleoperadora' => $id_teleop,
                    'fecha_programada' => "$fecha_prog $hora_prog:00",
                    'estado_programado' => $nuevo_estado
                ]);
            }
            
            // Incrementar intentos si es No Contesta
            if (strpos($nuevo_estado, 'No Contesta') !== false) {
                $intentos = incrementarIntentosNoContesta($pdo, $id_lead);
                if ($intentos >= 3) {
                    // Mover a leads_no_contesta automáticamente
                    $estado_final = getEstadoByNombre($pdo, 'No Contesta 3');
                    moverLeadATablaFinal($pdo, $id_lead, 'leads_no_contesta', $estado_final['id'] ?? null);
                    $pdo->commit();
                    
                    // Buscar siguiente lead
                    $fecha_hoy = date('Y-m-d');
                    $siguiente = obtenerSiguienteLead($pdo, $id_teleop, $id_lead, $fecha_hoy);
                    
                    if ($siguiente) {
                        $_SESSION['exito'] = 'No Contesta (3 intentos). Pasando al siguiente...';
                        header("Location: gestionar_lead.php?id=$siguiente");
                        exit;
                    } else {
                        $_SESSION['exito'] = 'Lead movido a No Contesta. ¡Has gestionado todos tus leads!';
                        header('Location: panel.php');
                        exit;
                    }
                }
            }
            
            $pdo->commit();
            
            // Buscar el siguiente lead para gestionar
            $fecha_hoy = date('Y-m-d');
            $siguiente = obtenerSiguienteLead($pdo, $id_teleop, $id_lead, $fecha_hoy);
            
            if ($siguiente) {
                $_SESSION['exito'] = 'Estado guardado. Pasando al siguiente lead...';
                header("Location: gestionar_lead.php?id=$siguiente");
                exit;
            } else {
                $_SESSION['exito'] = '¡Enhorabuena! Has gestionado todos tus leads.';
                header('Location: panel.php');
                exit;
            }
        }
        
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $mensaje = 'Error: ' . $e->getMessage();
        $tipo = 'danger';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar: <?php echo htmlspecialchars($lead['empresa']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background: #f3f4f6; }
        .navbar { background: linear-gradient(135deg, #4f46e5, #6366f1); }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .telefono-principal { font-size: 1.5rem; color: #4f46e5; font-weight: 600; }
        .historial-item { border-left: 3px solid #4f46e5; padding-left: 1rem; margin-bottom: 1rem; }
        .seccion-oculta { display: none; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark mb-4">
    <div class="container-fluid">
        <a href="panel.php" class="navbar-brand"><i class="bi bi-arrow-left me-2"></i>Volver al Panel</a>
        <div class="d-flex align-items-center gap-2">
            <?php if ($modo_ver): ?>
            <span class="badge bg-info fs-6"><i class="bi bi-eye me-1"></i>Modo Consulta</span>
            <a href="gestionar_lead.php?id=<?php echo $id_lead; ?>" class="btn btn-success btn-sm">
                <i class="bi bi-telephone me-1"></i>Pasar a Llamar
            </a>
            <?php endif; ?>
            <span class="text-white"><?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
        </div>
    </div>
</nav>

<div class="container-fluid px-4">
    <?php if (!empty($_SESSION['exito'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo $_SESSION['exito']; unset($_SESSION['exito']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($mensaje): ?>
    <div class="alert alert-<?php echo $tipo; ?> alert-dismissible fade show">
        <?php echo $mensaje; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Cabecera del Lead -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="h3 fw-bold"><?php echo htmlspecialchars($lead['empresa']); ?></h1>
                    <p class="text-muted mb-0">
                        <i class="bi bi-briefcase me-1"></i><?php echo htmlspecialchars($lead['actividad'] ?? 'Sin actividad'); ?> |
                        <i class="bi bi-geo-alt me-1"></i><?php echo htmlspecialchars($lead['provincia'] ?? 'Sin provincia'); ?>
                    </p>
                </div>
                <div class="col-md-4">
                    <div class="telefono-principal mb-1">
                        <i class="bi bi-telephone-fill me-2"></i>
                        <a href="tel:<?php echo $lead['telefono1']; ?>"><?php echo htmlspecialchars($lead['telefono1']); ?></a>
                    </div>
                    <?php if (!empty($lead['telefono2'])): ?>
                    <div class="text-muted"><i class="bi bi-telephone me-2"></i><?php echo htmlspecialchars($lead['telefono2']); ?></div>
                    <?php endif; ?>
                    <?php if (!empty($lead['email'])): ?>
                    <div class="text-muted"><i class="bi bi-envelope me-2"></i><?php echo htmlspecialchars($lead['email']); ?></div>
                    <?php endif; ?>
                </div>
                <div class="col-md-2 text-end">
                    <?php if (!empty($lead['verificado'])): ?>
                    <span class="badge bg-success mb-1">Verificado</span><br>
                    <?php endif; ?>
                    <?php if ($lead['intentos_no_contesta'] > 0): ?>
                    <span class="badge bg-warning text-dark"><?php echo $lead['intentos_no_contesta']; ?>/3 intentos</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Columna: Actualizar Estado -->
        <div class="col-lg-6 mb-4">
            <?php if ($modo_ver): ?>
            <!-- MODO VER: Solo información -->
            <div class="card">
                <div class="card-header bg-info text-white">
                    <i class="bi bi-eye me-2"></i><strong>Modo Consulta</strong>
                </div>
                <div class="card-body text-center py-4">
                    <i class="bi bi-info-circle text-info" style="font-size: 3rem;"></i>
                    <p class="mt-3 mb-4">Estás viendo este lead en modo consulta.<br>No es necesario guardar ningún cambio.</p>
                    <a href="gestionar_lead.php?id=<?php echo $id_lead; ?>" class="btn btn-success btn-lg">
                        <i class="bi bi-telephone me-2"></i>Pasar a Llamar
                    </a>
                    <a href="panel.php" class="btn btn-outline-secondary btn-lg ms-2">
                        <i class="bi bi-arrow-left me-2"></i>Volver
                    </a>
                </div>
            </div>
            <?php else: ?>
            <!-- MODO LLAMAR: Formulario completo -->
            <div class="card">
                <div class="card-header bg-white">
                    <i class="bi bi-arrow-repeat me-2"></i><strong>Actualizar Estado</strong>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="accion" value="actualizar_estado">
                        
                        <div class="row mb-3">
                            <div class="col-6">
                                <label class="form-label">Estado Actual</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($ultimo_estado ?? 'Nuevo'); ?>" readonly>
                            </div>
                            <div class="col-6">
                                <label class="form-label">Nuevo Estado *</label>
                                <select name="nuevo_estado" id="nuevoEstado" class="form-select" required>
                                    <option value="">-- Seleccionar --</option>
                                    <?php foreach ($estados as $e): ?>
                                    <option value="<?php echo htmlspecialchars($e['nombre']); ?>" 
                                            data-tipo="<?php echo $e['tipo']; ?>"
                                            data-rgpd="<?php echo $e['requiere_rgpd_check'] ?? 0; ?>">
                                        <?php echo htmlspecialchars($e['nombre']); ?>
                                        <?php if ($e['tipo'] === 'final'): ?> [FINAL]<?php endif; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Teléfono Usado</label>
                            <select name="telefono_usado" class="form-select">
                                <option value="<?php echo $lead['telefono1']; ?>"><?php echo $lead['telefono1']; ?> (Principal)</option>
                                <?php if (!empty($lead['telefono2'])): ?>
                                <option value="<?php echo $lead['telefono2']; ?>"><?php echo $lead['telefono2']; ?> (Secundario)</option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <!-- Sección Programación (oculta por defecto) -->
                        <div id="seccionProgramacion" class="seccion-oculta bg-light p-3 rounded mb-3">
                            <h6><i class="bi bi-calendar-event me-2"></i>Programar Próxima Llamada</h6>
                            <div class="row">
                                <div class="col-6">
                                    <label class="form-label">Fecha *</label>
                                    <input type="date" name="fecha_programada" id="fechaProgramada" class="form-control" min="<?php echo date('Y-m-d'); ?>">
                                </div>
                                <div class="col-6">
                                    <label class="form-label">Hora *</label>
                                    <input type="time" name="hora_programada" id="horaProgramada" class="form-control" value="09:00">
                                </div>
                            </div>
                        </div>

                        <!-- Sección RGPD (oculta por defecto) -->
                        <div id="seccionRGPD" class="seccion-oculta alert alert-warning mb-3">
                            <div class="form-check">
                                <input type="checkbox" name="consentimiento_rgpd" id="checkRGPD" class="form-check-input">
                                <label for="checkRGPD" class="form-check-label">
                                    <strong>OBLIGATORIO:</strong> El cliente ha dado su consentimiento expreso para recibir comunicaciones comerciales por correo electrónico conforme al RGPD y la LSSI.
                                </label>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Comentario / Notas</label>
                            <textarea name="notas" class="form-control" rows="3" placeholder="Escribe aquí lo hablado con el cliente..."></textarea>
                        </div>

                        <div class="form-check mb-3">
                            <input type="checkbox" name="verificado" id="checkVerificado" class="form-check-input" <?php echo !empty($lead['verificado']) ? 'checked' : ''; ?>>
                            <label for="checkVerificado" class="form-check-label">Los datos de este cliente han sido verificados</label>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-check-lg me-2"></i>Guardar Estado
                        </button>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Columna: Historial -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header bg-white">
                    <i class="bi bi-clock-history me-2"></i><strong>Historial de Llamadas</strong>
                </div>
                <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                    <?php if (count($historial) > 0): ?>
                        <?php foreach ($historial as $h): ?>
                        <div class="historial-item">
                            <div class="d-flex justify-content-between">
                                <strong><?php echo date('d/m/Y H:i', strtotime($h['fecha_llamada'])); ?></strong>
                                <span class="badge bg-info"><?php echo htmlspecialchars($h['estado_nuevo']); ?></span>
                            </div>
                            <small class="text-muted">Por: <?php echo htmlspecialchars($h['nombre_teleoperadora'] ?? 'Sistema'); ?></small>
                            <?php if (!empty($h['notas'])): ?>
                            <p class="mb-0 mt-1"><em><?php echo nl2br(htmlspecialchars($h['notas'])); ?></em></p>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted text-center">Sin historial de llamadas</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Datos del Cliente (Editables) -->
    <div class="card mb-4">
        <div class="card-header bg-white">
            <i class="bi bi-person-lines-fill me-2"></i><strong>Datos del Cliente</strong> (editables)
        </div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="accion" value="actualizar_datos">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Empresa</label>
                        <input type="text" name="empresa" class="form-control" value="<?php echo htmlspecialchars($lead['empresa'] ?? ''); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Actividad</label>
                        <input type="text" name="actividad" class="form-control" value="<?php echo htmlspecialchars($lead['actividad'] ?? ''); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($lead['email'] ?? ''); ?>" placeholder="email@empresa.com">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Teléfono 2</label>
                        <input type="text" name="telefono2" class="form-control" value="<?php echo htmlspecialchars($lead['telefono2'] ?? ''); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Provincia</label>
                        <input type="text" name="provincia" class="form-control" value="<?php echo htmlspecialchars($lead['provincia'] ?? ''); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Población</label>
                        <input type="text" name="poblacion" class="form-control" value="<?php echo htmlspecialchars($lead['poblacion'] ?? ''); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">C.P.</label>
                        <input type="text" name="cp" class="form-control" value="<?php echo htmlspecialchars($lead['cp'] ?? ''); ?>">
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Tipo Vía</label>
                        <input type="text" name="tipovia" class="form-control" value="<?php echo htmlspecialchars($lead['tipovia'] ?? ''); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Dirección</label>
                        <input type="text" name="direccion" class="form-control" value="<?php echo htmlspecialchars($lead['direccion'] ?? ''); ?>">
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Número</label>
                        <input type="text" name="numerocalle" class="form-control" value="<?php echo htmlspecialchars($lead['numerocalle'] ?? ''); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Comunidad Autónoma</label>
                        <input type="text" name="comunidad" class="form-control" value="<?php echo htmlspecialchars($lead['comunidad'] ?? ''); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">CNAE</label>
                        <input type="text" name="cnaecod" class="form-control" value="<?php echo htmlspecialchars($lead['cnaecod'] ?? ''); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Facturación</label>
                        <input type="text" name="facturacion" class="form-control" value="<?php echo htmlspecialchars($lead['facturacion'] ?? ''); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Nº Trabajadores</label>
                        <input type="text" name="nr_trabajadores" class="form-control" value="<?php echo htmlspecialchars($lead['nr_trabajadores'] ?? ''); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Gerentes/Autónomos</label>
                        <input type="text" name="gerentes_autonomos" class="form-control" value="<?php echo htmlspecialchars($lead['gerentes_autonomos'] ?? ''); ?>">
                    </div>
                </div>
                <button type="submit" class="btn btn-secondary">
                    <i class="bi bi-save me-2"></i>Guardar Datos
                </button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('nuevoEstado').addEventListener('change', function() {
    var opt = this.options[this.selectedIndex];
    var tipo = opt.dataset.tipo;
    var valor = this.value;
    var requiereRgpd = opt.dataset.rgpd === '1';
    
    // Mostrar programación para estados programables o No Contesta 1/2
    var mostrarProg = (tipo === 'programable') || (valor.includes('No Contesta') && valor !== 'No Contesta 3');
    document.getElementById('seccionProgramacion').style.display = mostrarProg ? 'block' : 'none';
    
    // Mostrar RGPD si el estado lo requiere
    document.getElementById('seccionRGPD').style.display = requiereRgpd ? 'block' : 'none';
});
</script>
</body>
</html>
