<?php
// verificar_tabla_programadas.php
// Guardar en: /agent/verificar_tabla_programadas.php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';

echo "<h1>Verificar Tabla llamadas_programadas</h1>";

// 1. Ver estructura de la tabla
echo "<h2>Estructura de la tabla:</h2>";
$result = $conexion->query("DESCRIBE llamadas_programadas");

if ($result) {
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
    echo "<tr style='background: #f0f0f0;'>";
    echo "<th>Campo</th><th>Tipo</th><th>Nulo</th><th>Clave</th><th>Por Defecto</th><th>Extra</th>";
    echo "</tr>";
    
    $tiene_estado = false;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td><strong>" . $row['Field'] . "</strong></td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . ($row['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
        
        if ($row['Field'] === 'estado') {
            $tiene_estado = true;
        }
    }
    echo "</table>";
    
    // Verificar si tiene columna 'estado'
    echo "<h2>Verificación:</h2>";
    if ($tiene_estado) {
        echo "<p style='color: green;'>✅ La tabla <strong>SÍ</strong> tiene la columna 'estado'</p>";
        echo "<p>El código actualizado puede usar esta columna para filtrar registros.</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ La tabla <strong>NO</strong> tiene la columna 'estado'</p>";
        echo "<p>El código actualizado ya está adaptado para funcionar sin esta columna.</p>";
        echo "<h3>Opciones:</h3>";
        echo "<ol>";
        echo "<li><strong>Opción 1 (Recomendada):</strong> Añadir la columna 'estado' ejecutando:<br>";
        echo "<code style='background: #f0f0f0; padding: 10px; display: block; margin: 10px 0;'>";
        echo "ALTER TABLE llamadas_programadas <br>";
        echo "ADD COLUMN estado ENUM('pendiente', 'completada', 'cancelada') DEFAULT 'pendiente' <br>";
        echo "AFTER notas_programacion;";
        echo "</code>";
        echo "</li>";
        echo "<li><strong>Opción 2:</strong> Usar el código actual que ya está adaptado (no requiere cambios).</li>";
        echo "</ol>";
    }
    
} else {
    echo "<p style='color: red;'>❌ Error al obtener estructura: " . $conexion->error . "</p>";
}

// 2. Ver registros actuales
echo "<h2>Registros actuales:</h2>";
$result = $conexion->query("SELECT * FROM llamadas_programadas LIMIT 10");

if ($result) {
    if ($result->num_rows > 0) {
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
        echo "<tr style='background: #f0f0f0;'>";
        
        // Encabezados dinámicos
        $first_row = $result->fetch_assoc();
        foreach ($first_row as $key => $value) {
            echo "<th>" . htmlspecialchars($key) . "</th>";
        }
        echo "</tr>";
        
        // Primera fila
        echo "<tr>";
        foreach ($first_row as $value) {
            echo "<td>" . htmlspecialchars($value ?? '') . "</td>";
        }
        echo "</tr>";
        
        // Resto de filas
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>" . htmlspecialchars($value ?? '') . "</td>";
            }
            echo "</tr>";
        }
        
        echo "</table>";
    } else {
        echo "<p>No hay registros en la tabla (está vacía)</p>";
    }
} else {
    echo "<p style='color: red;'>❌ Error al obtener registros: " . $conexion->error . "</p>";
}

// 3. Script de prueba de inserción
echo "<h2>Test de Inserción:</h2>";
echo "<form method='POST'>";
echo "<p>¿Probar insertar un registro de prueba?</p>";
echo "<button type='submit' name='test_insert'>Probar Inserción</button>";
echo "</form>";

if (isset($_POST['test_insert'])) {
    // Obtener un lead de prueba
    $result = $conexion->query("SELECT id FROM leads_activos WHERE id_teleoperadora = 3 LIMIT 1");
    if ($result && $result->num_rows > 0) {
        $lead = $result->fetch_assoc();
        $lead_id = $lead['id'];
        $teleop_id = 3;
        $fecha = date('Y-m-d H:i:s', strtotime('+1 day'));
        $notas = 'Prueba de inserción';
        
        $stmt = $conexion->prepare("
            INSERT INTO llamadas_programadas (
                id_lead, 
                id_teleoperadora, 
                fecha_programada, 
                notas_programacion
            ) VALUES (?, ?, ?, ?)
        ");
        
        $stmt->bind_param("iiss", $lead_id, $teleop_id, $fecha, $notas);
        
        if ($stmt->execute()) {
            echo "<p style='color: green;'>✅ Inserción exitosa. ID: " . $stmt->insert_id . "</p>";
            echo "<p><a href='verificar_tabla_programadas.php'>Recargar para ver el registro</a></p>";
        } else {
            echo "<p style='color: red;'>❌ Error en inserción: " . $stmt->error . "</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ No se encontraron leads asignados a ti para la prueba</p>";
    }
}

echo "<hr>";
echo "<p><a href='gestionar_lead.php'>Ir a Gestionar Lead</a></p>";
echo "<p><a href='test_conexion.php'>Volver al Test de Conexión</a></p>";
?>