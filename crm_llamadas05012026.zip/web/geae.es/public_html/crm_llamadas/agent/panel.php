<?php
/**
 * Panel de Teleoperadora - CRM Llamadas
 * Con alta manual de leads
 */
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('agent');

$id_teleop = $_SESSION['user_id'];
$nombre = $_SESSION['nombre'] ?? 'Teleoperadora';
$fecha_hoy = date('Y-m-d');
$mensaje = '';
$tipo = '';

// Procesar alta manual de lead
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'alta_lead') {
    try {
        $empresa = trim($_POST['empresa'] ?? '');
        $telefono1 = trim($_POST['telefono1'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $actividad = trim($_POST['actividad'] ?? '');
        $provincia = trim($_POST['provincia'] ?? '');
        $notas = trim($_POST['notas_alta'] ?? '');
        
        // Validaciones
        if (empty($empresa)) {
            throw new Exception('El nombre de la empresa es obligatorio.');
        }
        if (empty($telefono1)) {
            throw new Exception('El teléfono es obligatorio.');
        }
        
        // Limpiar teléfono
        $telefono1 = preg_replace('/[^0-9]/', '', $telefono1);
        if (strlen($telefono1) !== 9 || !preg_match('/^[6789]/', $telefono1)) {
            throw new Exception('El teléfono debe ser un número español válido (9 dígitos).');
        }
        
        // Verificar duplicado
        $stmt = $pdo->prepare("SELECT id FROM leads_activos WHERE telefono1 = :tel");
        $stmt->execute([':tel' => $telefono1]);
        if ($stmt->fetch()) {
            throw new Exception('Ya existe un lead con este teléfono.');
        }
        
        // Insertar lead
        $stmt = $pdo->prepare("
            INSERT INTO leads_activos 
            (empresa, telefono1, email, actividad, provincia, id_teleoperadora, verificado, intentos_no_contesta)
            VALUES (:empresa, :tel, :email, :actividad, :provincia, :id_teleop, 0, 0)
        ");
        $stmt->execute([
            ':empresa' => $empresa,
            ':tel' => $telefono1,
            ':email' => $email,
            ':actividad' => $actividad,
            ':provincia' => $provincia,
            ':id_teleop' => $id_teleop
        ]);
        
        $nuevo_id = $pdo->lastInsertId();
        
        // Registrar en historial si hay notas
        if (!empty($notas)) {
            $stmt = $pdo->prepare("
                INSERT INTO historial_llamadas 
                (id_lead, desde_tabla, id_teleoperadora, estado_anterior, estado_nuevo, notas, verificado)
                VALUES (:id_lead, 'leads_activos', :id_teleop, NULL, 'Alta Manual', :notas, 0)
            ");
            $stmt->execute([
                ':id_lead' => $nuevo_id,
                ':id_teleop' => $id_teleop,
                ':notas' => $notas
            ]);
        }
        
        $_SESSION['exito'] = "Lead '$empresa' dado de alta correctamente.";
        header('Location: panel.php');
        exit;
        
    } catch (Exception $e) {
        $mensaje = $e->getMessage();
        $tipo = 'danger';
    }
}

// TODOS los leads asignados
$stmt = $pdo->prepare("
    SELECT id, empresa, actividad, telefono1, telefono2, email, provincia, 
           verificado, intentos_no_contesta, creado_en
    FROM leads_activos 
    WHERE id_teleoperadora = :id 
    ORDER BY empresa
");
$stmt->execute([':id' => $id_teleop]);
$todos_leads = $stmt->fetchAll();
$total = count($todos_leads);

// Obtener último estado de cada lead
foreach ($todos_leads as &$lead) {
    $stmt = $pdo->prepare("SELECT estado_nuevo, fecha_llamada FROM historial_llamadas WHERE id_lead = :id ORDER BY fecha_llamada DESC LIMIT 1");
    $stmt->execute([':id' => $lead['id']]);
    $hist = $stmt->fetch();
    $lead['ultimo_estado'] = $hist['estado_nuevo'] ?? 'Nuevo';
    $lead['ultima_llamada'] = $hist['fecha_llamada'] ?? null;
}
unset($lead);

// Llamadas programadas HOY
$stmt = $pdo->prepare("
    SELECT lp.id as id_programada, lp.fecha_programada, lp.estado_programado,
           la.id as id_lead, la.empresa, la.actividad, la.telefono1, la.telefono2,
           la.email, la.provincia, la.verificado, la.intentos_no_contesta
    FROM llamadas_programadas lp
    INNER JOIN leads_activos la ON lp.id_lead = la.id
    WHERE lp.id_teleoperadora = :id 
    AND DATE(lp.fecha_programada) = :fecha
    AND lp.completada = 0
    AND lp.estado = 'pendiente'
    ORDER BY lp.fecha_programada ASC
");
$stmt->execute([':id' => $id_teleop, ':fecha' => $fecha_hoy]);
$llamadas_hoy = $stmt->fetchAll();

// Añadir prioridad a cada llamada
foreach ($llamadas_hoy as &$ll) {
    $stmt = $pdo->prepare("SELECT estado_nuevo FROM historial_llamadas WHERE id_lead = :id ORDER BY fecha_llamada DESC LIMIT 1");
    $stmt->execute([':id' => $ll['id_lead']]);
    $ll['estado_actual'] = $stmt->fetchColumn() ?: $ll['estado_programado'];
    
    $stmt = $pdo->prepare("SELECT prioridad FROM estados_llamada WHERE nombre = :nombre");
    $stmt->execute([':nombre' => $ll['estado_actual']]);
    $ll['prioridad'] = $stmt->fetchColumn() ?: 99;
}
unset($ll);

// Ordenar por prioridad y hora
usort($llamadas_hoy, function($a, $b) {
    if ($a['prioridad'] == $b['prioridad']) {
        return strtotime($a['fecha_programada']) - strtotime($b['fecha_programada']);
    }
    return $a['prioridad'] - $b['prioridad'];
});

// Llamadas ATRASADAS
$stmt = $pdo->prepare("
    SELECT lp.fecha_programada, lp.estado_programado,
           la.id as id_lead, la.empresa, la.telefono1, la.provincia
    FROM llamadas_programadas lp
    INNER JOIN leads_activos la ON lp.id_lead = la.id
    WHERE lp.id_teleoperadora = :id 
    AND DATE(lp.fecha_programada) < :fecha
    AND lp.completada = 0
    AND lp.estado = 'pendiente'
    ORDER BY lp.fecha_programada
");
$stmt->execute([':id' => $id_teleop, ':fecha' => $fecha_hoy]);
$atrasadas = $stmt->fetchAll();

// Contar interesados pendientes
$interesados = 0;
foreach ($llamadas_hoy as $ll) {
    if ($ll['estado_actual'] === 'Interesados') $interesados++;
}

function getPrioridadClass($p) {
    switch((int)$p) {
        case 1: return 'border-start border-danger border-4 bg-danger-subtle';
        case 2: return 'border-start border-warning border-4 bg-warning-subtle';
        case 3: return 'border-start border-info border-4 bg-info-subtle';
        case 4: return 'border-start border-primary border-4 bg-primary-subtle';
        default: return 'border-start border-secondary border-4';
    }
}

function getPrioridadBadge($p, $e) {
    switch((int)$p) {
        case 1: return '<span class="badge bg-danger">🔴 INTERESADOS</span>';
        case 2: return '<span class="badge bg-warning text-dark">🟠 VOLVER A LLAMAR</span>';
        case 3: return '<span class="badge bg-info">🟡 MANDO INFO</span>';
        case 4: return '<span class="badge bg-primary">🔵 NO CONTESTA</span>';
        default: return '<span class="badge bg-secondary">'.htmlspecialchars($e).'</span>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel - CRM Llamadas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body{background:#f3f4f6}
        .navbar{background:linear-gradient(135deg,#4f46e5,#6366f1)}
        .card{border:none;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
        .stat-number{font-size:2rem;font-weight:700}
        .lead-card{border-radius:8px;padding:1rem;margin-bottom:.5rem;background:#fff}
        .btn-llamar{background:#10b981;color:#fff;border:none}
        .btn-llamar:hover{background:#059669;color:#fff}
        .hora-badge{background:#e0e7ff;color:#4f46e5;padding:.25rem .75rem;border-radius:20px;font-weight:600}
        .btn-alta{background:#8b5cf6;color:#fff;border:none}
        .btn-alta:hover{background:#7c3aed;color:#fff}
    </style>
</head>
<body>
<nav class="navbar navbar-dark mb-4">
    <div class="container-fluid">
        <span class="navbar-brand"><i class="bi bi-telephone-fill me-2"></i>CRM Llamadas</span>
        <div class="d-flex align-items-center gap-3">
            <?php if($interesados > 0): ?>
            <span class="btn btn-danger"><i class="bi bi-star-fill me-1"></i>Interesados: <?php echo $interesados; ?></span>
            <?php endif; ?>
            <button class="btn btn-alta" data-bs-toggle="modal" data-bs-target="#modalAltaLead">
                <i class="bi bi-plus-circle me-1"></i>Nuevo Lead
            </button>
            <?php 
            // Obtener primer lead pendiente para el botón "Empezar"
            $primer_lead = obtenerSiguienteLead($pdo, $id_teleop, 0, $fecha_hoy);
            if ($primer_lead): 
            ?>
            <a href="gestionar_lead.php?id=<?php echo $primer_lead; ?>" class="btn btn-success">
                <i class="bi bi-play-fill me-1"></i>Empezar a Llamar
            </a>
            <?php endif; ?>
            <span class="text-white"><i class="bi bi-person me-1"></i><?php echo htmlspecialchars($nombre); ?></span>
            <a href="../auth/logout.php" class="btn btn-outline-light btn-sm">Salir</a>
        </div>
    </div>
</nav>

<div class="container-fluid px-4">
    <?php if (!empty($_SESSION['exito'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo $_SESSION['exito']; unset($_SESSION['exito']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <?php if (!empty($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($mensaje): ?>
    <div class="alert alert-<?php echo $tipo; ?> alert-dismissible fade show">
        <?php echo $mensaje; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Estadísticas -->
    <div class="row mb-4">
        <div class="col-6 col-md-3 mb-3">
            <div class="card text-center p-3">
                <div class="stat-number text-primary"><?php echo $total; ?></div>
                <small class="text-muted">Leads Asignados</small>
            </div>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <div class="card text-center p-3">
                <div class="stat-number text-success"><?php echo count($llamadas_hoy); ?></div>
                <small class="text-muted">Llamadas Hoy</small>
            </div>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <div class="card text-center p-3">
                <div class="stat-number text-danger"><?php echo count($atrasadas); ?></div>
                <small class="text-muted">Atrasadas</small>
            </div>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <div class="card text-center p-3">
                <div class="stat-number text-warning"><?php echo $interesados; ?></div>
                <small class="text-muted">Interesados</small>
            </div>
        </div>
    </div>

    <!-- Buscador -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="input-group">
                <span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="text" id="buscador" class="form-control" placeholder="Buscar por empresa, teléfono, email...">
            </div>
        </div>
    </div>

    <!-- Pestañas -->
    <div class="card">
        <div class="card-body">
            <ul class="nav nav-pills mb-4">
                <li class="nav-item">
                    <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tab-hoy">
                        Hoy <span class="badge bg-success"><?php echo count($llamadas_hoy); ?></span>
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-atrasadas">
                        Atrasadas <?php if(count($atrasadas) > 0): ?><span class="badge bg-danger"><?php echo count($atrasadas); ?></span><?php endif; ?>
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-todos">
                        Todos <span class="badge bg-secondary"><?php echo $total; ?></span>
                    </button>
                </li>
            </ul>

            <div class="tab-content">
                <!-- TAB HOY -->
                <div class="tab-pane fade show active" id="tab-hoy">
                    <?php if (count($llamadas_hoy) > 0): ?>
                        <?php $prio_actual = null; ?>
                        <?php foreach ($llamadas_hoy as $ll): ?>
                            <?php if ($ll['prioridad'] != $prio_actual): ?>
                                <?php $prio_actual = $ll['prioridad']; ?>
                                <div class="mb-2 mt-3"><?php echo getPrioridadBadge($prio_actual, $ll['estado_actual']); ?></div>
                            <?php endif; ?>
                            <div class="lead-card <?php echo getPrioridadClass($ll['prioridad']); ?>">
                                <div class="row align-items-center">
                                    <div class="col-auto">
                                        <span class="hora-badge"><?php echo date('H:i', strtotime($ll['fecha_programada'])); ?></span>
                                    </div>
                                    <div class="col">
                                        <strong><?php echo htmlspecialchars($ll['empresa']); ?></strong><br>
                                        <a href="tel:<?php echo $ll['telefono1']; ?>" class="text-primary fw-bold"><?php echo htmlspecialchars($ll['telefono1']); ?></a>
                                        <?php if (!empty($ll['email'])): ?><br><small class="text-muted"><?php echo htmlspecialchars($ll['email']); ?></small><?php endif; ?>
                                    </div>
                                    <div class="col-auto d-none d-md-block">
                                        <small class="text-muted"><?php echo htmlspecialchars($ll['provincia'] ?? ''); ?></small>
                                    </div>
                                    <div class="col-auto">
                                        <a href="gestionar_lead.php?id=<?php echo $ll['id_lead']; ?>&modo=ver" class="btn btn-outline-secondary btn-sm me-1" title="Ver sin llamar">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="gestionar_lead.php?id=<?php echo $ll['id_lead']; ?>" class="btn btn-llamar">
                                            <i class="bi bi-telephone-outbound"></i> Llamar
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-calendar-check text-muted" style="font-size:4rem"></i>
                            <?php if ($total > 0): ?>
                                <h5 class="mt-3">No hay llamadas programadas para hoy</h5>
                                <p>Ve a "Todos" para ver tus <?php echo $total; ?> leads asignados.</p>
                            <?php else: ?>
                                <h5 class="mt-3 text-warning">No tienes leads asignados</h5>
                                <p>Puedes dar de alta un nuevo lead con el botón "Nuevo Lead".</p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- TAB ATRASADAS -->
                <div class="tab-pane fade" id="tab-atrasadas">
                    <?php if (count($atrasadas) > 0): ?>
                        <div class="alert alert-danger">
                            <strong><?php echo count($atrasadas); ?> llamadas atrasadas</strong> - ¡Gestiónalas cuanto antes!
                        </div>
                        <?php foreach ($atrasadas as $ll): ?>
                        <div class="lead-card border-start border-danger border-4">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <span class="badge bg-danger"><?php echo date('d/m H:i', strtotime($ll['fecha_programada'])); ?></span>
                                </div>
                                <div class="col">
                                    <strong><?php echo htmlspecialchars($ll['empresa']); ?></strong> - <?php echo $ll['telefono1']; ?>
                                </div>
                                <div class="col-auto">
                                    <a href="gestionar_lead.php?id=<?php echo $ll['id_lead']; ?>&modo=ver" class="btn btn-outline-secondary btn-sm me-1" title="Ver">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="gestionar_lead.php?id=<?php echo $ll['id_lead']; ?>" class="btn btn-llamar btn-sm">Llamar</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-emoji-smile text-success" style="font-size:4rem"></i>
                            <h5 class="mt-3 text-success">¡Sin llamadas atrasadas!</h5>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- TAB TODOS -->
                <div class="tab-pane fade" id="tab-todos">
                    <?php if ($total > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover" id="tablaLeads">
                            <thead>
                                <tr>
                                    <th>Empresa</th>
                                    <th>Teléfono</th>
                                    <th>Email</th>
                                    <th>Provincia</th>
                                    <th>Estado</th>
                                    <th>Última</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($todos_leads as $l): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($l['empresa']); ?></strong><br>
                                        <small class="text-muted"><?php echo htmlspecialchars($l['actividad'] ?? ''); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($l['telefono1']); ?></td>
                                    <td><?php echo !empty($l['email']) ? htmlspecialchars($l['email']) : '-'; ?></td>
                                    <td><?php echo htmlspecialchars($l['provincia'] ?? '-'); ?></td>
                                    <td><span class="badge bg-secondary"><?php echo htmlspecialchars($l['ultimo_estado']); ?></span></td>
                                    <td><?php echo $l['ultima_llamada'] ? date('d/m/y', strtotime($l['ultima_llamada'])) : '-'; ?></td>
                                    <td>
                                        <a href="gestionar_lead.php?id=<?php echo $l['id']; ?>&modo=ver" class="btn btn-sm btn-outline-secondary me-1" title="Ver">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="gestionar_lead.php?id=<?php echo $l['id']; ?>" class="btn btn-sm btn-llamar" title="Llamar">
                                            <i class="bi bi-telephone"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <h5 class="text-warning">No tienes leads asignados</h5>
                            <p>Puedes dar de alta un nuevo lead con el botón "Nuevo Lead".</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Alta Lead -->
<div class="modal fade" id="modalAltaLead" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Nuevo Lead</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="accion" value="alta_lead">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Empresa *</label>
                            <input type="text" name="empresa" class="form-control" required placeholder="Nombre de la empresa">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Teléfono *</label>
                            <input type="text" name="telefono1" class="form-control" required placeholder="666123456" maxlength="9">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="email@empresa.com">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Actividad / Sector</label>
                            <input type="text" name="actividad" class="form-control" placeholder="Ej: Restauración, Comercio...">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Provincia</label>
                            <input type="text" name="provincia" class="form-control" placeholder="Ej: Madrid, Barcelona...">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Notas iniciales</label>
                            <input type="text" name="notas_alta" class="form-control" placeholder="Origen del contacto, etc.">
                        </div>
                    </div>
                    <div class="alert alert-info mb-0">
                        <i class="bi bi-info-circle me-2"></i>
                        El lead se asignará automáticamente a ti y podrás gestionarlo desde tu panel.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Dar de Alta</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function() {
    var tabla = $('#tablaLeads').DataTable({
        language: {url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json'},
        pageLength: 25
    });
    
    $('#buscador').on('keyup', function() {
        var v = $(this).val().toLowerCase();
        $('.lead-card').each(function() {
            $(this).toggle($(this).text().toLowerCase().includes(v));
        });
        tabla.search(v).draw();
        if (v.length > 2) $('[data-bs-target="#tab-todos"]').tab('show');
    });
});
</script>
</body>
</html>
